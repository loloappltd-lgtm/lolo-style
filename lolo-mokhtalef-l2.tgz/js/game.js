/* مختلف – MOKHTALEF · LOLO
   Every level lives in its own folder: levels/NNN/level.json + a.webp + b.webp, listed in levels/index.json.
   Adding a level = add its folder and its number to the index (tools/add_level.py does both). */
'use strict';
var $ = function (id) { return document.getElementById(id); };
var $$ = function (q) { return Array.prototype.slice.call(document.querySelectorAll(q)); };
var KEY = 'loloMokhtalef.v1';
var S = (function () {
  var d = { d: 0, lv: {}, coins: 0, extraHints: 0, found: 0, wins: 0, perfect: 0, fast: 0, nohint: 0, gift: -1, streak: 0, snd: 1, vib: 1, ach: {} };
  try { var j = JSON.parse(localStorage.getItem(KEY) || '{}'); for (var k in j) d[k] = j[k]; } catch (e) {}
  return d;
})();
function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} }
var TOTAL = 100, IDX = [], CACHE = {};
var RANGES = [{ name: 'سهل', from: 1, to: 34, key: 'easy' }, { name: 'متوسط', from: 35, to: 67, key: 'medium' }, { name: 'صعب', from: 68, to: 100, key: 'hard' }];

/* ---------- soft sounds (synth, no files) ---------- */
var AC = null;
function tone(f, t, type, v, to) {
  if (!S.snd) return;
  try {
    AC = AC || new (window.AudioContext || window.webkitAudioContext)(); if (AC.state === 'suspended') AC.resume();
    var o = AC.createOscillator(), g = AC.createGain(), n = AC.currentTime;
    o.type = type || 'sine'; o.frequency.setValueAtTime(f, n); if (to) o.frequency.exponentialRampToValueAtTime(to, n + t);
    g.gain.setValueAtTime(0.0001, n); g.gain.exponentialRampToValueAtTime(v || 0.12, n + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, n + t);
    o.connect(g); g.connect(AC.destination); o.start(n); o.stop(n + t + 0.05);
  } catch (e) {}
}
var sfx = {
  tap: function () { tone(620, 0.09, 'sine', 0.08); },
  ok: function () { tone(660, 0.16, 'sine', 0.12); setTimeout(function () { tone(990, 0.22, 'sine', 0.11); }, 110); },
  soft: function () { tone(300, 0.16, 'sine', 0.07, 240); },
  hint: function () { tone(740, 0.35, 'sine', 0.08, 1100); },
  win: function () { [523, 659, 784, 1047].forEach(function (f, i) { setTimeout(function () { tone(f, 0.3, 'sine', 0.11); }, i * 140); }); },
  coin: function () { tone(1046, 0.1, 'triangle', 0.06); setTimeout(function () { tone(1318, 0.14, 'triangle', 0.06); }, 80); }
};
function buzz(ms) { if (S.vib && navigator.vibrate) try { navigator.vibrate(ms); } catch (e) {} }
var tT;
function toast(t) { var e = $('toast'); e.textContent = t; e.style.display = 'block'; clearTimeout(tT); tT = setTimeout(function () { e.style.display = 'none'; }, 2000); }
function confetti() {
  var c = ['#B9A5E8', '#8D78C7', '#A9D8EA', '#B8DCC2', '#F2C4D4', '#F6D98B'];
  for (var i = 0; i < 46; i++) { var e = document.createElement('i'); e.className = 'conf'; e.style.left = Math.random() * 100 + 'vw'; e.style.background = c[i % c.length]; e.style.animationDuration = 2 + Math.random() * 1.6 + 's'; e.style.animationDelay = Math.random() * 0.5 + 's'; document.body.appendChild(e); setTimeout(function (x) { x.remove(); }.bind(null, e), 4400); }
}
(function () { var b = $('bgx'); for (var i = 0; i < 9; i++) { var e = document.createElement('i'), s = 40 + Math.random() * 120; e.style.cssText = 'width:' + s + 'px;height:' + s * 0.55 + 'px;left:' + Math.random() * 100 + '%;top:' + Math.random() * 40 + '%'; b.appendChild(e); } })();

/* ---------- screens & popups ---------- */
function show(id) { $$('.scr').forEach(function (s) { s.classList.toggle('on', s.id === id); }); if (id === 'levels') renderLevels(); if (id === 'home') renderHome(); if (id === 'game') layout(); }
function openOv(id) { $(id).classList.add('on'); }
function closeOv(id) { $(id).classList.remove('on'); }
$$('[data-close]').forEach(function (b) { b.onclick = function () { sfx.tap(); var o = b.closest('.ov'); o.classList.remove('on'); if (o.id === 'ovPause' || o.id === 'ovSet') resume(); }; });
$$('[data-go]').forEach(function (b) { b.onclick = function () { sfx.tap(); show(b.dataset.go); }; });
function ask(h, t, yes) { $('askH').textContent = h; $('askT').textContent = t; openOv('ovAsk'); $('askYes').onclick = function () { closeOv('ovAsk'); yes(); }; $('askNo').onclick = function () { closeOv('ovAsk'); }; }

/* ---------- levels data ---------- */
function getJSON(u) { return fetch(u, { cache: 'no-cache' }).then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); }); }
function hasLevel(n) { return IDX.indexOf(('00' + n).slice(-3)) >= 0; }
function loadLevel(n) {
  var id = ('00' + n).slice(-3);
  if (CACHE[id]) return Promise.resolve(CACHE[id]);
  return getJSON('levels/' + id + '/level.json').then(function (L) { L.dir = 'levels/' + id + '/'; CACHE[id] = L; return L; });
}
function preload(L) { [L.images.a, L.images.b].forEach(function (f) { var i = new Image(); i.src = L.dir + f; }); }

/* ---------- progress ---------- */
function starsOf(n) { return (S.lv[n] && S.lv[n].s) || 0; }
function unlocked(n) { return n === 1 || starsOf(n - 1) > 0; }
function totalStars() { var t = 0; for (var k in S.lv) t += S.lv[k].s || 0; return t; }
function doneCount() { var t = 0; for (var k in S.lv) if (S.lv[k].s) t++; return t; }
function nextIn(r) { for (var n = r.from; n <= r.to; n++) { if (!hasLevel(n)) return { soon: n }; if (!starsOf(n)) return unlocked(n) ? { n: n } : { locked: n }; } return { all: true }; }
function updPills() { $$('.coinsN').forEach(function (e) { e.textContent = S.coins; }); $$('.starsN').forEach(function (e) { e.textContent = totalStars(); }); }

/* ---------- home ---------- */
function renderHome() { $$('.dbtn').forEach(function (b) { b.classList.toggle('sel', +b.dataset.d === S.d); }); $('gdot').style.display = giftReady() ? 'block' : 'none'; updPills(); }
$$('.dbtn').forEach(function (b) { b.onclick = function () { S.d = +b.dataset.d; save(); sfx.tap(); renderHome(); }; });
$('hPlay').onclick = function () {
  sfx.tap(); var r = RANGES[S.d], x = nextIn(r);
  if (x.n) return startLevel(x.n);
  if (x.locked) { toast('خلّص المراحل اللي قبل ' + x.locked + ' الأول 🔒'); return show('levels'); }
  if (x.soon) { toast('مراحل «' + r.name + '» الجديدة جاية قريب ✨'); return show('levels'); }
  toast('خلّصت كل مراحل «' + r.name + '» 👏'); show('levels');
};
$('hLv').onclick = function () { sfx.tap(); show('levels'); };
$('hSet').onclick = function () { sfx.tap(); renderSet(); openOv('ovSet'); };
$('hAch').onclick = function () { sfx.tap(); renderAch(); openOv('ovAch'); };
$('hGift').onclick = function () { sfx.tap(); renderGift(); openOv('ovGift'); };

/* ---------- levels screen ---------- */
function renderLevels() {
  updPills(); var h = '', cur = 0;
  for (var n = 1; n <= TOTAL; n++) if (hasLevel(n) && unlocked(n) && !starsOf(n)) { cur = n; break; }
  RANGES.forEach(function (r) {
    h += '<div class="sec">' + r.name + ' ' + '★'.repeat(RANGES.indexOf(r) + 1) + '<i></i></div>';
    for (var n = r.from; n <= r.to; n++) {
      if (!hasLevel(n)) { h += '<div class="lc soon">' + n + '<small>قريبًا</small></div>'; continue; }
      var s = starsOf(n), u = unlocked(n);
      h += '<button class="lc ' + (s ? 'done' : n === cur ? 'cur' : u ? '' : 'lock') + '" data-n="' + n + '">' + (u ? n : '🔒') + (u ? '<small>' + '★'.repeat(s) + '☆'.repeat(3 - s) + '</small>' : '') + '</button>';
    }
  });
  var g = $('lgrid'); g.innerHTML = h;
  $$('#lgrid button.lc').forEach(function (b) { b.onclick = function () { var n = +b.dataset.n; if (!unlocked(n)) { sfx.soft(); toast('خلّص المرحلة ' + (n - 1) + ' الأول 🔒'); return; } sfx.tap(); startLevel(n); }; });
  var c = g.querySelector('.cur'); if (c) setTimeout(function () { c.scrollIntoView({ block: 'center' }); }, 30);
}

/* ---------- game ---------- */
var G = null, clock = 0;
function startLevel(n) {
  loadLevel(n).then(function (L) {
    G = { n: n, L: L, got: [], miss: 0, t: 0, hints: L.hints, used: 0, over: false, paused: false, hintOn: false, score: 0 };
    $('gLv').textContent = n;
    ['svA', 'svB'].forEach(function (s) { $(s).innerHTML = ''; $(s).setAttribute('viewBox', '0 0 1000 ' + Math.round(1000 / L.ratio)); });
    var ready = 0, go = function () { if (++ready < 2) return; show('game'); updHUD(); clearInterval(clock); clock = setInterval(function () { if (G && !G.over && !G.paused && !document.hidden) G.t++; }, 1000); };
    $('imA').onload = go; $('imB').onload = go; $('imA').onerror = $('imB').onerror = function () { toast('الصور مش راضية تحمل — جرّب تاني'); };
    $('imA').src = L.dir + L.images.a; $('imB').src = L.dir + L.images.b;
    if (hasLevel(n + 1)) loadLevel(n + 1).then(preload, function () {});
  }, function () { toast('المرحلة دي مش موجودة لسه'); });
}
function layout() {
  if (!G) return; var bd = $('board'), W = bd.clientWidth, H = bd.clientHeight - 12, gap = parseFloat(getComputedStyle(bd).gap) || 12, ar = G.L.ratio;
  var w = Math.min((W - gap) / 2 - 12, (H - 12) * ar), h = w / ar;
  ['picA', 'picB'].forEach(function (p) { $(p).style.width = w + 12 + 'px'; $(p).style.height = h + 12 + 'px'; });
}
window.addEventListener('resize', function () { setTimeout(layout, 60); });
function liveStars() { var s = 3; if (G.used >= 1) s--; if (G.used >= 2 || G.miss >= 6) s--; if (G.miss >= 12) s = Math.min(s, 1); return Math.max(1, s); }
function updHUD() {
  var c = G.L.differences.length, f = G.got.length;
  $('gCnt').textContent = f + ' من ' + c;
  $('progB').style.width = (f / c * 100) + '%';
  var left = G.hints + S.extraHints; $('hintN').textContent = left; $('hintB').classList.toggle('dis', left <= 0);
  var s = liveStars(); $$('#gStars .st').forEach(function (e, i) { e.classList.toggle('on', i < s); });
}
function vbH() { return 1000 / G.L.ratio; }
function circ(cls, d, k) { var r = Math.max(46, (d.r + 0.012) * 1000); return '<circle class="' + cls + '" cx="' + (d.x * 1000).toFixed(1) + '" cy="' + (d.y * vbH()).toFixed(1) + '" r="' + r.toFixed(1) + '"' + (k ? ' data-k="' + k + '"' : '') + '/>'; }
function point(pic, e) { var r = pic.getBoundingClientRect(), b = 6; return { x: (e.clientX - r.left - b) / (r.width - 2 * b), y: (e.clientY - r.top - b) / (r.height - 2 * b) }; }
function hitTest(p) {
  var best = -1, bd = 1e9;
  G.L.differences.forEach(function (d, k) {
    var dx = p.x - d.x, dy = (p.y - d.y) / G.L.ratio, dist = Math.sqrt(dx * dx + dy * dy), tol = Math.max(d.r, 0.055) + (d.r < 0.1 ? 0.045 : 0.02); // forgiving for small fingers, without swallowing nearby objects
    if (dist <= tol && dist < bd) { bd = dist; best = k; }
  });
  return best;
}
function onTap(e) {
  if (!G || G.over || G.paused) return;
  e.preventDefault();
  var pic = e.currentTarget, p = point(pic, e), k = hitTest(p);
  if (k >= 0 && G.got.indexOf(k) < 0) return found(k);
  // wrong place, or a difference already found: a gentle ripple only, never counted twice
  var sv = pic.querySelector('svg'), vb = vbH();
  sv.insertAdjacentHTML('beforeend', '<circle class="ripple" cx="' + p.x * 1000 + '" cy="' + p.y * vb + '" r="34"/>');
  var rp = sv.lastChild; setTimeout(function () { rp.remove(); }, 650);
  if (k < 0) { G.miss++; sfx.soft(); buzz(25); pic.classList.remove('shake'); void pic.offsetWidth; pic.classList.add('shake'); updHUD(); }
}
function found(k) {
  G.got.push(k); var d = G.L.differences[k];
  sfx.ok(); buzz(35); S.found++; save();
  ['svA', 'svB'].forEach(function (s) {
    var sv = $(s); sv.querySelectorAll('.hintC').forEach(function (h) { h.remove(); });
    sv.insertAdjacentHTML('beforeend', '<g class="grow">' + circ('found', d) + circ('found2', d) + '</g>');
    var y = d.y * vbH() - Math.max(46, d.r * 1000) - 10;
    sv.insertAdjacentHTML('beforeend', '<use href="#star" class="flyStar" x="' + (d.x * 1000 - 34) + '" y="' + (y - 34) + '" width="68" height="68" fill="#F6D98B" stroke="#fff" stroke-width="3"/>');
    var st = sv.lastChild; setTimeout(function () { st.remove(); }, 1050);
  });
  G.hintOn = false; updHUD();
  if (G.got.length === G.L.differences.length) win();
}
$('picA').addEventListener('pointerdown', onTap); $('picB').addEventListener('pointerdown', onTap);
$('hintB').onclick = function () {
  if (!G || G.over || G.paused) return;
  if (G.hintOn) return; // one hint at a time
  var left = G.L.differences.map(function (d, k) { return k; }).filter(function (k) { return G.got.indexOf(k) < 0; });
  if (!left.length) return;
  if (G.hints + S.extraHints <= 0) {
    if (S.coins >= 20) return ask('تلميح زيادة 💡', 'تاخد تلميح بـ 20 🪙؟', function () { S.coins -= 20; S.extraHints++; save(); sfx.coin(); updHUD(); updPills(); $('hintB').click(); });
    sfx.soft(); return toast('خلصت التلميحات — جرّب تدوّر بنفسك 🔎');
  }
  if (G.hints > 0) G.hints--; else { S.extraHints--; save(); }
  G.used++; G.hintOn = true; sfx.hint();
  var d = G.L.differences[left[0]];
  ['svA', 'svB'].forEach(function (s) { $(s).insertAdjacentHTML('beforeend', circ('hintC', d)); var c = $(s).lastChild; setTimeout(function () { c.remove(); if (G) G.hintOn = false; }, 3400); });
  updHUD();
};
function win() {
  G.over = true; clearInterval(clock);
  var P = G.L.points || {}, c = G.L.differences.length, s = liveStars();
  var base = (P.perDifference || 100) * c, fast = G.t <= (P.fastSeconds || 60) ? (P.fastBonus || 150) : 0, noh = G.used === 0 ? (P.noHintBonus || 100) : 0, total = base + fast + noh;
  var prev = S.lv[G.n] || {}, first = !prev.s, coins = first ? (P.coins || 10) + (s - 1) * 5 : 2;
  S.lv[G.n] = { s: Math.max(prev.s || 0, s), score: Math.max(prev.score || 0, total), t: Math.min(prev.t || 1e9, G.t) };
  S.coins += coins; S.wins++; if (s === 3) S.perfect++; if (fast) S.fast++; if (noh) S.nohint++; save();
  var h = ''; for (var i = 0; i < 3; i++) h += '<svg class="st' + (i < s ? ' on' : '') + '" style="animation-delay:' + (0.2 + i * 0.22) + 's"><use href="#star"/></svg>';
  $('wStars').innerHTML = h;
  $('wScore').innerHTML = '<div><span>الاختلافات (' + c + ')</span><b>' + base + '</b></div>' +
    (fast ? '<div><span>⚡ مكافأة السرعة</span><b>+' + fast + '</b></div>' : '') +
    (noh ? '<div><span>💡 من غير تلميح</span><b>+' + noh + '</b></div>' : '') +
    '<div class="tot"><span>النقاط</span><b>' + total + '</b></div><div><span>العملات</span><b>+' + coins + ' 🪙</b></div>';
  var nx = hasLevel(G.n + 1); $('wNext').classList.toggle('dis', !nx); $('wNext').dataset.soon = nx ? '' : '1';
  setTimeout(function () { sfx.win(); confetti(); openOv('ovWin'); checkAch(); }, 650);
}
$('wNext').onclick = function () { if (this.dataset.soon) { toast('المرحلة ' + (G.n + 1) + ' جاية قريب ✨'); return; } closeOv('ovWin'); startLevel(G.n + 1); };
$('wRe').onclick = function () { closeOv('ovWin'); startLevel(G.n); };
$('wLv').onclick = function () { closeOv('ovWin'); show('levels'); };
function pause(withSet) { if (!G || G.over) return; G.paused = true; if (withSet) { renderSet(); openOv('ovSet'); } else openOv('ovPause'); }
function resume() { if (G && !G.over) G.paused = false; }
$('gHome').onclick = function () { sfx.tap(); if (!G || G.over) return show('home'); pause(false); };
$('gSet').onclick = function () { sfx.tap(); pause(true); };
$('pGo').onclick = function () { closeOv('ovPause'); resume(); };
$('pLv').onclick = function () { closeOv('ovPause'); G.over = true; clearInterval(clock); show('levels'); };
$('pHome').onclick = function () { closeOv('ovPause'); G.over = true; clearInterval(clock); show('home'); };
document.addEventListener('visibilitychange', function () { if (document.hidden && G && !G.over && !G.paused && $('game').classList.contains('on')) pause(false); });

/* ---------- settings ---------- */
function renderSet() { $('tgSnd').classList.toggle('on', !!S.snd); $('tgVib').classList.toggle('on', !!S.vib); }
$('tgSnd').onclick = function () { S.snd = S.snd ? 0 : 1; save(); renderSet(); sfx.tap(); };
$('tgVib').onclick = function () { S.vib = S.vib ? 0 : 1; save(); renderSet(); buzz(40); };
$('rstB').onclick = function () { ask('تبدأ من الأول؟', 'هيتمسح كل المراحل والنجوم والعملات', function () { try { localStorage.removeItem(KEY); } catch (e) {} location.reload(); }); };

/* ---------- achievements ---------- */
var ACH = [
  { id: 'w1', ic: '🔎', n: 'أول اكتشاف', d: 'خلّص أول مرحلة', v: function () { return S.wins; }, goal: 1, c: 10 },
  { id: 'nh', ic: '💡', n: 'من غير مساعدة', d: 'خلّص مرحلة من غير تلميح', v: function () { return S.nohint; }, goal: 1, c: 15 },
  { id: 'fast', ic: '⚡', n: 'سريع', d: 'خلّص مرحلة وتاخد مكافأة السرعة', v: function () { return S.fast; }, goal: 1, c: 15 },
  { id: 'f50', ic: '👀', n: 'عين لولو', d: 'اكتشف 50 اختلاف', v: function () { return S.found; }, goal: 50, c: 20 },
  { id: 'p5', ic: '⭐', n: 'نجمة لولو', d: '5 مراحل بـ 3 نجوم', v: function () { return S.perfect; }, goal: 5, c: 25 },
  { id: 'w10', ic: '🏅', n: 'محقق شاطر', d: 'خلّص 10 مراحل', v: doneCount, goal: 10, c: 30 },
  { id: 'st100', ic: '🌟', n: '100 نجمة', d: 'اجمع 100 نجمة', v: totalStars, goal: 100, c: 60 },
  { id: 'w100', ic: '👑', n: 'بطل مختلف', d: 'خلّص الـ100 مرحلة', v: doneCount, goal: 100, c: 200 }
];
function checkAch() { var d = 0; ACH.forEach(function (a) { if (!S.ach[a.id] && a.v() >= a.goal) { S.ach[a.id] = 1; S.coins += a.c; save(); d += 1600; setTimeout(function () { sfx.coin(); toast('🏆 ' + a.n + ' +' + a.c + ' 🪙'); }, 1400 + d - 1600); } }); }
function renderAch() { $('achL').innerHTML = ACH.map(function (a) { var v = Math.min(a.v(), a.goal), got = !!S.ach[a.id]; return '<div class="it' + (got ? ' got' : '') + '"><span class="ic">' + a.ic + '</span><span class="tx">' + a.n + '<small>' + a.d + ' · ' + a.c + ' 🪙</small><div class="pb"><b style="width:' + (v / a.goal * 100) + '%"></b></div></span><b>' + (got ? '✅' : v + '/' + a.goal) + '</b></div>'; }).join(''); }

/* ---------- rewards ---------- */
function today() { var d = new Date(); return Math.floor((d.getTime() - d.getTimezoneOffset() * 6e4) / 864e5); }
function giftReady() { return S.gift !== today(); }
var GIFTS = [10, 15, 20, 25, 30, 40, 60];
function renderGift() {
  var st = (S.gift === today() || S.gift === today() - 1) ? S.streak : 0, nowK = giftReady() ? st % 7 : (st - 1) % 7;
  var days = GIFTS.map(function (g, k) { var cls = (k < nowK || (k === nowK && !giftReady())) ? 'ok' : k === nowK ? 'now' : ''; return '<span class="' + cls + '">يوم ' + (k + 1) + '<br>' + g + ' 🪙</span>'; }).join('');
  $('giftL').innerHTML =
    '<div class="it"><span class="ic">📅</span><span class="tx">هدية كل يوم<small>تعالى كل يوم وهديتك تكبر</small><div class="days">' + days + '</div></span></div>' +
    '<div class="rowb"><button class="btn y' + (giftReady() ? '' : ' dis') + '" id="takeG">' + (giftReady() ? '🎁 خد هديتك' : 'تعالى بكرة 😊') + '</button></div>' +
    '<div class="it" style="margin-top:6px"><span class="ic">🪙</span><span class="tx">عملاتك: ' + S.coins + '<small>كل 20 🪙 = تلميح 💡 · عندك ' + S.extraHints + ' تلميح زيادة</small></span><button class="btn l" id="buyH" style="height:42px;padding:0 14px;font-size:16px">💡 بـ 20</button></div>';
  $('buyH').onclick = function () { if (S.coins < 20) { sfx.soft(); return toast('محتاج 20 🪙'); } S.coins -= 20; S.extraHints++; save(); sfx.coin(); updPills(); renderGift(); };
  $('takeG').onclick = function () { if (!giftReady()) return; S.streak = S.gift === today() - 1 ? S.streak + 1 : 1; var g = GIFTS[(S.streak - 1) % 7]; S.coins += g; S.gift = today(); save(); sfx.win(); confetti(); toast('🎁 +' + g + ' 🪙'); renderGift(); renderHome(); };
}

/* ---------- start ---------- */
getJSON('levels/index.json').then(function (j) { IDX = j.levels || []; TOTAL = j.total || 100; }, function () { IDX = []; }).then(function () {
  renderHome();
  if (hasLevel(1)) loadLevel(1).then(function (L) { $('pvA').src = L.dir + L.images.a; $('pvB').src = L.dir + L.images.b; preload(L); }, function () {});
});
window.MOKHTALEF = { S: S, get G() { return G; }, startLevel: startLevel, hitTest: function (x, y) { return hitTest({ x: x, y: y }); } };
