/* مختلف — leaderboard (ترتيب اللاعبين) for the LOLO backend.
   Child safety: players appear only after they choose to join; only a nickname built from fixed word lists and a ready-made
   avatar are stored and shown — no real name, email, phone, country, location, photos or messages. Leaving deletes the
   player's leaderboard data.
   Scores: the server never takes a score from the device. The device sends a finished level (number, stars, time, hints);
   the server checks it against the real level files and its own rules, keeps each player's best stars per level, and
   records only the stars that are NEW (an improvement) as an event with the server time, so the same stars are never
   counted twice.
   week  = stars gained since Saturday 00:00 (Africa/Cairo)   month = since the 1st 00:00 (Africa/Cairo)   all = every star.
   Ties (fixed rule): more stars first → the player who reached that total EARLIER first → the older player id first. */
'use strict';
const crypto = require('crypto'), fs = require('fs'), path = require('path');
const TZ = 'Africa/Cairo';
const NICK_A = ['النجم', 'البطل', 'المحقق', 'الصقر', 'القمر', 'الفراشة', 'الكابتن', 'النحلة', 'الأسد', 'الدلفين', 'الأميرة', 'الفارس', 'الكوكب', 'الشمس', 'الوردة', 'السنجاب'];
const NICK_B = ['الذكي', 'السريع', 'اللامع', 'الشجاع', 'المرح', 'الهادي', 'الشاطر', 'البطل', 'الصغير', 'المبدع', 'المكتشف', 'الطيّب'];
const AVATARS = ['lolo', 'boy', 'girl', 'bunny', 'squirrel', 'turtle', 'penguin', 'robot', 'dino', 'rocket'];
const PRIZES = [100, 60, 40];      // weekly gift coins for places 1, 2, 3 of the week that just ended
const ACH_MAX = 50, LVL_MAX = 200, PAGE_MAX = 50;

function tzParts(ms) {
  const f = new Intl.DateTimeFormat('en-GB', { timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', weekday: 'short', hourCycle: 'h23' });
  const o = {}; f.formatToParts(new Date(ms)).forEach((p) => { o[p.type] = p.value; }); return o;
}
/* the instant (UTC ms) of local midnight for a given local Y-M-D in TZ */
function localMidnight(y, m, d) {
  let guess = Date.UTC(y, m - 1, d);
  for (let i = 0; i < 2; i++) { const p = tzParts(guess); const off = Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute, +p.second) - guess; guess = Date.UTC(y, m - 1, d) - off; }
  return guess;
}
function periodStart(kind, now) {
  if (kind === 'all') return 0;
  const p = tzParts(now), y = +p.year, m = +p.month, d = +p.day;
  if (kind === 'month') return localMidnight(y, m, 1);
  const wd = { Sat: 0, Sun: 1, Mon: 2, Tue: 3, Wed: 4, Thu: 5, Fri: 6 }[p.weekday];   // week starts Saturday
  const base = new Date(Date.UTC(y, m - 1, d - wd));
  return localMidnight(base.getUTCFullYear(), base.getUTCMonth() + 1, base.getUTCDate());
}
function nextWeekStart(now) { const s = periodStart('week', now), b = new Date(s + 8 * 864e5), p = tzParts(b.getTime()); return periodStart('week', localMidnight(+p.year, +p.month, +p.day) + 3600e3); }
const sha = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');
const isNick = (n) => { const a = String(n || '').split(' '); return a.length === 2 && NICK_A.includes(a[0]) && NICK_B.includes(a[1]); };
class Fail extends Error { constructor(code, msg) { super(msg); this.code = code; } }

function makeLeaderboard(opts) {
  const store = opts.store, levelsDir = opts.levelsDir, now = opts.now || (() => Date.now());
  const lastResult = new Map(), joins = new Map();
  let cache = { k: '', t: 0, rows: null };
  function levelInfo(n) {
    try {
      const id = ('00' + n).slice(-3), idx = JSON.parse(fs.readFileSync(path.join(levelsDir, 'index.json'), 'utf8'));
      if (!(idx.levels || []).includes(id)) return null;
      return JSON.parse(fs.readFileSync(path.join(levelsDir, id, 'level.json'), 'utf8'));
    } catch (e) { return null; }
  }
  async function auth(pid, key) {
    if (typeof pid !== 'string' || !/^[a-f0-9]{24}$/.test(pid) || typeof key !== 'string' || key.length < 20) throw new Fail(401, 'auth');
    const p = await store.getPlayer(pid);
    if (!p || p.keyHash !== sha(key)) throw new Fail(401, 'auth');
    return p;
  }
  async function join(body, ip) {
    const t = now(), j = (joins.get(ip) || []).filter((x) => t - x < 3600e3);
    if (j.length >= 10) throw new Fail(429, 'too many');
    if (!isNick(body.nick) || !AVATARS.includes(body.av)) throw new Fail(400, 'nick or avatar');
    j.push(t); joins.set(ip, j);
    const pid = crypto.randomBytes(12).toString('hex'), key = crypto.randomBytes(24).toString('hex');
    await store.insertPlayer({ pid, keyHash: sha(key), nick: body.nick, av: body.av, ach: 0, lvl: 1, show: body.show === true, created: t });
    cache.t = 0; return { pid, key };
  }
  async function profile(body) {
    await auth(body.pid, body.key); const set = {};
    if (body.nick !== undefined) { if (!isNick(body.nick)) throw new Fail(400, 'nick'); set.nick = body.nick; }
    if (body.av !== undefined) { if (!AVATARS.includes(body.av)) throw new Fail(400, 'avatar'); set.av = body.av; }
    if (body.show !== undefined) {                                   // shown in the leaderboard only when the player agrees
      const par = await store.getParent(body.pid);
      if (par && par.pinHash && !(await tokenOk(par, body.token))) throw new Fail(403, 'parent');
      if (body.show === true && par && par.set && par.set.lbAllow === false) throw new Fail(403, 'parent off');
      set.show = body.show === true;
    }
    await store.updatePlayer(body.pid, set); cache.t = 0; return { ok: true };
  }
  async function leave(body) { await auth(body.pid, body.key); const par = await store.getParent(body.pid); if (par && par.pinHash && !(await tokenOk(par, body.token))) throw new Fail(403, 'parent'); await store.deletePlayer(body.pid); cache.t = 0; return { ok: true }; }
  async function result(body) {
    const p = await auth(body.pid, body.key), t = now();
    if (t - (lastResult.get(p.pid) || 0) < 1500) throw new Fail(429, 'slow down');
    const st = await playStatus(p.pid, t); if (!st.allowed) throw new Fail(403, 'play ' + st.reason);   // parent rules are checked here too, not only in the game
    const out = await applyOne(p, body, t); lastResult.set(p.pid, t);
    await store.incPlay(p.pid, dayKey(t), { res: Math.min(3600, Math.max(0, Number(body.time) || 0)), levels: out.first ? 1 : 0 }, {});
    await displayFields(p, body); return out;
  }
  /* first sync after joining: the levels already finished on this device, checked one by one in order */
  async function sync(body) {
    const p = await auth(body.pid, body.key), t = now(), list = Array.isArray(body.levels) ? body.levels.slice(0, 100) : [];
    if (t - (lastResult.get(p.pid) || 0) < 1500) throw new Fail(429, 'slow down');
    lastResult.set(p.pid, t);
    list.sort((a, b) => (a.level | 0) - (b.level | 0)); let added = 0, ok = 0;
    for (const L of list) { try { added += (await applyOne(p, L, t)).added; ok++; } catch (e) { break; } }
    await displayFields(p, body); return { ok: true, accepted: ok, added };
  }
  async function displayFields(p, body) {
    const set = {};
    if (body.ach !== undefined) set.ach = Math.max(0, Math.min(ACH_MAX, body.ach | 0));
    if (body.lvl !== undefined) set.lvl = Math.max(1, Math.min(LVL_MAX, body.lvl | 0));
    if (Object.keys(set).length) await store.updatePlayer(p.pid, set);
  }
  async function applyOne(p, body, t) {
    const n = body.level | 0, stars = body.stars | 0, secs = Number(body.time), hints = body.hints | 0;
    const L = n >= 1 && n <= 100 ? levelInfo(n) : null;
    if (!L) throw new Fail(400, 'level');
    if (stars < 1 || stars > 3 || hints < 0 || hints > 20) throw new Fail(400, 'stars');
    const cnt = (L.differences || []).length || 1;
    if (!(secs >= Math.max(3, cnt * 1.5)) || secs > 86400) throw new Fail(400, 'time');
    const maxStars = hints >= 2 ? 1 : hints === 1 ? 2 : 3;                       // same rule as the game
    if (stars > maxStars) throw new Fail(400, 'stars vs hints');
    if (n > 1 && !(await store.getBest(p.pid, n - 1))) throw new Fail(409, 'previous level');
    const prev = (await store.getBest(p.pid, n)) || 0, delta = stars - prev;
    if (delta > 0) { await store.setBest(p.pid, n, stars); await store.addEvent({ pid: p.pid, level: n, delta, at: t }); cache.t = 0; }
    return { ok: true, added: Math.max(0, delta), first: prev === 0 };
  }
  async function ranked(kind, at) {
    const from = periodStart(kind, at === undefined ? now() : at), to = at === undefined ? Infinity : at, k = kind + ':' + from + ':' + to;
    let rows;                                                  // star totals are cached a few seconds; who may be shown is read fresh every time
    if (cache.k === k && now() - cache.t < 15000 && cache.rows) rows = cache.rows; else { rows = await store.scores(from, to); if (at === undefined) cache = { k, t: now(), rows }; }
    const players = await store.getPlayers(rows.map((r) => r.pid));
    const list = rows.filter((r) => r.score > 0 && players[r.pid] && players[r.pid].show).sort((a, b) => b.score - a.score || a.at - b.at || (a.pid < b.pid ? -1 : 1))
      .map((r, i) => ({ rank: i + 1, pid: r.pid, stars: r.score, nick: players[r.pid].nick, av: players[r.pid].av, ach: players[r.pid].ach || 0, lvl: players[r.pid].lvl || 1 }));
    return list;
  }
  const pub = (r) => ({ rank: r.rank, nick: r.nick, av: r.av, stars: r.stars, ach: r.ach, lvl: r.lvl });
  async function board(q) {
    const kind = ['week', 'month', 'all'].includes(q.period) ? q.period : 'week';
    const size = Math.max(1, Math.min(PAGE_MAX, q.size | 0 || 20)), page = Math.max(1, q.page | 0 || 1);
    const list = await ranked(kind), items = list.slice((page - 1) * size, page * size).map(pub);
    let me = null;
    if (q.pid && q.key) { try { const p = await auth(q.pid, q.key); const r = list.find((x) => x.pid === p.pid); me = r ? Object.assign(pub(r), { show: !!p.show }) : { rank: null, nick: p.nick, av: p.av, stars: 0, ach: p.ach || 0, lvl: p.lvl || 1, show: !!p.show }; } catch (e) { me = null; } }
    return { period: kind, page, size, total: list.length, pages: Math.max(1, Math.ceil(list.length / size)), items, me, resetIn: Math.max(0, Math.round((nextWeekStart(now()) - now()) / 1000)), prizes: PRIZES };
  }
  async function me(q) {
    const p = await auth(q.pid, q.key), out = { nick: p.nick, av: p.av, show: !!p.show, ranks: {} };
    for (const k of ['week', 'month', 'all']) { const r = (await ranked(k)).find((x) => x.pid === p.pid); out.ranks[k] = r ? r.rank : null; }
    return out;
  }
  async function prize(body) {
    const p = await auth(body.pid, body.key), weekStart = periodStart('week', now()), lastStart = periodStart('week', weekStart - 3600e3);
    if (p.prizeWeek === lastStart) return { coins: 0, place: null, already: true };
    const last = await ranked('week', weekStart - 1);
    const r = last.find((x) => x.pid === p.pid), place = r && r.rank <= PRIZES.length ? r.rank : null;
    if (!place) return { coins: 0, place: null };
    await store.updatePlayer(p.pid, { prizeWeek: lastStart });
    return { coins: PRIZES[place - 1], place };
  }

  /* ================= parental controls =================
     The PIN is never stored: only scrypt(pin, salt). Wrong PINs are counted on the server (5 tries, then 15 minutes locked).
     A parent session is a random token (only its hash is kept) that ends after 15 minutes.
     Recovery: when the PIN is made, a one-time recovery code is shown to the parent once; only its scrypt hash is kept.
     Play time is counted on the server (heartbeats + the time of every finished level) and the server refuses results
     outside the parent's rules, so the limits do not depend on the game screen alone. */
  const PIN_RE = /^[0-9]{4,6}$/, TOKEN_MS = 15 * 60e3, MAX_FAILS = 5, LOCK_MS = 15 * 60e3;
  const DEF_SET = { limitOn: false, limitMin: 30, schedOn: false, from: '16:00', to: '20:00', paused: false, age: '6-8', buyApproval: true, lbAllow: true, sync: true };
  const kdf = (secret, salt) => crypto.scryptSync(String(secret), salt, 32).toString('hex');
  const same = (a, b) => { try { return a.length === b.length && crypto.timingSafeEqual(Buffer.from(a, 'hex'), Buffer.from(b, 'hex')); } catch (e) { return false; } };
  function dayKey(t) { const p = tzParts(t); return p.year + '-' + p.month + '-' + p.day; }
  function mins(hhmm) { const m = /^([01][0-9]|2[0-3]):([0-5][0-9])$/.exec(hhmm || ''); return m ? +m[1] * 60 + +m[2] : null; }
  function settingsOf(par) { return Object.assign({}, DEF_SET, (par && par.set) || {}, { kidSafe: true, privacy: true }); }
  function recCode() { const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; let s = ''; const b = crypto.randomBytes(12); for (let i = 0; i < 12; i++) s += A[b[i] % A.length]; return s.slice(0, 4) + '-' + s.slice(4, 8) + '-' + s.slice(8); }
  async function tokenOk(par, token) {
    if (!par || typeof token !== 'string' || token.length < 20) return false;
    const h = sha(token), t = now(); return (par.tokens || []).some((x) => x.h === h && x.exp > t);
  }
  async function newToken(pid, par) {
    const token = crypto.randomBytes(24).toString('hex'), t = now();
    const tokens = (par.tokens || []).filter((x) => x.exp > t).slice(-2).concat([{ h: sha(token), exp: t + TOKEN_MS }]);
    await store.putParent(pid, { tokens }); return { token, expiresIn: TOKEN_MS / 1000 };
  }
  async function needParent(body) { const p = await auth(body.pid, body.key), par = await store.getParent(p.pid); if (!par || !par.pinHash || !(await tokenOk(par, body.token))) throw new Fail(401, 'parent'); return { p, par }; }
  function lockLeft(par) { return par && par.lockUntil > now() ? Math.ceil((par.lockUntil - now()) / 1000) : 0; }
  async function failed(pid, par) {
    const fails = (par.fails || 0) + 1, set = { fails };
    if (fails >= MAX_FAILS) { set.fails = 0; set.lockUntil = now() + LOCK_MS; }
    await store.putParent(pid, set);
    const e = new Fail(fails >= MAX_FAILS ? 429 : 403, fails >= MAX_FAILS ? 'locked' : 'wrong'); e.left = fails >= MAX_FAILS ? LOCK_MS / 1000 : MAX_FAILS - fails; throw e;
  }
  async function checkPin(pid, par, pin) {
    if (!par || !par.pinHash) throw new Fail(404, 'no pin');
    if (lockLeft(par)) { const e = new Fail(429, 'locked'); e.left = lockLeft(par); throw e; }
    if (!PIN_RE.test(String(pin || '')) || !same(kdf(pin, par.pinSalt), par.pinHash)) await failed(pid, par);
    if (par.fails) await store.putParent(pid, { fails: 0 });
  }
  async function setPin(pid, pin) {
    const pinSalt = crypto.randomBytes(16).toString('hex'), recSalt = crypto.randomBytes(16).toString('hex'), code = recCode();
    await store.putParent(pid, { pinHash: kdf(pin, pinSalt), pinSalt, pinLen: String(pin).length, recHash: kdf(code.replace(/-/g, ''), recSalt), recSalt, fails: 0, lockUntil: 0, tokens: [], changed: now() });
    return code;
  }
  async function playStatus(pid, t) {
    const par = await store.getParent(pid); if (!par || !par.pinHash) return { allowed: true, reason: null, used: 0, left: null, guarded: false };
    const st = settingsOf(par), day = await store.getPlay(pid, dayKey(t)) || {}, used = Math.max(day.secs || 0, day.res || 0);
    const limit = st.limitOn ? st.limitMin * 60 + (day.extra || 0) : null;
    const p = tzParts(t), nowMin = +p.hour * 60 + +p.minute, a = mins(st.from), b = mins(st.to);
    const inWin = a === null || b === null ? true : a <= b ? nowMin >= a && nowMin < b : nowMin >= a || nowMin < b;
    let reason = null;
    if (st.paused) reason = 'paused'; else if (st.schedOn && !inWin && !(day.extra > 0 && day.extraOpen)) reason = 'schedule'; else if (limit !== null && used >= limit) reason = 'limit';
    return { allowed: !reason, reason, used, left: limit === null ? null : Math.max(0, limit - used), guarded: true, from: st.from, to: st.to, schedOn: st.schedOn, limitOn: st.limitOn, newDayIn: Math.round((localMidnight(+p.year, +p.month, +p.day + 1) - t) / 1000) };
  }
  async function parentStatus(body) {
    const p = await auth(body.pid, body.key), par = await store.getParent(p.pid), t = now();
    return { hasPin: !!(par && par.pinHash), pinLen: par && par.pinLen || 4, locked: lockLeft(par), parent: await tokenOk(par, body.token), settings: settingsOf(par), play: await playStatus(p.pid, t), show: !!p.show };
  }
  async function parentSetup(body) {
    const p = await auth(body.pid, body.key), par = await store.getParent(p.pid);
    if (par && par.pinHash) throw new Fail(409, 'pin exists');
    if (!PIN_RE.test(String(body.pin || ''))) throw new Fail(400, 'pin');
    const code = await setPin(p.pid, String(body.pin)); return Object.assign({ recovery: code }, await newToken(p.pid, await store.getParent(p.pid)));
  }
  async function parentLogin(body) { const p = await auth(body.pid, body.key), par = await store.getParent(p.pid); await checkPin(p.pid, par, body.pin); return newToken(p.pid, await store.getParent(p.pid)); }
  /* one clear approval (e.g. a purchase): the PIN each time, checked here */
  async function parentApprove(body) { const p = await auth(body.pid, body.key), par = await store.getParent(p.pid); await checkPin(p.pid, par, body.pin); return { ok: true, what: String(body.what || '').slice(0, 20) }; }
  async function parentRecover(body) {
    const p = await auth(body.pid, body.key), par = await store.getParent(p.pid);
    if (!par || !par.recHash) throw new Fail(404, 'no pin');
    if (lockLeft(par)) { const e = new Fail(429, 'locked'); e.left = lockLeft(par); throw e; }
    const code = String(body.code || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (code.length !== 12 || !same(kdf(code, par.recSalt), par.recHash)) await failed(p.pid, par);
    if (!PIN_RE.test(String(body.pin || ''))) throw new Fail(400, 'pin');
    const next = await setPin(p.pid, String(body.pin)); return Object.assign({ recovery: next }, await newToken(p.pid, await store.getParent(p.pid)));
  }
  async function parentPin(body) { const { p } = await needParent(body); if (!PIN_RE.test(String(body.pin || ''))) throw new Fail(400, 'pin'); const code = await setPin(p.pid, String(body.pin)); return Object.assign({ recovery: code }, await newToken(p.pid, await store.getParent(p.pid))); }
  async function parentLogout(body) { const p = await auth(body.pid, body.key), par = await store.getParent(p.pid); if (par && body.token) await store.putParent(p.pid, { tokens: (par.tokens || []).filter((x) => x.h !== sha(body.token)) }); return { ok: true }; }
  async function parentSettings(body) {
    const { p, par } = await needParent(body), cur = settingsOf(par), x = body.set || {}, nx = {};
    for (const k of ['limitOn', 'schedOn', 'paused', 'buyApproval', 'lbAllow', 'sync']) nx[k] = x[k] === undefined ? cur[k] : x[k] === true;
    nx.limitMin = x.limitMin === undefined ? cur.limitMin : Math.round(Number(x.limitMin));
    if (!(nx.limitMin >= 5 && nx.limitMin <= 240 && nx.limitMin % 5 === 0)) throw new Fail(400, 'limitMin');
    nx.from = x.from === undefined ? cur.from : x.from; nx.to = x.to === undefined ? cur.to : x.to;
    if (mins(nx.from) === null || mins(nx.to) === null || nx.from === nx.to) throw new Fail(400, 'schedule');
    nx.age = x.age === undefined ? cur.age : x.age; if (!['3-5', '6-8', '9-12'].includes(nx.age)) throw new Fail(400, 'age');
    await store.putParent(p.pid, { set: nx, updated: now() });
    if (nx.lbAllow === false && p.show) { await store.updatePlayer(p.pid, { show: false }); cache.t = 0; }
    if (x.show !== undefined && nx.lbAllow) { await store.updatePlayer(p.pid, { show: x.show === true }); cache.t = 0; }
    return { ok: true, settings: settingsOf({ set: nx }), play: await playStatus(p.pid, now()), show: nx.lbAllow ? (x.show !== undefined ? x.show === true : !!p.show) : false };
  }
  async function parentExtra(body) {
    const { p } = await needParent(body), m = Math.round(Number(body.min)); if (![10, 15, 30].includes(m)) throw new Fail(400, 'min');
    await store.incPlay(p.pid, dayKey(now()), { extra: m * 60 }, { extraOpen: true }); return { ok: true, play: await playStatus(p.pid, now()) };
  }
  async function parentReport(body) {
    const { p } = await needParent(body), t = now(), days = [];
    for (let i = 6; i >= 0; i--) days.push(dayKey(t - i * 864e5));
    const rows = await store.playRange(p.pid, days), by = {}; rows.forEach((r) => { by[r.day] = r; });
    const list = days.map((d) => { const r = by[d] || {}; return { day: d, secs: Math.max(r.secs || 0, r.res || 0), found: r.found || 0, levels: r.levels || 0 }; });
    const best = await store.bestSummary(p.pid);
    return { days: list, week: { secs: list.reduce((a, r) => a + r.secs, 0), found: list.reduce((a, r) => a + r.found, 0), levels: list.reduce((a, r) => a + r.levels, 0) }, total: { levels: best.levels, stars: best.stars, found: await store.foundTotal(p.pid) } };
  }
  /* heartbeat from the game while a level is being played (seconds since the last beat, capped by the real time between beats) */
  async function playBeat(body) {
    const p = await auth(body.pid, body.key), par = await store.getParent(p.pid), t = now();
    if (!par || !par.pinHash) return { ok: true, play: { allowed: true, guarded: false } };
    const k = dayKey(t), day = await store.getPlay(p.pid, k) || {}, gap = day.lb ? (t - day.lb) / 1000 + 5 : 70;
    const secs = Math.max(0, Math.min(Number(body.secs) || 0, gap, 90)), found = Math.max(0, Math.min(body.found | 0, 40));
    await store.incPlay(p.pid, k, { secs: Math.round(secs), found }, { lb: t });
    return { ok: true, play: await playStatus(p.pid, t) };
  }
  /* ================= cloud save (progress backup) ================= */
  async function saveData(body) {
    const p = await auth(body.pid, body.key), par = await store.getParent(p.pid);
    if (par && par.pinHash && settingsOf(par).sync === false) throw new Fail(403, 'sync off');
    const data = body.data; if (!data || typeof data !== 'object' || Array.isArray(data)) throw new Fail(400, 'data');
    const str = JSON.stringify(data); if (str.length > 40000) throw new Fail(413, 'too big');
    const t = now(), last = await store.getSave(p.pid); if (last && t - last.at < 3000) throw new Fail(429, 'slow down');
    await store.putSave(p.pid, { data: str, at: t }); return { ok: true, at: t };
  }
  async function loadData(body) { const p = await auth(body.pid, body.key), s = await store.getSave(p.pid); let data = null; try { data = s ? JSON.parse(s.data) : null; } catch (e) {} return { data, at: s ? s.at : 0 }; }
  return { parentStatus, parentSetup, parentLogin, parentApprove, parentRecover, parentPin, parentLogout, parentSettings, parentExtra, parentReport, playBeat, saveData, loadData, playStatus, join, profile, leave, result, sync, board, me, prize, lists: { NICK_A, NICK_B, AVATARS }, _periodStart: periodStart, _nextWeekStart: nextWeekStart, Fail };
}

/* storage on the backend's MongoDB (own collections, nothing else is touched) */
function mongoStore(db) {
  const P = db.collection('mk_lb_players'), B = db.collection('mk_lb_best'), E = db.collection('mk_lb_events');
  const PA = db.collection('mk_parent'), PL = db.collection('mk_play'), SV = db.collection('mk_saves');
  PA.createIndex({ pid: 1 }, { unique: true }).catch(() => {}); PL.createIndex({ pid: 1, day: 1 }, { unique: true }).catch(() => {}); SV.createIndex({ pid: 1 }, { unique: true }).catch(() => {});
  P.createIndex({ pid: 1 }, { unique: true }).catch(() => {}); B.createIndex({ pid: 1, level: 1 }, { unique: true }).catch(() => {}); E.createIndex({ at: 1 }).catch(() => {}); E.createIndex({ pid: 1 }).catch(() => {});
  return {
    getPlayer: (pid) => P.findOne({ pid }),
    getPlayers: async (pids) => { const o = {}; (await P.find({ pid: { $in: pids } }).project({ pid: 1, nick: 1, av: 1, ach: 1, lvl: 1, show: 1 }).toArray()).forEach((p) => { o[p.pid] = p; }); return o; },
    insertPlayer: (d) => P.insertOne(d),
    updatePlayer: (pid, set) => P.updateOne({ pid }, { $set: set }),
    deletePlayer: async (pid) => { await P.deleteOne({ pid }); await B.deleteMany({ pid }); await E.deleteMany({ pid }); await PA.deleteOne({ pid }); await PL.deleteMany({ pid }); await SV.deleteOne({ pid }); },
    getParent: (pid) => PA.findOne({ pid }),
    putParent: (pid, set) => PA.updateOne({ pid }, { $set: set }, { upsert: true }),
    getPlay: (pid, day) => PL.findOne({ pid, day }),
    incPlay: (pid, day, inc, set) => PL.updateOne({ pid, day }, Object.assign({ $inc: inc }, Object.keys(set || {}).length ? { $set: set } : {}), { upsert: true }),
    playRange: (pid, days) => PL.find({ pid, day: { $in: days } }).toArray(),
    foundTotal: async (pid) => { const r = await PL.aggregate([{ $match: { pid } }, { $group: { _id: null, f: { $sum: '$found' } } }]).toArray(); return r[0] ? r[0].f : 0; },
    bestSummary: async (pid) => { const r = await B.aggregate([{ $match: { pid, stars: { $gt: 0 } } }, { $group: { _id: null, n: { $sum: 1 }, s: { $sum: '$stars' } } }]).toArray(); return { levels: r[0] ? r[0].n : 0, stars: r[0] ? r[0].s : 0 }; },
    getSave: (pid) => SV.findOne({ pid }),
    putSave: (pid, d) => SV.updateOne({ pid }, { $set: d }, { upsert: true }),
    getBest: async (pid, level) => { const r = await B.findOne({ pid, level }); return r ? r.stars : 0; },
    setBest: (pid, level, stars) => B.updateOne({ pid, level }, { $set: { stars } }, { upsert: true }),
    addEvent: (e) => E.insertOne(e),
    scores: (from, to) => E.aggregate([{ $match: { at: to === Infinity ? { $gte: from } : { $gte: from, $lte: to } } }, { $group: { _id: '$pid', score: { $sum: '$delta' }, at: { $max: '$at' } } }]).toArray().then((a) => a.map((r) => ({ pid: r._id, score: r.score, at: r.at })))
  };
}
/* in-memory storage, for tests */
function memoryStore() {
  const P = new Map(), B = new Map(), E = [], PA = new Map(), PL = new Map(), SV = new Map();
  return {
    getParent: async (pid) => PA.get(pid) || null,
    putParent: async (pid, set) => { PA.set(pid, Object.assign(PA.get(pid) || { pid }, JSON.parse(JSON.stringify(set)))); },
    getPlay: async (pid, day) => PL.get(pid + '|' + day) || null,
    incPlay: async (pid, day, inc, set) => { const k = pid + '|' + day, r = PL.get(k) || { pid, day }; for (const x in inc) r[x] = (r[x] || 0) + inc[x]; Object.assign(r, set || {}); PL.set(k, r); },
    playRange: async (pid, days) => days.map((d) => PL.get(pid + '|' + d)).filter(Boolean),
    foundTotal: async (pid) => [...PL.values()].filter((r) => r.pid === pid).reduce((a, r) => a + (r.found || 0), 0),
    bestSummary: async (pid) => { let n = 0, s = 0; for (const [k, v] of B) if (k.startsWith(pid + ':') && v > 0) { n++; s += v; } return { levels: n, stars: s }; },
    getSave: async (pid) => SV.get(pid) || null,
    putSave: async (pid, d) => { SV.set(pid, d); },
    getPlayer: async (pid) => P.get(pid) || null,
    getPlayers: async (pids) => { const o = {}; pids.forEach((p) => { if (P.has(p)) o[p] = P.get(p); }); return o; },
    insertPlayer: async (d) => { P.set(d.pid, Object.assign({}, d)); },
    updatePlayer: async (pid, set) => { if (P.has(pid)) Object.assign(P.get(pid), set); },
    deletePlayer: async (pid) => { PA.delete(pid); SV.delete(pid); for (const k of [...PL.keys()]) if (k.startsWith(pid + '|')) PL.delete(k); P.delete(pid); for (const k of [...B.keys()]) if (k.startsWith(pid + ':')) B.delete(k); for (let i = E.length - 1; i >= 0; i--) if (E[i].pid === pid) E.splice(i, 1); },
    getBest: async (pid, l) => B.get(pid + ':' + l) || 0,
    setBest: async (pid, l, s) => { B.set(pid + ':' + l, s); },
    addEvent: async (e) => { E.push(e); },
    scores: async (from, to) => { const m = new Map(); E.forEach((e) => { if (e.at >= from && e.at <= to) { const r = m.get(e.pid) || { pid: e.pid, score: 0, at: 0 }; r.score += e.delta; r.at = Math.max(r.at, e.at); m.set(e.pid, r); } }); return [...m.values()]; },
    _E: E, _P: P
  };
}
/* express router: mount with  app.use('/api/mokhtalef/lb', require('./routes/mokhtalef_lb').router({ levelsDir, db }))  */
function router(o) {
  const express = require('express'), r = express.Router();
  let lb = null;
  const get = () => lb || (lb = makeLeaderboard({ store: mongoStore(o.db()), levelsDir: o.levelsDir }));
  r.use((req, res, next) => { res.set('Cache-Control', 'no-store'); next(); });
  const wrap = (fn, src) => (req, res) => fn(src === 'q' ? req.query : req.body || {}, req.ip).then((x) => res.json(x)).catch((e) => res.status(e.code || 500).json(e.code ? Object.assign({ error: e.message }, e.left !== undefined ? { left: e.left } : {}) : { error: 'server' }));
  r.post('/save', express.json({ limit: '48kb' }), wrap((b) => get().saveData(b)));   // the progress backup is bigger than the other calls
  r.use(express.json({ limit: '4kb' }));
  r.post('/load', wrap((b) => get().loadData(b)));
  for (const [path_, fn] of [['/parent/status', 'parentStatus'], ['/parent/setup', 'parentSetup'], ['/parent/login', 'parentLogin'], ['/parent/approve', 'parentApprove'], ['/parent/recover', 'parentRecover'], ['/parent/pin', 'parentPin'], ['/parent/logout', 'parentLogout'], ['/parent/settings', 'parentSettings'], ['/parent/extra', 'parentExtra'], ['/parent/report', 'parentReport'], ['/play/beat', 'playBeat']]) r.post(path_, wrap((b) => get()[fn](b)));
  r.get('/lists', (req, res) => res.json(get().lists));
  r.get('/board', wrap((q) => get().board(q), 'q'));
  r.get('/me', wrap((q) => get().me(q), 'q'));
  r.post('/join', wrap((b, ip) => get().join(b, ip)));
  r.post('/profile', wrap((b) => get().profile(b)));
  r.post('/leave', wrap((b) => get().leave(b)));
  r.post('/result', wrap((b) => get().result(b)));
  r.post('/sync', wrap((b) => get().sync(b)));
  r.post('/prize', wrap((b) => get().prize(b)));
  return r;
}
module.exports = { makeLeaderboard, mongoStore, memoryStore, router };
