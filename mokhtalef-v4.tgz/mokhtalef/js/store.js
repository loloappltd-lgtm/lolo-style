/* مختلف — saved progress (localStorage). Old saves keep every field; new fields are only added. */
'use strict';
var KEY = 'loloMokhtalef.v1';
var DEFAULTS = {
  d: 0, lv: {}, last: 0, coins: 0, extraHints: 0, found: 0, wins: 0, perfect: 0, fast: 0, nohint: 0, hintsUsed: 0,
  gift: -1, streak: 0, snd: 1, vib: 1, fx: 1, ach: {},
  day: null,          // today's daily tasks: { k: day number, wins, found, hints, nohint, claimed: {id:1}, bonus: 0 }
  chestStars: 0,      // stars collected toward the next treasure chest
  chests: 0,          // chests opened
  miles: {},          // level-completion rewards already taken
  log: []             // reward history, newest first
};
var S = (function () {
  var d = JSON.parse(JSON.stringify(DEFAULTS));
  try { var j = JSON.parse(localStorage.getItem(KEY) || '{}'); for (var k in j) d[k] = j[k]; } catch (e) {}
  return d;
})();
function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} }
function today() { var d = new Date(); return Math.floor((d.getTime() - d.getTimezoneOffset() * 6e4) / 864e5); }
function daily() {
  var t = today();
  if (!S.day || S.day.k !== t) { S.day = { k: t, wins: 0, found: 0, hints: 0, nohint: 0, claimed: {}, bonus: 0 }; save(); }
  return S.day;
}
function addLog(icon, text, coins, extra) {
  S.log.unshift({ t: Date.now(), i: icon, x: text, c: coins || 0, e: extra || '' });
  if (S.log.length > 40) S.log.length = 40;
}
function giveCoins(n, icon, text, extra) { S.coins += n; S.coinsEarned = (S.coinsEarned || 0) + n; addLog(icon, text, n, extra); save(); }
function starsOf(n) { return (S.lv[n] && S.lv[n].s) || 0; }
function totalStars() { var t = 0; for (var k in S.lv) t += S.lv[k].s || 0; return t; }
function doneCount() { var t = 0; for (var k in S.lv) if (S.lv[k].s) t++; return t; }
function unlocked(n) { return n === 1 || starsOf(n - 1) > 0; }
