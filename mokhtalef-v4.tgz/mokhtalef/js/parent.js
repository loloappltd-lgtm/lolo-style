/* مختلف — Parental controls (التحكم الأبوي).
   Everything sensitive is decided on the server (routes/mokhtalef_lb.js): the PIN is checked there (never stored in
   clear text — only a salted scrypt hash), wrong tries are counted there, settings are saved there, play time is counted
   there and finished levels are refused there when play is not allowed. This file only shows the screens and asks. */
'use strict';
var PAR = { st: S.parC || null, token: null, exp: 0, state: 'idle', err: '', busy: {} };
function parQ(o) { var p = pf(); return Object.assign({ pid: p.pid, key: p.key }, PAR.token ? { token: PAR.token } : {}, o || {}); }
function parIn() { return !!(PAR.token && PAR.exp > Date.now()); }
function parErr(e) {
  if (!e) return 'حصلت مشكلة — جرّب تاني';
  if (e.status === 403 && /wrong/.test(e.message)) return 'الرمز غلط' + (e.left ? ' — فاضل ' + e.left + ' محاولات' : '');
  if (e.status === 429 && /locked/.test(e.message)) return 'محاولات كتير غلط — استنى ' + Math.ceil((e.left || 900) / 60) + ' دقيقة';
  if (e.status === 401) return 'انتهت جلسة ولي الأمر — ادخل تاني';
  if (e.status === 400) return 'القيمة دي مش مسموحة';
  return errText(e);
}
/* the api() helper keeps only error text; parent calls also need "left" */
function papi(path, body) {
  return fetch(API + path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, cache: 'no-store', body: JSON.stringify(body) }).then(function (r) {
    return r.json().catch(function () { return {}; }).then(function (j) { if (!r.ok) { var e = new Error(j.error || r.status); e.status = r.status; e.left = j.left; throw e; } return j; });
  });
}
function cacheStatus(st) {
  PAR.st = st; S.parC = { hasPin: st.hasPin, pinLen: st.pinLen, settings: st.settings, play: st.play, at: Date.now() }; save();
  if (st.show !== undefined && pf().show !== st.show) { pf().show = st.show; save(); }
  document.body.classList.toggle('age35', !!(st.hasPin && st.settings && st.settings.age === '3-5'));
}
function parentFetch() {
  PAR.state = 'load'; if (CUR === 'parental') renderParental();
  return ensureProfile().then(function () { return papi('/parent/status', parQ()); }).then(function (st) {
    if (PAR.token && !st.parent) { PAR.token = null; PAR.exp = 0; }
    cacheStatus(st); PAR.state = 'ok'; if (CUR === 'parental') renderParental(); return st;
  }, function (e) { PAR.state = 'err'; PAR.err = parErr(e); if (CUR === 'parental') renderParental(); throw e; });
}

/* ================= number pad (PIN, or the grown-ups question) ================= */
var PIN = null;
function pinAsk(o) {
  PIN = { v: '', o: o, busy: false };
  $('pinH').textContent = o.title; $('pinT').textContent = o.text || ''; $('pinMsg').className = 'msg'; $('pinMsg').textContent = '';
  var keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'del', '0', 'ok'];
  $('pinPad').innerHTML = keys.map(function (k) { return '<button class="pk' + (k === 'ok' ? ' ok' : k === 'del' ? ' del' : '') + '" data-k="' + k + '" aria-label="' + (k === 'del' ? 'امسح' : k === 'ok' ? 'تأكيد' : k) + '">' + (k === 'del' ? '⌫' : k === 'ok' ? ic('check') : k) + '</button>'; }).join('');
  $$('#pinPad [data-k]').forEach(function (b) { b.onclick = function () { pinKey(b.dataset.k); }; });
  pinDraw(); openOv('ovPin');
}
function pinDraw() {
  var o = PIN.o, n = o.max, h = '';
  if (o.plain) h = '<span class="pinPlain">' + (PIN.v || '…') + '</span>';
  else for (var i = 0; i < n; i++) h += '<i class="' + (i < PIN.v.length ? 'on' : '') + (i >= o.min ? ' opt' : '') + '"></i>';
  $('pinDots').innerHTML = h;
  $('pinPad').querySelector('.ok').classList.toggle('dis', PIN.v.length < o.min || PIN.busy);
}
function pinKey(k) {
  if (!PIN || PIN.busy) return; sfx.tap();
  if (k === 'del') PIN.v = PIN.v.slice(0, -1);
  else if (k === 'ok') return pinSubmit();
  else if (PIN.v.length < PIN.o.max) PIN.v += k;
  pinDraw();
  if (PIN.o.auto && PIN.v.length === PIN.o.max) pinSubmit();
}
function pinSubmit() {
  if (PIN.v.length < PIN.o.min) return;
  var v = PIN.v; PIN.busy = true; pinDraw(); $('pinMsg').className = 'msg'; $('pinMsg').innerHTML = '<span class="spin"></span>لحظة…';
  Promise.resolve().then(function () { return PIN.o.submit(v); }).then(function (next) {
    if (next && next.again) { PIN.busy = false; PIN.v = ''; if (next.title) $('pinH').textContent = next.title; if (next.text) $('pinT').textContent = next.text; $('pinMsg').className = 'msg err'; $('pinMsg').textContent = next.msg || ''; pinDraw(); return; }
    PIN.busy = false; closeOv('ovPin');
  }, function (e) { PIN.busy = false; PIN.v = ''; $('pinMsg').className = 'msg err'; $('pinMsg').textContent = typeof e === 'string' ? e : parErr(e); sfx.soft(); pinDraw(); });
}
document.addEventListener('keydown', function (e) { if (!$('ovPin').classList.contains('on')) return; if (/^[0-9]$/.test(e.key)) pinKey(e.key); else if (e.key === 'Backspace') pinKey('del'); else if (e.key === 'Enter') pinKey('ok'); });
$('pinX').onclick = function () { sfx.tap(); closeOv('ovPin'); if (PIN && PIN.o.cancel) PIN.o.cancel(); PIN = null; };

/* grown-ups question, only before a PIN exists */
function grownUp(cb) {
  var a = 12 + Math.floor(Math.random() * 18), b = 3 + Math.floor(Math.random() * 6);
  pinAsk({ title: 'للكبار بس', text: 'اكتب ناتج ' + a + ' × ' + b, min: 2, max: 3, plain: true, submit: function (v) {
    if (+v === a * b) { setTimeout(cb, 250); return; }
    a = 12 + Math.floor(Math.random() * 18); b = 3 + Math.floor(Math.random() * 6);
    return { again: true, text: 'اكتب ناتج ' + a + ' × ' + b, msg: 'مش مظبوط — جرّب السؤال ده' };
  } });
}
/* a new PIN, typed twice */
function newPin(title, done) {
  var first = '';
  pinAsk({ title: title, text: 'اختار رمز من 4 لـ 6 أرقام', min: 4, max: 6, submit: function (v) {
    if (!first) { if (/^(\d)\1+$/.test(v) || '0123456789'.indexOf(v) >= 0 || '9876543210'.indexOf(v) >= 0) return { again: true, msg: 'الرمز ده سهل قوي — اختار رمز تاني' }; first = v; return { again: true, text: 'اكتب الرمز تاني للتأكيد', msg: '' }; }
    if (v !== first) { first = ''; return { again: true, text: 'اختار رمز من 4 لـ 6 أرقام', msg: 'الرمزين مش زي بعض — ابدأ تاني' }; }
    return done(v);
  } });
}
function showRecovery(code, then) {
  $('recCode').textContent = code; $('recOk').checked = false; $('recGo').classList.add('dis'); openOv('ovRec');
  $('recOk').onchange = function () { $('recGo').classList.toggle('dis', !this.checked); };
  $('recGo').onclick = function () { if (!$('recOk').checked) return; sfx.tap(); closeOv('ovRec'); if (then) then(); };
}
function gotToken(j) { PAR.token = j.token; PAR.exp = Date.now() + (j.expiresIn || 900) * 1000 - 5000; }

/* ================= asking the parent from anywhere in the game ================= */
/* parentCheck: the PIN (checked on the server) when parental controls are on, otherwise the grown-ups question */
function parentCheck(why, cb) {
  if (parIn()) return cb();
  var go = function (st) {
    if (!st || !st.hasPin) return grownUp(cb);
    pinAsk({ title: 'موافقة ولي الأمر', text: why, min: st.pinLen || 4, max: st.pinLen || 6, auto: true, submit: function (v) { return papi('/parent/approve', parQ({ pin: v, what: 'check' })).then(function () { setTimeout(cb, 200); }); } });
  };
  if (!pf().pid) return go(null);
  parentFetch().then(go, function () { if (S.parC && S.parC.hasPin) toast('محتاجين نت عشان نتأكد من رمز ولي الأمر', 'close'); else go(null); });
}
/* every purchase: a clear yes; with parental controls on, the parent's PIN */
function approvePurchase(title, text, cb) {
  var st = PAR.st || S.parC;
  if (!(st && st.hasPin && st.settings && st.settings.buyApproval)) return ask(title, text, 'أيوه', cb);
  pinAsk({ title: 'موافقة ولي الأمر على الشراء', text: text + ' — محتاج رمز ولي الأمر', min: st.pinLen || 4, max: st.pinLen || 6, auto: true, submit: function (v) {
    return papi('/parent/approve', parQ({ pin: v, what: 'purchase' })).then(function () { setTimeout(function () { toast('ولي الأمر وافق', 'check'); cb(); }, 200); });
  } });
}

/* ================= play time (counted by the server) ================= */
var PLAY = { secs: 0, sentFound: S.found || 0, warned: false, beatT: 0 };
function guarded() { var st = PAR.st || S.parC; return !!(st && st.hasPin && pf().pid); }
function restText(play) {
  var r = play && play.reason;
  if (r === 'paused') return ['اللعب متوقف دلوقتي', 'ولي الأمر وقّف اللعب. ارتاح شوية وتعالى نكمّل بعدين!'];
  if (r === 'schedule') return ['مش وقت اللعب دلوقتي', 'وقت اللعب المسموح من ' + hm12(play.from) + ' لـ ' + hm12(play.to) + '. هستناك!'];
  return ['خلص وقت اللعب النهارده', 'لعبت كتير وبرافو عليك! تعالى بكرة نكمّل نكتشف اختلافات جديدة.'];
}
function showRest(play) {
  var t = restText(play); $('restH').textContent = t[0]; $('restT').textContent = t[1];
  openOv('ovRest'); sfx.soft();
}
$('restOk').onclick = function () { sfx.tap(); closeOv('ovRest'); if (G) { G.over = true; clearInterval(clock); } show('start'); };
$('restPar').onclick = function () { sfx.tap(); closeOv('ovRest'); if (G) { G.over = true; clearInterval(clock); } show('parental'); };
function beat(secs) {
  var f = Math.max(0, (S.found || 0) - PLAY.sentFound), sentF = S.found || 0;
  return papi('/play/beat', parQ({ secs: secs, found: f })).then(function (j) {
    PLAY.sentFound = sentF;
    if (j.play) { if (PAR.st) PAR.st.play = j.play; if (S.parC) { S.parC.play = j.play; S.parC.at = Date.now(); S.parC.playBase = PLAY.secs; save(); } }
    return j.play || { allowed: true };
  });
}
function localAllowed() {   // no internet: use the last answer from the server, counting this device's time since then
  var c = S.parC; if (!c || !c.play) return { allowed: true };
  var p = c.play; if (!p.allowed) return p;
  if (p.left !== null && p.left !== undefined && PLAY.secs - (c.playBase || 0) >= p.left) return { allowed: false, reason: 'limit' };
  return { allowed: true };
}
function playGuard(cb) {
  if (!guarded()) return cb();
  beat(0).then(function (p) { if (p.allowed) cb(); else showRest(p); }, function () { var p = localAllowed(); if (p.allowed) cb(); else showRest(p); });
}
function playFoundFlush() { if (guarded() && (S.found || 0) > PLAY.sentFound) { var s = PLAY.pend || 0; PLAY.pend = 0; beat(s).catch(function () {}); } }
setInterval(function () {
  if (CUR !== 'game' || !G || G.over || G.paused || document.hidden || !guarded()) return;
  PLAY.secs++; PLAY.pend = (PLAY.pend || 0) + 1;
  if (PLAY.pend >= 30) {
    var s = PLAY.pend; PLAY.pend = 0;
    beat(s).then(function (p) {
      if (!p.allowed && CUR === 'game' && G && !G.over) { G.paused = true; showRest(p); }
      else if (p.left !== null && p.left !== undefined && p.left <= 120 && !PLAY.warned) { PLAY.warned = true; toast('فاضل دقيقتين على وقت الراحة', 'calendar'); }
    }, function () { var p = localAllowed(); if (!p.allowed && CUR === 'game' && G && !G.over) { G.paused = true; showRest(p); } });
  }
}, 1000);

/* ================= the parental screen ================= */
function hm12(v) { var m = /^(\d\d):(\d\d)$/.exec(v || ''); if (!m) return v || ''; var h = +m[1], pm = h >= 12; h = h % 12 || 12; return ('0' + h).slice(-2) + ':' + m[2] + ' ' + (pm ? 'م' : 'ص'); }
(function fillTimes() {
  var o = ''; for (var h = 0; h < 24; h++) for (var m = 0; m < 60; m += 30) { var v = ('0' + h).slice(-2) + ':' + ('0' + m).slice(-2); o += '<option value="' + v + '">' + hm12(v) + '</option>'; }
  $('schFrom').innerHTML = o; $('schTo').innerHTML = o;
})();
function renderGate() {
  var g = $('gate'), st = PAR.st;
  if (PAR.state === 'load' && !st) { g.innerHTML = '<div class="skel"></div><div class="skel"></div><div class="skel"></div>'; return; }
  if (PAR.state === 'err' && !st) { g.innerHTML = '<img class="gKid" src="assets/ui/lolo.webp" alt=""><b class="gH">مش قادرين نوصل للسيرفر</b><p>' + PAR.err + '</p><button class="btn sec" id="gRetry2">' + ic('retry') + 'جرّب تاني</button>'; $('gRetry2').onclick = function () { sfx.tap(); parentFetch().catch(function () {}); }; return; }
  if (!st) { g.innerHTML = ''; return; }
  var kid = '<div class="gTop"><img class="gKid" src="assets/ui/s_boy.webp" alt=""><span class="gLock">' + ic('lock') + '</span></div>';
  if (!st.hasPin) {
    g.innerHTML = kid + '<div class="gRib">رمز ولي الأمر</div><p>عشان تحمي الإعدادات دي، اعمل رمز سري من 4 لـ 6 أرقام. الطفل مش هيقدر يغيّر أي حاجة من غيره.</p><button class="btn mint xl wide" id="gMake">' + ic('lock') + 'إنشاء الرمز</button><small class="gSafe">' + ic('shield') + 'الرمز بيتحفظ مشفّر على السيرفر ومحدش يقدر يشوفه</small>';
    $('gMake').onclick = function () { sfx.tap(); grownUp(function () { newPin('رمز ولي الأمر الجديد', function (v) { return papi('/parent/setup', parQ({ pin: v })).then(function (j) { gotToken(j); setTimeout(function () { showRecovery(j.recovery, function () { parentFetch().catch(function () {}); toast('اتعمل رمز ولي الأمر', 'check'); }); }, 250); }); }); }); };
    return;
  }
  if (parIn()) {
    var left = Math.max(0, Math.round((PAR.exp - Date.now()) / 1000));
    g.innerHTML = kid + '<div class="gRib on">ولي الأمر داخل</div><p>تقدر تغيّر الإعدادات دلوقتي. الخروج التلقائي بعد <b id="gLeft" dir="ltr">' + mmss(left) + '</b></p><button class="btn sec wide" id="gChange">' + ic('edit') + 'تغيير الرمز</button><button class="btn pri wide" id="gOut">' + ic('lock') + 'خروج ولي الأمر</button>';
    $('gChange').onclick = function () { sfx.tap(); newPin('الرمز الجديد', function (v) { return papi('/parent/pin', parQ({ pin: v })).then(function (j) { gotToken(j); setTimeout(function () { showRecovery(j.recovery, function () { parentFetch().catch(function () {}); toast('اتغيّر الرمز', 'check'); }); }, 250); }); }); };
    $('gOut').onclick = function () { sfx.tap(); papi('/parent/logout', parQ()).catch(function () {}); PAR.token = null; PAR.exp = 0; renderParental(); toast('خرجت من وضع ولي الأمر', 'lock'); };
    return;
  }
  var n = st.pinLen || 4, boxes = ''; for (var i = 0; i < n; i++) boxes += '<i>*</i>';
  g.innerHTML = kid + '<div class="gRib">دخول ولي الأمر</div><p>لحماية إعدادات التحكم الأبوي، يرجى إدخال رمز المرور</p><button class="gBoxes" id="gBoxes" dir="ltr" aria-label="اكتب رمز المرور">' + boxes + '</button><button class="btn mint xl wide" id="gIn">' + ic('lock') + 'دخول</button>' + (st.locked ? '<p class="msg err">محاولات كتير غلط — استنى ' + Math.ceil(st.locked / 60) + ' دقيقة</p>' : '') + '<button class="lnk gForgot" id="gForgot">نسيت رمز المرور؟</button>';
  $('gIn').onclick = $('gBoxes').onclick = function () { sfx.tap(); pinAsk({ title: 'دخول ولي الأمر', text: 'اكتب رمز المرور', min: n, max: n, auto: true, submit: function (v) { return papi('/parent/login', parQ({ pin: v })).then(function (j) { gotToken(j); setTimeout(function () { parentFetch().catch(function () {}); toast('أهلًا يا ولي الأمر', 'check'); }, 150); }); } }); };
  $('gForgot').onclick = function () { sfx.tap(); $('recIn').value = ''; $('recMsg').textContent = ''; openOv('ovRecover'); };
}
$('recIn').oninput = function () { var v = this.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 12); this.value = v.replace(/(.{4})(?=.)/g, '$1-'); };
$('recNext').onclick = function () {
  var code = $('recIn').value.replace(/-/g, ''); sfx.tap();
  if (code.length !== 12) { $('recMsg').className = 'msg err'; $('recMsg').textContent = 'رمز الاستعادة 12 حرف ورقم'; return; }
  closeOv('ovRecover');
  newPin('رمز ولي الأمر الجديد', function (v) {
    return papi('/parent/recover', parQ({ code: code, pin: v })).then(function (j) { gotToken(j); setTimeout(function () { showRecovery(j.recovery, function () { parentFetch().catch(function () {}); toast('اتغيّر الرمز — ده رمز استعادة جديد', 'check'); }); }, 250); },
      function (e) { if (e.status === 403 || e.status === 429) { setTimeout(function () { closeOv('ovPin'); openOv('ovRecover'); $('recMsg').className = 'msg err'; $('recMsg').textContent = e.status === 403 ? 'رمز الاستعادة غلط' : parErr(e); }, 50); return; } throw e; });
  });
};
function renderParental() {
  renderGate();
  var st = PAR.st, s = (st && st.settings) || {}, ok = parIn(), cols = $('parCols');
  cols.classList.toggle('locked', !ok); cols.classList.toggle('nopin', !!(st && !st.hasPin));
  $$('#parental [data-ptg]').forEach(function (b) { var k = b.dataset.ptg; b.classList.toggle('on', k === 'show' ? !!(st && st.show) : !!s[k]); b.classList.toggle('dis', !ok || k === 'kidSafe' || k === 'privacy' || (k === 'show' && !s.lbAllow)); b.classList.toggle('busy', !!PAR.busy[k]); });
  $$('#parental [data-prow="kidSafe"], #parental [data-prow="privacy"]').forEach(function (r) { r.classList.add('fixed'); });
  $('limVal').textContent = (s.limitMin || 30) + ' دقيقة';
  $('parental').querySelector('.stepper').classList.toggle('off', !s.limitOn);
  $('schFrom').value = s.from || '16:00'; $('schTo').value = s.to || '20:00';
  $('schFrom').disabled = $('schTo').disabled = !ok || !s.schedOn; $('parental').querySelector('.schRow').classList.toggle('off', !s.schedOn);
  $$('#ageRow [data-age]').forEach(function (b) { b.classList.toggle('on', s.age === b.dataset.age); b.disabled = !ok; });
  var p = st && st.play, u = $('parUsage');
  if (!st || !st.hasPin) u.innerHTML = '';
  else {
    var used = Math.round(((p && p.used) || 0) / 60);
    u.innerHTML = '<span>' + ic('calendar') + 'النهارده: <b>' + used + '</b> دقيقة لعب' + (p && p.left !== null && p.left !== undefined ? ' · فاضل <b>' + Math.ceil(p.left / 60) + '</b> دقيقة' : '') + '</span>' + (p && !p.allowed ? '<em class="stopT">' + restText(p)[0] + '</em>' : '') + (ok ? '<button class="btn sm sec" id="parExtra">+15 دقيقة النهارده</button>' : '');
    var ex = $('parExtra'); if (ex) ex.onclick = function () { sfx.tap(); parSave(null, null, { extra: 15 }); };
  }
  var syncOff = st && st.hasPin && s.sync === false; $('parSyncNow').classList.toggle('dis', !!syncOff);
  updPills();
}
var parMsgT = 0;
function parMsg(t, cls) { var m = $('parMsg'); m.className = 'parMsg ' + (cls || ''); m.innerHTML = t; clearTimeout(parMsgT); if (cls !== 'load') parMsgT = setTimeout(function () { m.textContent = ''; m.className = 'parMsg'; }, 3500); }
function needIn() { if (parIn()) return true; sfx.soft(); toast(PAR.st && !PAR.st.hasPin ? 'اعمل رمز ولي الأمر الأول' : 'ادخل كولي أمر الأول', 'lock'); var g = $('gate'); g.classList.remove('shake'); void g.offsetWidth; g.classList.add('shake'); return false; }
/* every change is saved on the server right away; on failure the screen goes back to what the server has */
function parSave(key, patch, extra) {
  if (!needIn()) return;
  if (key) PAR.busy[key] = 1; parMsg('<span class="spin"></span>بنحفظ…', 'load'); renderParental();
  var call = extra ? papi('/parent/extra', parQ({ min: extra.extra })) : papi('/parent/settings', parQ({ set: patch }));
  return call.then(function (j) {
    if (key) delete PAR.busy[key];
    if (j.settings) PAR.st.settings = j.settings; if (j.play) PAR.st.play = j.play; if (j.show !== undefined) PAR.st.show = j.show;
    cacheStatus(PAR.st); renderParental(); parMsg(ic('check') + (extra ? 'زودنا 15 دقيقة النهارده' : 'اتحفظ'), 'ok'); sfx.ok();
  }, function (e) {
    if (key) delete PAR.busy[key];
    if (e.status === 401) { PAR.token = null; PAR.exp = 0; }
    renderParental(); parMsg(ic('close') + parErr(e), 'err'); sfx.soft();
  });
}
$$('#parental [data-ptg]').forEach(function (b) {
  b.onclick = function () {
    var k = b.dataset.ptg, s = (PAR.st && PAR.st.settings) || {};
    if (k === 'kidSafe') { sfx.soft(); return toast('كل محتوى اللعبة مناسب للأطفال — ده مش ممكن يتقفل', 'shield'); }
    if (k === 'privacy') { sfx.soft(); return toast('مفيش محادثات ولا جمع بيانات شخصية — دايمًا', 'shield'); }
    if (!needIn() || PAR.busy[k]) return; sfx.tap();
    if (k === 'show') { if (!s.lbAllow) return toast('فعّل «الترتيب والمنافسات» الأول', 'lock'); return parSave(k, { show: !PAR.st.show }); }
    var patch = {}; patch[k] = !s[k]; parSave(k, patch);
  };
});
var limT = 0;
function limStep(d) {
  if (!needIn()) return; var s = PAR.st.settings; if (!s.limitOn) return toast('فعّل حد الوقت الأول', 'calendar');
  var v = Math.max(5, Math.min(240, (s.limitMin || 30) + d)); if (v === s.limitMin) return; sfx.tap();
  s.limitMin = v; $('limVal').textContent = v + ' دقيقة';
  clearTimeout(limT); limT = setTimeout(function () { parSave('limitMin', { limitMin: v }); }, 700);
}
$('limMinus').onclick = function () { limStep(-5); }; $('limPlus').onclick = function () { limStep(5); };
$('schFrom').onchange = $('schTo').onchange = function () {
  if ($('schFrom').value === $('schTo').value) { toast('وقت البداية والنهاية لازم يختلفوا', 'close'); return renderParental(); }
  parSave('sched', { from: $('schFrom').value, to: $('schTo').value });
};
$$('#ageRow [data-age]').forEach(function (b) { b.onclick = function () { if (!needIn()) return; sfx.tap(); parSave('age', { age: b.dataset.age }); }; });
$('parPrivInfo').onclick = function () { sfx.tap(); openPrivacy(); };
$('parSyncNow').onclick = function () { sfx.tap(); if (this.classList.contains('dis')) return toast('المزامنة مقفولة', 'lock'); cloudSync(); parMsg('<span class="spin"></span>بنزامن…', 'load'); var w = setInterval(function () { if (SYNC.state !== 'load') { clearInterval(w); parMsg((SYNC.state === 'ok' ? ic('check') : ic('close')) + SYNC.msg, SYNC.state === 'ok' ? 'ok' : 'err'); } }, 300); };
/* activity report */
var AR_DAYS = ['الأحد', 'الاتنين', 'التلات', 'الأربع', 'الخميس', 'الجمعة', 'السبت'];
$('parRepB').onclick = function () {
  if (!needIn()) return; sfx.tap();
  $('repBody').innerHTML = '<div class="skel"></div><div class="skel"></div><div class="skel"></div>'; openOv('ovReport');
  papi('/parent/report', parQ()).then(function (r) {
    var max = Math.max.apply(null, r.days.map(function (d) { return d.secs; }).concat([60]));
    var bars = r.days.map(function (d) {
      var p = d.day.split('-'), dt = new Date(Date.UTC(+p[0], +p[1] - 1, +p[2])), m = Math.round(d.secs / 60);
      return '<div class="rBar"><small dir="ltr">' + m + '</small><i style="height:' + Math.max(4, d.secs / max * 100) + '%"></i><b>' + AR_DAYS[dt.getUTCDay()] + '</b></div>';
    }).join('');
    $('repBody').innerHTML = '<div class="repChips"><div class="chip2">' + ic('calendar') + '<b dir="ltr">' + Math.round(r.week.secs / 60) + '</b><small>دقيقة لعب في 7 أيام</small></div><div class="chip2 y">' + ic('flag') + '<b dir="ltr">' + r.week.levels + '</b><small>مرحلة جديدة في 7 أيام</small></div><div class="chip2 c">' + ic('search') + '<b dir="ltr">' + r.week.found + '</b><small>اختلاف اتكشف في 7 أيام</small></div></div>'
      + '<h3 class="edH">وقت اللعب كل يوم (دقايق)</h3><div class="rBars">' + bars + '</div>'
      + '<div class="repTot"><span>' + ic('check') + 'المراحل المكتملة كلها: <b dir="ltr">' + r.total.levels + '</b></span><span>' + ic('star', 'starI') + 'النجوم: <b dir="ltr">' + r.total.stars + '</b></span><span>' + ic('search') + 'الاختلافات المكتشفة: <b dir="ltr">' + r.total.found + '</b></span></div>'
      + '<p class="safe">' + ic('shield') + 'التقرير ده من السيرفر ولولي الأمر بس — ومفيهوش أي بيانات شخصية.</p>';
  }, function (e) { if (e.status === 401) { PAR.token = null; PAR.exp = 0; renderParental(); } $('repBody').innerHTML = '<div class="emptyBox"><img src="assets/ui/lolo.webp" alt=""><b>مش قادرين نجيب التقرير</b><small>' + parErr(e) + '</small></div>'; });
};
var parTick = 0;
SCREENS.parental = function () {
  renderParental(); parentFetch().catch(function () {});
  clearInterval(parTick); parTick = setInterval(function () {
    if (CUR !== 'parental') return clearInterval(parTick);
    if (PAR.token && PAR.exp <= Date.now()) { PAR.token = null; PAR.exp = 0; renderParental(); toast('خرجنا من وضع ولي الأمر تلقائيًا', 'lock'); }
    var l = $('gLeft'); if (l) l.textContent = mmss(Math.max(0, Math.round((PAR.exp - Date.now()) / 1000)));
  }, 1000);
};
/* boot: know early whether parental controls are on (for the play-time rules and purchases) */
if (pf().pid) parentFetch().catch(function () {});
if (S.parC) document.body.classList.toggle('age35', !!(S.parC.hasPin && S.parC.settings && S.parC.settings.age === '3-5'));
