/* مختلف — game settings: every reward value lives here, so it can be changed without touching the game code.
   coins = عملات, stars = نجوم مكافأة (تتضاف لرصيد النجوم), hints = تلميحات زيادة */
'use strict';
var CONFIG = {
  timeZone: 'Africa/Cairo',             // the day (daily tasks, daily box, login streak) starts at midnight in this zone, using the server clock
  hintPrice: 20,                        // coins for one extra hint
  level: { firstCoins: 10, perExtraStar: 5, fast: 5, noHint: 5, replayCoins: 2, replayNewStar: 5 },
  dailyTasks: [
    { id: 'win3', img: 't_i1', name: 'أكمل 3 مراحل', desc: 'خلّص أي 3 مراحل النهارده', stat: 'wins', goal: 3, coins: 30, stars: 2, go: 'play' },
    { id: 'find10', img: 't_i2', name: 'اكتشف 10 اختلافات', desc: 'دوّر ولاقي 10 اختلافات في أي مراحل', stat: 'found', goal: 10, coins: 20, stars: 2, go: 'play' },
    { id: 'hint1', img: 't_i3', name: 'استخدم التلميح مرة واحدة', desc: 'دوس على زرار التلميح جوه أي مرحلة', stat: 'hints', goal: 1, coins: 15, stars: 1, go: 'hint' },
    { id: 'nohint', img: 't_i4', name: 'أكمل مرحلة دون استخدام تلميح', desc: 'خلّص مرحلة كاملة من غير ولا تلميح', stat: 'nohint', goal: 1, coins: 25, stars: 2, go: 'play' }
  ],
  dailyBonus: { coins: 100, stars: 5, hints: 1 },   // after all daily tasks are claimed
  dailyBox: { coins: 15, stars: 1 },                // once a day
  loginStreak: [                                     // day 1 … day 7, then it starts again
    { coins: 20 }, { coins: 50 }, { stars: 2 }, { coins: 100 }, { hints: 1, coins: 30 }, { stars: 3 }, { coins: 150, stars: 5 }
  ],
  chest: { stars: 5, minCoins: 20, maxCoins: 50, hintEvery: 3 },
  world: { coins: 300, stars: 10, hints: 2 },        // finishing all 10 levels of a world
  levelMilestones: [{ n: 5, coins: 30 }, { n: 10, coins: 60 }, { n: 25, coins: 120 }, { n: 50, coins: 250 }, { n: 75, coins: 350 }, { n: 100, coins: 500 }]
};