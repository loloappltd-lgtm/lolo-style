/* مختلف — screens: start, levels, tasks, rewards, settings; boot */
'use strict';
/* ---------- start ---------- */
function renderStart() {
  var n = doneCount();
  $('stDone').textContent = n; $('stTot').textContent = TOTAL;
  $('stBar').style.width = (n / TOTAL * 100) + '%';
  var avg = n ? totalStars() / n : 0, k = Math.round(avg);
  $$('#stStars .st').forEach(function (e, i) { e.classList.toggle('on', i < k); });
  var c = continueLevel(), b = $('stCont');
  if (c.n && (n > 0 || S.last)) { b.style.display = ''; $('stContN').textContent = c.n; b.dataset.n = c.n; }
  else b.style.display = 'none';
  $$('.dcard').forEach(function (e) { e.classList.toggle('sel', +e.dataset.d === S.d); });
  renderSidePanels(); updPills();
  $$('[data-chest]').forEach(function (x) { x.onclick = openChest; });
}
SCREENS.start = renderStart;
$('stDiff').innerHTML = RANGES.map(function (r, i) {
  return '<button class="dcard ' + r.cls + '" data-d="' + i + '"><img src="assets/ui/' + r.img + '.webp" alt=""><b>' + r.name + '</b><small>' + r.diffs + '</small><span class="dst">' + '<svg class="st on"><use href="#i-star"/></svg>'.repeat(i + 1) + '</span></button>';
}).join('');
$$('.dcard').forEach(function (b) { b.onclick = function () { S.d = +b.dataset.d; save(); sfx.tap(); renderStart(); }; });
$('stPlay').onclick = function () {
  sfx.tap(); var r = RANGES[S.d], x = nextIn(r);
  if (x.n) return startLevel(x.n);
  if (x.locked) { toast('خلّص المراحل اللي قبل ' + x.locked + ' الأول', 'lock'); return show('worlds'); }
  if (x.soon) { toast('مراحل «' + r.name + '» الجديدة جاية قريب', 'star'); return show('worlds'); }
  toast('خلّصت كل مراحل «' + r.name + '»', 'trophy'); show('worlds');
};
$('stCont').onclick = function () { sfx.tap(); startLevel(+this.dataset.n); };

/* ---------- worlds (10 worlds × 10 levels) and the levels of one world ---------- */
var WORLDS = ['عالم الحديقة', 'عالم البحار', 'عالم المطبخ', 'عالم الملاهي', 'عالم الفضاء', 'عالم الديناصورات', 'عالم الثلج', 'عالم الممالك', 'عالم الروبوتات', 'عالم السحر'];
var LV_W = 0, LV_WANT = 0;
function wFrom(w) { return w * 10 + 1; }
function wStars(w) { var t = 0; for (var n = wFrom(w); n < wFrom(w) + 10; n++) t += starsOf(n); return t; }
function wDone(w) { for (var n = wFrom(w); n < wFrom(w) + 10; n++) if (!starsOf(n)) return false; return true; }
function wDoneCount(w) { var t = 0; for (var n = wFrom(w); n < wFrom(w) + 10; n++) if (starsOf(n)) t++; return t; }
/* a world opens only when all 10 levels of the world before it are finished */
function wOpen(w) { return w === 0 || wDone(w - 1); }
function curWorld() { var c = continueLevel().n || 1; return Math.min(9, Math.floor((c - 1) / 10)); }
var RANKS = [{ n: 0, t: 'مستكشف صغير' }, { n: 5, t: 'مستكشف شاطر' }, { n: 20, t: 'مستكشف ماهر' }, { n: 50, t: 'خبير الاختلافات' }, { n: 90, t: 'بطل مختلف' }];
function rankName() { var d = doneCount(), r = RANKS[0]; RANKS.forEach(function (x) { if (d >= x.n) r = x; }); return r.t; }
function sideCommon() {
  var d = doneCount();
  $$('[data-done]').forEach(function (e) { e.textContent = d; });
  $$('[data-allbar]').forEach(function (e) { e.style.width = (d / TOTAL * 100) + '%'; });
  if ($('rankN')) { $('rankN').textContent = rankName(); $('lvDone').textContent = d; $('lvBar').style.width = (d / TOTAL * 100) + '%'; }
  updPills();
}
function renderWorlds() {
  sideCommon(); var cw = curWorld();
  $('wgrid').innerHTML = WORLDS.map(function (name, w) {
    var open = wOpen(w), st = wStars(w), any = false;
    for (var n = wFrom(w); n < wFrom(w) + 10; n++) if (hasLevel(n)) any = true;
    return '<button class="wcard' + (w === cw ? ' cur' : open ? ' open' : ' lock') + (wDone(w) ? ' done' : '') + '" data-w="' + w + '">' +
      '<span class="wImg"><img src="assets/worlds/w' + ('0' + (w + 1)).slice(-2) + '.webp" alt="" loading="lazy"><span class="wNum">' + (w + 1) + '</span></span>' +
      '<span class="wName">' + name + '</span><span class="wRange"><span dir="ltr">' + wFrom(w) + ' - ' + (wFrom(w) + 9) + '</span></span>' +
      '<span class="wProg">' + (open ? '<svg class="st on"><use href="#i-star"/></svg>' : ic('lock', 'lockI')) + '<span class="bar"><i style="width:' + (wDoneCount(w) * 10) + '%"></i><span>' + st + ' / 30</span></span><b class="pct">' + (wDoneCount(w) * 10) + '%</b></span>' + (open ? '' : '<span class="wLock">' + ic('lock') + '</span>') +
      (open && !any ? '<span class="wSoon">قريبًا</span>' : '') + '</button>';
  }).join('');
  $$('#wgrid .wcard').forEach(function (b) {
    b.onclick = function () { var w = +b.dataset.w; if (!wOpen(w)) { sfx.soft(); return toast('خلّص ' + WORLDS[w - 1] + ' الأول عشان يفتح', 'lock'); } sfx.tap(); LV_W = w; LV_SEL = 0; show('levels'); };
  });
}
SCREENS.worlds = renderWorlds;
/* ---------- world map: 10 stops on a winding path ---------- */
var STOPS = [[13, 44], [28, 42], [42, 43], [56, 39], [70, 43], [73, 66], [59, 73], [45, 75], [31, 73], [17, 70]];
var THEMES = ['#DCEFD9', '#D5ECF4', '#F8E7DA', '#F6E3EE', '#DCD6F2', '#E1EFD3', '#E4F1F7', '#EDE4F7', '#DDE8F2', '#E6DDF4'];
var LV_SEL = 0;
function thumb(n) { var w = Math.floor((n - 1) / 10); return hasLevel(n) ? 'levels/' + lid(n) + '/a.webp' : 'assets/worlds/w' + ('0' + (w + 1)).slice(-2) + '.webp'; }
function pathD() {
  var p = STOPS, d = 'M' + p[0][0] + ' ' + p[0][1];
  for (var i = 1; i < p.length; i++) { var a = p[i - 1], b = p[i], mx = (a[0] + b[0]) / 2, my = (a[1] + b[1]) / 2; d += ' Q' + a[0] + ' ' + a[1] + ' ' + mx + ' ' + my; }
  var l = p[p.length - 1]; return d + ' T' + l[0] + ' ' + l[1] + ' L6 76';
}
function nodeState(n, cur) { if (!hasLevel(n)) return unlocked(n) ? 'soon' : 'lock'; if (starsOf(n)) return 'done'; if (n === cur) return 'cur'; return unlocked(n) ? 'cur' : 'lock'; }
function renderMap() {
  sideCommon();
  if (LV_WANT) { LV_WANT = 0; LV_W = curWorld(); LV_SEL = 0; }
  var w = LV_W, f = wFrom(w), cur = continueLevel().n || 0;
  if (!LV_SEL || LV_SEL < f || LV_SEL > f + 9) { LV_SEL = (cur >= f && cur <= f + 9) ? cur : f; if (!unlocked(LV_SEL) && wOpen(w)) LV_SEL = f; }
  $('mTitle').textContent = WORLDS[w]; $('mRange').textContent = f + ' - ' + (f + 9);
  var img = 'assets/worlds/w' + ('0' + (w + 1)).slice(-2) + '.webp';
  $('mapBg').style.backgroundImage = 'url(' + img + ')'; $('mapArea').style.setProperty('--theme', THEMES[w]);
  $('mapArea').classList.toggle('garden', w === 0);
  $('mapDeco').innerHTML = w === 0 ? '<img class="d1" src="assets/ui/m_house.webp" alt=""><img class="d2" src="assets/ui/m_lolo.webp" alt=""><img class="d3" src="assets/ui/m_bunny.webp" alt=""><img class="d4" src="assets/ui/m_squirrel.webp" alt=""><img class="d5" src="assets/ui/m_sign.webp" alt="">'
    : '<img class="d2" src="assets/ui/m_lolo.webp" alt=""><img class="d6" src="' + img + '" alt="">';
  var d = pathD(); $('mPathEdge').setAttribute('d', d); $('mPathMain').setAttribute('d', d);
  var h = '';
  for (var k = 0; k < 10; k++) {
    var n = f + k, st = nodeState(n, cur), s = starsOf(n), stars = '';
    for (var i = 0; i < 3; i++) stars += '<svg class="st' + (i < s ? ' on' : '') + '"><use href="#i-star"/></svg>';
    h += '<button class="node ' + st + (n === LV_SEL ? ' sel' : '') + '" data-n="' + n + '" style="left:' + STOPS[k][0] + '%;top:' + STOPS[k][1] + '%" aria-label="المرحلة ' + (k + 1) + '">' +
      '<span class="nb"><b>' + (k + 1) + '</b>' + (st === 'cur' ? ic('play', 'playI') : st === 'lock' ? ic('lock', 'lockI') : st === 'soon' ? '<small>قريبًا</small>' : '') + '</span>' +
      (st === 'done' ? '<span class="ok">' + ic('check') + '</span><span class="nst">' + stars + '</span>' : '') + '</button>';
  }
  $('mNodes').innerHTML = h;
  $$('#mNodes .node').forEach(function (b) {
    b.onclick = function () {
      var n = +b.dataset.n;
      if (b.classList.contains('lock')) { sfx.soft(); b.classList.remove('nope'); void b.offsetWidth; b.classList.add('nope'); return toast('خلّص المرحلة ' + ((n - 1) % 10 || 10) + ' الأول', 'lock'); }
      if (b.classList.contains('soon')) { sfx.soft(); return toast('المرحلة دي جاية قريب', 'star'); }
      sfx.tap(); LV_SEL = n; renderMap();
    };
    b.ondblclick = function () { var n = +b.dataset.n; if (hasLevel(n) && unlocked(n)) startLevel(n); };
  });
  // side panel: world progress, world reward, preview + chosen stop
  var ws = wStars(w), dc = wDoneCount(w);
  $('mBar').style.width = (ws / 30 * 100) + '%'; $('mBarT').textContent = ws + ' / 30'; $('mDone').textContent = dc + ' من 10 مراحل';
  var got = S.worlds && S.worlds[w];
  $('mGift').classList.toggle('got', !!got); $('mGiftT').textContent = got ? 'خدتها! ' + rewardText(CONFIG.world) : 'خلّص الـ10 مراحل: ' + rewardText(CONFIG.world);
  var n = LV_SEL, loc = (n - 1) % 10 + 1, sst = starsOf(n), ok = hasLevel(n) && unlocked(n), rec = S.lv[n];
  $('mPrevImg').src = hasLevel(n) ? thumb(n) : img;
  var sstars = ''; for (var i = 0; i < 3; i++) sstars += '<svg class="st' + (i < sst ? ' on' : '') + '"><use href="#i-star"/></svg>';
  $('mSel').innerHTML = '<b>المرحلة ' + loc + '</b><span class="sst">' + sstars + '</span>' + (rec && rec.score ? '<small>أحسن نتيجة: ' + fmtNum(rec.score) + '</small>' : '<small>' + (ok ? 'جاهزة تلعبها' : hasLevel(n) ? 'مقفولة' : 'قريبًا') + '</small>');
  if (hasLevel(n)) loadLevel(n).then(function (L) { if (LV_SEL !== n) return; var x = $('mSel').querySelector('small'); if (x && !(rec && rec.score)) x.textContent = (L.scene ? L.scene + ' · ' : '') + L.differences.length + ' اختلافات'; }, function () {});
  $('mStartT').textContent = (sst ? 'العب تاني المرحلة ' : 'ابدأ المرحلة ') + loc;
  $('mStart').classList.toggle('dis', !ok);
  $('lvPrev').classList.toggle('dis', w === 0);
  $('lvNext').classList.toggle('dis', w === 9 || !wOpen(w + 1));
}
$('mStart').onclick = function () { var n = LV_SEL; if (!hasLevel(n) || !unlocked(n)) { sfx.soft(); return toast(hasLevel(n) ? 'المرحلة دي لسه مقفولة' : 'المرحلة دي جاية قريب', 'lock'); } sfx.tap(); startLevel(n); };
var renderLevels = renderMap;
function lvStep(dir) { var w = LV_W + dir; if (w < 0 || w > 9) return; if (!wOpen(w)) { sfx.soft(); return toast(WORLDS[w] + ' لسه مقفول — خلّص ' + WORLDS[w - 1] + ' الأول', 'lock'); } sfx.tap(); LV_W = w; LV_SEL = 0; renderMap(); }
$('lvPrev').onclick = function () { lvStep(-1); };
$('lvNext').onclick = function () { lvStep(1); };
function gotoCurrentPage() { LV_WANT = 1; }
/* finishing all 10 levels of a world: congratulations + reward, given once */
function checkWorldDone(n) {
  var w = Math.floor((n - 1) / 10); S.worlds = S.worlds || {};
  if (!wDone(w) || S.worlds[w]) return false;
  S.worlds[w] = 1; grant(CONFIG.world, 'trophy', 'إكمال ' + WORLDS[w]);
  $('wdName').textContent = WORLDS[w]; $('wdImg').src = 'assets/worlds/w' + ('0' + (w + 1)).slice(-2) + '.webp';
  $('wdStars').textContent = wStars(w) + ' / 30';
  $('wdNext').style.display = w < 9 ? '' : 'none'; $('wdNextN').textContent = w < 9 ? WORLDS[w + 1] : '';
  $('wdNext').onclick = function () { sfx.tap(); closeOv('ovWorld'); closeOv('ovWin'); LV_W = w + 1; LV_SEL = 0; show('levels'); };
  return true;
}
SCREENS.levels = renderMap;
$('stLevels').onclick = function () { sfx.tap(); show('worlds'); };
document.addEventListener('click', function (e) {
  var nv = e.target.closest('[data-nav]'); if (nv) { sfx.tap(); var t = nv.dataset.nav; if (t === 'map') { gotoCurrentPage(); show('levels'); } else show(t); }
  if (e.target.closest('[data-ach]')) { sfx.tap(); show('achievements'); }
  if (e.target.closest('[data-rank]')) { sfx.tap(); show('leaderboard'); }
  if (e.target.closest('[data-set]')) { sfx.tap(); show('settings'); }
});

/* ---------- tasks & rewards ---------- */
SCREENS.tasks = function () { renderTasks(); tickTasks(); clearInterval(tkTimer); tkTimer = setInterval(function () { if (CUR === 'tasks') tickTasks(); else clearInterval(tkTimer); }, 1000); };
SCREENS.achievements = function () { renderAchievements(); };
SCREENS.rewards = function () { renderRewards(); refreshMeta(); };

/* ---------- settings ---------- */
$('stSet').onclick = function () { sfx.tap(); show('settings'); };

/* ---------- boot ---------- */
var READY = false;
getJSON('levels/index.json').then(function (j) { IDX = j.levels || []; TOTAL = j.total || 100; }, function () { IDX = []; toast('النت ضعيف — بعض المراحل مش هتظهر', 'close'); }).then(function () {
  READY = true; recordLogin(); daily(); show('start');
  document.body.classList.add('ready');
});
window.MOKHTALEF = { checkWorldDone: function (n) { return checkWorldDone(n); }, wOpen: function (w) { return wOpen(w); }, setIdx: function (a) { IDX = a; }, S: S, get G() { return G; }, startLevel: startLevel, show: show, hitTest: function (x, y) { return hitTest({ x: x, y: y }); } };
