/* مختلف — player profile (game profile, nickname + ready-made avatar only) and the leaderboard.
   Nothing personal is ever asked or shown: no real name, email, phone, country, location, photos or chat.
   The player appears in the leaderboard only after agreeing (show = true), and can hide or delete it any time. */
'use strict';
var API = '/api/mokhtalef/lb';
var NICK_A = ['النجم', 'البطل', 'المحقق', 'الصقر', 'القمر', 'الفراشة', 'الكابتن', 'النحلة', 'الأسد', 'الدلفين', 'الأميرة', 'الفارس', 'الكوكب', 'الشمس', 'الوردة', 'السنجاب'];
var NICK_B = ['الذكي', 'السريع', 'اللامع', 'الشجاع', 'المرح', 'الهادي', 'الشاطر', 'البطل', 'الصغير', 'المبدع', 'المكتشف', 'الطيّب'];
var AVATARS = [{ id: 'lolo', n: 'لولو' }, { id: 'boy', n: 'ولد' }, { id: 'girl', n: 'بنت' }, { id: 'bunny', n: 'أرنوب' }, { id: 'squirrel', n: 'سنجاب' }, { id: 'turtle', n: 'سلحفاة' }, { id: 'penguin', n: 'بطريق' }, { id: 'robot', n: 'روبوت' }, { id: 'dino', n: 'ديناصور' }, { id: 'rocket', n: 'صاروخ' }];
function avSrc(id) { return 'assets/avatars/' + (AVATARS.some(function (a) { return a.id === id; }) ? id : 'lolo') + '.webp'; }
function pf() {
  if (!S.pf) { S.pf = { nick: NICK_A[Math.floor(Math.random() * NICK_A.length)] + ' ' + NICK_B[Math.floor(Math.random() * NICK_B.length)], av: 'lolo', show: false }; save(); }
  return S.pf;
}
/* ---------- server calls ---------- */
function api(method, path, body) {
  var ctl = window.AbortController ? new AbortController() : null, t = setTimeout(function () { if (ctl) ctl.abort(); }, 9000);
  var o = { method: method, headers: { 'Content-Type': 'application/json' }, cache: 'no-store' }; if (ctl) o.signal = ctl.signal;
  if (body) o.body = JSON.stringify(body);
  return fetch(API + path, o).then(function (r) { clearTimeout(t); return r.json().catch(function () { return {}; }).then(function (j) { if (!r.ok) { var e = new Error(j.error || r.status); e.status = r.status; throw e; } return j; }); }, function (e) { clearTimeout(t); throw e; });
}
function q(o) { return '?' + Object.keys(o).filter(function (k) { return o[k] !== undefined && o[k] !== null; }).map(function (k) { return k + '=' + encodeURIComponent(o[k]); }).join('&'); }
function errText(e) { return e && e.status === 429 ? 'استنى ثواني وجرّب تاني' : e && e.status === 401 ? 'ملفك على السيرفر مش موجود — احفظه تاني' : 'مفيش اتصال بالسيرفر — جرّب تاني'; }
/* create the game profile on the server once (hidden from the leaderboard until the player agrees), then send finished levels */
function ensureProfile() {
  var p = pf();
  if (p.pid && p.key) return Promise.resolve(p);
  return api('POST', '/join', { nick: p.nick, av: p.av, show: !!p.show }).then(function (j) { p.pid = j.pid; p.key = j.key; save(); return syncLevels().then(function () { return p; }, function () { return p; }); });
}
function syncLevels() {
  var p = pf(); if (!p.pid) return Promise.resolve();
  var list = []; for (var n = 1; n <= 100; n++) { var r = S.lv[n]; if (!r || !r.s) break; list.push({ level: n, stars: r.s, time: Math.max(r.t || 0, 30) }); }
  return api('POST', '/sync', { pid: p.pid, key: p.key, levels: list, ach: Object.keys(S.ach || {}).length, lvl: playerXP().lvl });
}
/* after a finished level (called by the game) */
function sendResult(n, stars, secs, hints) {
  var p = pf(); if (!p.pid) return;
  api('POST', '/result', { pid: p.pid, key: p.key, level: n, stars: stars, time: secs, hints: hints, ach: Object.keys(S.ach || {}).length, lvl: playerXP().lvl }).catch(function (e) {
    if (e.status === 409) syncLevels().catch(function () {});
    if (e.status === 401) { delete p.pid; delete p.key; save(); }
  });
}
function forgetServer() { var p = pf(); delete p.pid; delete p.key; p.show = false; save(); }

/* ================= PROFILE ================= */
var PF_RANK = { state: 'idle', val: null };
function renderProfile() {
  var p = pf(), X = playerXP();
  $('pfAv').src = avSrc(p.av); $('pfNick').textContent = p.nick; $('pfLvl').textContent = X.lvl;
  $('pfXpBar').style.width = (X.cur / X.need * 100) + '%'; $('pfXpT').textContent = fmtNum(X.cur) + ' / ' + fmtNum(X.need);
  var wd = ACH_STATS.worldsDone(), rank = PF_RANK.state === 'ok' ? (PF_RANK.val ? fmtNum(PF_RANK.val) : '—') : PF_RANK.state === 'load' ? '…' : PF_RANK.state === 'err' ? '!' : '—';
  $('pfStats').innerHTML = [
    ['c_play', 'المراحل المكتملة', doneCount() + ' / 100'], ['n_globe', 'العوالم المكتملة', wd + ' / 10'], ['coin', 'العملات', fmtNum(S.coins)],
    ['star', 'النجوم', fmtNum(starBal())], ['crown', 'ترتيبي الحالي', rank, 'rank'], ['calendar', 'أيام اللعب', fmtNum(S.loginDays || 1)]
  ].map(function (r) { return '<div class="pfStat' + (r[3] ? ' ' + r[3] : '') + '">' + (r[0].indexOf('_') > 0 ? '<img src="assets/ui/' + r[0] + '.webp" alt="">' : ic(r[0], r[0] === 'coin' ? 'coinI' : r[0] === 'star' ? 'starI' : r[0] === 'crown' ? 'crownI' : '')) + '<small>' + r[1] + '</small><b dir="ltr">' + r[2] + '</b></div>'; }).join('');
  var rk = $('pfStats').querySelector('.rank'); if (rk) rk.onclick = function () { sfx.tap(); if (!pf().show) return openPrivacy(); loadRank(); };
  // latest badges first, then the closest ones
  var got = ACHIEVEMENTS.filter(function (b) { return S.ach[b.id]; }).sort(function (a, b) { return ((S.achAt || {})[b.id] || 0) - ((S.achAt || {})[a.id] || 0); });
  var rest = ACHIEVEMENTS.filter(function (b) { return !S.ach[b.id] && !b.future; }).sort(function (a, b) { return badgeVal(b) / b.goal - badgeVal(a) / a.goal; });
  var show5 = got.concat(rest).slice(0, 5);
  $('pfBadges').innerHTML = show5.map(function (b) { var g = !!S.ach[b.id]; return '<div class="pfB' + (g ? ' got' : '') + '"><img src="assets/ui/' + b.img + '.webp" alt=""><b>' + b.name + '</b><small dir="ltr">' + (g ? '✓' : Math.round(badgeVal(b) / b.goal * 100) + '%') + '</small></div>'; }).join('');
  $('pfWorlds').innerHTML = WORLDS.map(function (n, w) {
    var dc = wDoneCount(w), open = wOpen(w);
    return '<button class="pfW' + (wDone(w) ? ' done' : open ? ' open' : ' lock') + '" data-w="' + w + '"><img src="assets/worlds/w' + ('0' + (w + 1)).slice(-2) + '.webp" alt="">' + (open ? '' : '<span class="aLock">' + ic('lock') + '</span>') + '<b>' + n + '</b><span class="bar"><i style="width:' + dc * 10 + '%"></i><span dir="ltr">' + dc + ' / 10</span></span></button>';
  }).join('');
  $$('#pfWorlds .pfW').forEach(function (b) { b.onclick = function () { var w = +b.dataset.w; if (!wOpen(w)) { sfx.soft(); return toast(WORLDS[w] + ' لسه مقفول', 'lock'); } sfx.tap(); LV_W = w; LV_SEL = 0; show('levels'); }; });
  $('pfPrivT').textContent = p.show ? 'ظاهر في الترتيب باسمك المستعار' : 'مخفي من الترتيب';
  updPills();
}
function loadRank() {
  var p = pf();
  if (!p.pid || !p.show) { PF_RANK = { state: 'idle', val: null }; return renderProfile(); }
  PF_RANK = { state: 'load', val: null }; renderProfile();
  api('GET', '/me' + q({ pid: p.pid, key: p.key })).then(function (j) { PF_RANK = { state: 'ok', val: j.ranks && j.ranks.all }; if (CUR === 'profile') renderProfile(); },
    function (e) { PF_RANK = { state: 'err', val: null }; if (CUR === 'profile') renderProfile(); if (e.status === 401) forgetServer(); });
}
SCREENS.profile = function () { renderProfile(); loadRank(); };
/* ---------- edit profile: ready-made avatars + nickname from word lists ---------- */
var ED = null;
function openEdit() {
  var p = pf(), parts = p.nick.split(' ');
  ED = { av: p.av, a: NICK_A.indexOf(parts[0]) >= 0 ? parts[0] : NICK_A[0], b: NICK_B.indexOf(parts[1]) >= 0 ? parts[1] : NICK_B[0] };
  renderEdit(); $('edMsg').textContent = ''; openOv('ovEdit');
}
function renderEdit() {
  $('edAvs').innerHTML = AVATARS.map(function (a) { return '<button class="avB' + (a.id === ED.av ? ' on' : '') + '" data-av="' + a.id + '" aria-label="' + a.n + '"><img src="' + avSrc(a.id) + '" alt=""></button>'; }).join('');
  $('edA').innerHTML = NICK_A.map(function (w) { return '<button class="wB' + (w === ED.a ? ' on' : '') + '" data-a="' + w + '">' + w + '</button>'; }).join('');
  $('edB').innerHTML = NICK_B.map(function (w) { return '<button class="wB' + (w === ED.b ? ' on' : '') + '" data-b="' + w + '">' + w + '</button>'; }).join('');
  $('edPrev').innerHTML = '<img src="' + avSrc(ED.av) + '" alt=""><b>' + ED.a + ' ' + ED.b + '</b>';
  $$('#edAvs [data-av]').forEach(function (b) { b.onclick = function () { sfx.tap(); ED.av = b.dataset.av; renderEdit(); }; });
  $$('#edA [data-a]').forEach(function (b) { b.onclick = function () { sfx.tap(); ED.a = b.dataset.a; renderEdit(); }; });
  $$('#edB [data-b]').forEach(function (b) { b.onclick = function () { sfx.tap(); ED.b = b.dataset.b; renderEdit(); }; });
}
$('edMix').onclick = function () { sfx.tap(); ED.a = NICK_A[Math.floor(Math.random() * NICK_A.length)]; ED.b = NICK_B[Math.floor(Math.random() * NICK_B.length)]; renderEdit(); };
$('edSave').onclick = function () {
  var p = pf(), btn = this; sfx.tap();
  p.nick = ED.a + ' ' + ED.b; p.av = ED.av; save(); renderProfile();
  btn.classList.add('dis'); $('edMsg').className = 'msg'; $('edMsg').textContent = 'بنحفظ…';
  ensureProfile().then(function (pp) { return api('POST', '/profile', { pid: pp.pid, key: pp.key, nick: pp.nick, av: pp.av }); })
    .then(function () { btn.classList.remove('dis'); closeOv('ovEdit'); toast('اتحفظ ملفك', 'check'); if (CUR === 'leaderboard') loadBoard(); },
      function (e) { btn.classList.remove('dis'); if (e.status === 401) forgetServer(); $('edMsg').className = 'msg err'; $('edMsg').textContent = 'اتحفظ على الجهاز بس — ' + errText(e); });
};
/* ---------- privacy ---------- */
function openPrivacy() { $('prShow').classList.toggle('on', !!pf().show); $('prMsg').textContent = ''; $('prDel').style.display = pf().pid ? '' : 'none'; openOv('ovPrivacy'); }
function parLocked() { var st = window.PAR && (PAR.st || S.parC); if (st && st.hasPin) { sfx.soft(); closeOv('ovPrivacy'); toast('ده من إعدادات ولي الأمر', 'lock'); show('parental'); return true; } return false; }
$('prShow').onclick = function () {
  if (parLocked()) return;
  var p = pf(), want = !p.show, btn = this; sfx.tap(); btn.classList.add('dis'); $('prMsg').className = 'msg'; $('prMsg').textContent = 'لحظة…';
  ensureProfile().then(function (pp) { return api('POST', '/profile', { pid: pp.pid, key: pp.key, show: want }); }).then(function () {
    p.show = want; save(); btn.classList.remove('dis'); btn.classList.toggle('on', want); $('prDel').style.display = '';
    $('prMsg').className = 'msg ok'; $('prMsg').textContent = want ? 'تمام! هتظهر في الترتيب باسمك المستعار بس' : 'اتخفيت من الترتيب';
    if (CUR === 'profile') loadRank(); if (CUR === 'leaderboard') loadBoard();
  }, function (e) { btn.classList.remove('dis'); $('prMsg').className = 'msg err'; $('prMsg').textContent = errText(e); });
};
$('prDel').onclick = function () {
  if (parLocked()) return;
  sfx.tap();
  ask('تمسح بياناتك من الترتيب؟', 'هيتمسح اسمك المستعار ونجومك من السيرفر. تقدّمك في اللعبة على الجهاز مش هيتمسح.', 'امسح', function () {
    var p = pf(); if (!p.pid) return;
    api('POST', '/leave', { pid: p.pid, key: p.key }).then(function () { forgetServer(); $('prShow').classList.remove('on'); $('prDel').style.display = 'none'; $('prMsg').className = 'msg ok'; $('prMsg').textContent = 'اتمسحت بياناتك من الترتيب'; if (CUR === 'profile') loadRank(); if (CUR === 'leaderboard') loadBoard(); },
      function (e) { $('prMsg').className = 'msg err'; $('prMsg').textContent = errText(e); });
  });
};
/* ---------- profile settings list ---------- */
$('pfEdit').onclick = $('pfEdit2').onclick = $('pfAvBtn').onclick = function () { sfx.tap(); openEdit(); };
$('pfSound').onclick = $('pfLang').onclick = function () { sfx.tap(); show('settings'); };
$('pfPriv').onclick = function () { sfx.tap(); openPrivacy(); };
$('pfHelp').onclick = function () { sfx.tap(); openOv('ovHelp'); };
$('pfAbout').onclick = function () { sfx.tap(); openOv('ovAbout'); };
$('pfOut').onclick = function () {
  sfx.tap();
  ask('تخرج من اللعبة؟', 'تقدّمك محفوظ، وتقدر ترجع تكمّل في أي وقت.', 'اخرج', function () { if (history.length > 1) history.back(); else show('start'); });
};
$('pfAllB').onclick = function () { sfx.tap(); show('achievements'); };
$('pfMap').onclick = function () { sfx.tap(); show('worlds'); };

/* ================= LEADERBOARD ================= */
var LB = { period: 'week', page: 1, size: 7, data: null, state: 'idle', err: '' };
var lbTimer = 0;
function lbRow(r) {
  return '<div class="lbRow r' + Math.min(r.rank, 4) + '"><span class="lbRank">' + r.rank + '</span><span class="lbP"><img src="' + avSrc(r.av) + '" alt=""><b>' + r.nick + '</b></span><span class="lbS">' + ic('star', 'starI') + '<b dir="ltr">' + fmtNum(r.stars) + '</b></span><span class="lbA">' + ic('trophy', 'trI') + '<b>' + r.ach + '</b></span><span class="lbL"><b>' + r.lvl + '</b></span></div>';
}
function renderBoard() {
  $$('#lbTabs [data-p]').forEach(function (b) { b.classList.toggle('on', b.dataset.p === LB.period); });
  var body = $('lbBody'), d = LB.data, p = pf();
  $('lbJoin').style.display = p.show ? 'none' : '';
  if (LB.state === 'load' && !d) { body.innerHTML = '<div class="skel"></div><div class="skel"></div><div class="skel"></div><div class="skel"></div>'; }
  else if (LB.state === 'err') { body.innerHTML = '<div class="emptyBox"><img src="assets/ui/lolo.webp" alt=""><b>مش قادرين نجيب الترتيب</b><small>' + LB.err + '</small><button class="btn sec sm" id="lbRetry">' + ic('retry') + 'جرّب تاني</button></div>'; $('lbRetry').onclick = function () { sfx.tap(); loadBoard(); }; }
  else if (d && !d.items.length) { body.innerHTML = '<div class="emptyBox"><img src="assets/ui/lolo_mag.webp" alt=""><b>لسه مفيش لاعبين في الترتيب ده</b><small>' + (LB.period === 'week' ? 'الأسبوع لسه بادئ — العب واكسب نجوم وكن الأول!' : 'العب واكسب نجوم وكن الأول!') + '</small></div>'; }
  else if (d) body.innerHTML = d.items.map(lbRow).join('');
  // pager
  var pages = d ? d.pages : 1, ph = '';
  for (var k = 1; k <= pages; k++) if (pages <= 7 || k === 1 || k === pages || Math.abs(k - LB.page) <= 1) ph += '<button class="pg' + (k === LB.page ? ' on' : '') + '" data-pg="' + k + '">' + k + '</button>'; else if (ph.slice(-3) !== '…</') ph += '<span class="pgDots">…</span>';
  $('lbPager').innerHTML = d && pages > 1 ? ph : '';
  $$('#lbPager [data-pg]').forEach(function (b) { b.onclick = function () { sfx.tap(); LB.page = +b.dataset.pg; loadBoard(); }; });
  // podium (top 3 of page 1)
  var top = d && LB.page === 1 ? d.items.slice(0, 3) : (LB.top || []);
  if (d && LB.page === 1) LB.top = top;
  $('lbPodium').innerHTML = [1, 0, 2].map(function (i) {
    var r = top[i]; return '<div class="pod p' + (i + 1) + (r ? '' : ' empty') + '">' + (r ? '<img src="' + avSrc(r.av) + '" alt="">' : '<span class="podQ">؟</span>') + '<span class="podN">' + (i + 1) + '</span><div class="podBox"><b>' + (r ? r.nick : '—') + '</b>' + (r ? '<small>' + ic('star', 'starI') + '<span dir="ltr">' + fmtNum(r.stars) + '</span></small>' : '') + '</div></div>';
  }).join('');
  // my card
  var me = d && d.me;
  $('lbMe').innerHTML = !p.show ? '<img src="' + avSrc(p.av) + '" alt=""><div><b>أنت مش ظاهر في الترتيب</b><small>شارك باسمك المستعار عشان تشوف ترتيبك</small></div>'
    : me ? '<img src="' + avSrc(me.av) + '" alt=""><div><b>' + me.nick + '</b><span class="meRow"><span>' + ic('star', 'starI') + '<b dir="ltr">' + fmtNum(me.stars) + '</b></span><span>' + ic('trophy', 'trI') + '<b>' + me.ach + '</b></span></span></div><span class="meRank">' + (me.rank ? '<small>ترتيبك</small><b>' + fmtNum(me.rank) + '</b>' : '<small>العب عشان تدخل الترتيب</small>') + '</span>'
    : '<img src="' + avSrc(p.av) + '" alt=""><div><b>' + p.nick + '</b><small>' + (LB.state === 'err' ? 'مش قادرين نجيب ترتيبك دلوقتي' : '…') + '</small></div>';
  $('lbPrizes').innerHTML = (d ? d.prizes : [100, 60, 40]).map(function (c, i) { return '<span class="lbPz p' + (i + 1) + '"><b>' + (i + 1) + '</b>' + ic('coin', 'coinI') + '<span dir="ltr">+' + c + '</span></span>'; }).join('');
  updPills();
}
function loadBoard() {
  var p = pf(); LB.state = 'load'; renderBoard();
  var my = p.pid ? { pid: p.pid, key: p.key } : {};
  return api('GET', '/board' + q({ period: LB.period, page: LB.page, size: LB.size, pid: my.pid, key: my.key })).then(function (j) {
    LB.data = j; LB.state = 'ok'; LB.reset = Date.now() + j.resetIn * 1000; renderBoard(); checkPrize();
  }, function (e) { LB.state = 'err'; LB.err = errText(e); LB.data = null; renderBoard(); });
}
function tickBoard() {
  var t = LB.reset ? Math.max(0, Math.round((LB.reset - Date.now()) / 1000)) : null;
  $('lbReset').textContent = t === null ? '…' : Math.floor(t / 86400) + ' أيام ' + Math.floor(t % 86400 / 3600) + ' ساعة ' + Math.floor(t % 3600 / 60) + ' دقيقة';
  if (t === 0 && CUR === 'leaderboard' && LB.state === 'ok') { LB.reset = 0; loadBoard(); }
}
/* weekly prize for places 1–3 of the week that ended — the server decides and gives it once */
function checkPrize() {
  var p = pf(); if (!p.pid || !p.show || S.prizeAsked === today()) return;
  S.prizeAsked = today(); save();
  api('POST', '/prize', { pid: p.pid, key: p.key }).then(function (j) { if (j.coins > 0) { grant({ coins: j.coins }, 'trophy', 'المركز ' + j.place + ' في ترتيب الأسبوع'); celebrate('المركز ' + j.place + ' الأسبوع اللي فات! +' + j.coins + ' عملة'); } }, function () { S.prizeAsked = 0; save(); });
}
$$('#lbTabs [data-p]').forEach(function (b) { b.onclick = function () { sfx.tap(); LB.period = b.dataset.p; LB.page = 1; LB.data = null; LB.top = []; loadBoard(); }; });
$('lbJoinBtn').onclick = function () { sfx.tap(); openPrivacy(); };
$('lbRefresh').onclick = function () { sfx.tap(); loadBoard(); };
SCREENS.leaderboard = function () { loadBoard(); tickBoard(); clearInterval(lbTimer); lbTimer = setInterval(function () { if (CUR === 'leaderboard') tickBoard(); else clearInterval(lbTimer); }, 1000); };
