/* مختلف — time, daily tasks, rewards, login streak, world rewards, badges, reward log.
   All reward values come from CONFIG (js/config.js). Nothing here is given twice. */
'use strict';
/* ---------- time: server clock + the approved time zone ---------- */
var SRV_OFF = 0;     // server time minus device time, from the Date header of our own files
function nowMs() { return Date.now() + SRV_OFF; }
function tzParts(ms) {
  try {
    var f = new Intl.DateTimeFormat('en-GB', { timeZone: CONFIG.timeZone, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' });
    var o = {}; f.formatToParts(new Date(ms)).forEach(function (p) { o[p.type] = +p.value; }); return o;
  } catch (e) { var d = new Date(ms); return { year: d.getFullYear(), month: d.getMonth() + 1, day: d.getDate(), hour: d.getHours(), minute: d.getMinutes(), second: d.getSeconds() }; }
}
function today() { var p = tzParts(nowMs()); return Math.floor(Date.UTC(p.year, p.month - 1, p.day) / 864e5); }
function secsToNewDay() { var p = tzParts(nowMs()); return 86400 - (p.hour * 3600 + p.minute * 60 + p.second); }
function hms(t) { var h = Math.floor(t / 3600), m = Math.floor(t % 3600 / 60), s = t % 60; return ('0' + h).slice(-2) + ':' + ('0' + m).slice(-2) + ':' + ('0' + s).slice(-2); }

/* ---------- balance ---------- */
function starBal() { return totalStars() + (S.bonusStars || 0); }
function rewardText(r) { var a = []; if (r.coins) a.push('+' + r.coins + ' عملة'); if (r.stars) a.push('+' + r.stars + ' نجمة'); if (r.hints) a.push('+' + r.hints + ' تلميح'); return a.join(' و '); }
function rewardChips(r) {
  return (r.stars ? '<span class="rc">' + ic('star', 'starI') + '<b dir="ltr">+' + r.stars + '</b></span>' : '') + (r.coins ? '<span class="rc">' + ic('coin', 'coinI') + '<b dir="ltr">+' + r.coins + '</b></span>' : '') + (r.hints ? '<span class="rc">' + ic('bulb', 'hintI') + '<b dir="ltr">+' + r.hints + '</b></span>' : '');
}
/* the one place that adds a reward: balance, log, save */
function grant(r, icon, text) {
  S.coins += r.coins || 0; S.coinsEarned = (S.coinsEarned || 0) + (r.coins || 0); S.bonusStars = (S.bonusStars || 0) + (r.stars || 0); S.extraHints += r.hints || 0;
  S.log.unshift({ t: nowMs(), i: icon, x: text, c: r.coins || 0, e: [r.stars ? '+' + r.stars + ' نجمة' : '', r.hints ? '+' + r.hints + ' تلميح' : ''].filter(Boolean).join(' · ') });
  if (S.log.length > 60) S.log.length = 60;
  save();
}
function celebrate(t) { sfx.open(); confetti(); toast(t, 'gift'); }

/* ---------- login streak (opening the game on a day = logging in that day) ---------- */
function recordLogin() {
  var t = today();
  if (S.lastLogin === t) return;
  S.loginDays = (S.loginDays || 0) + 1;
  S.streak = S.lastLogin === t - 1 ? (S.streak || 0) + 1 : 1;
  S.bestStreak = Math.max(S.bestStreak || 0, S.streak); S.lastLogin = t; save(); checkBadges();
}
function streakIdx() { return Math.max(0, ((S.streak || 1) - 1) % 7); }
function streakReady() { return S.streakClaimed !== today(); }
function claimStreak() {
  if (!streakReady()) return toast('خدت مكافأة النهارده — تعالى بكرة', 'calendar');
  var r = CONFIG.loginStreak[streakIdx()]; S.streakClaimed = today();
  grant(r, 'calendar', 'تسجيل الدخول — اليوم ' + (streakIdx() + 1)); celebrate(rewardText(r)); refreshMeta();
}
function boxReady() { return S.boxDay !== today(); }
function claimBox() {
  if (!boxReady()) return toast('استلمت صندوق النهارده', 'gift');
  S.boxDay = today(); grant(CONFIG.dailyBox, 'gift', 'صندوق المكافأة اليومي'); celebrate(rewardText(CONFIG.dailyBox)); refreshMeta();
}

/* ---------- daily tasks ---------- */
function daily() {
  var t = today();
  if (!S.day || S.day.k !== t) { S.day = { k: t, wins: 0, found: 0, hints: 0, nohint: 0, claimed: {}, bonus: 0 }; save(); }
  return S.day;
}
function taskVal(t) { return Math.min(daily()[t.stat] || 0, t.goal); }
function tasksDone() { return CONFIG.dailyTasks.filter(function (t) { return taskVal(t) >= t.goal; }).length; }
function tasksClaimed() { var d = daily(); return CONFIG.dailyTasks.filter(function (t) { return d.claimed[t.id]; }).length; }
function allTasksClaimed() { return tasksClaimed() === CONFIG.dailyTasks.length; }
function claimTask(id) {
  var t = CONFIG.dailyTasks.filter(function (x) { return x.id === id; })[0], d = daily();
  if (!t) return toast('المهمة دي مش موجودة', 'close');
  if (d.claimed[id]) return toast('استلمت المكافأة دي قبل كده', 'check');
  if (taskVal(t) < t.goal) return toast('لسه المهمة مخلصتش', 'lock');
  d.claimed[id] = 1; S.tasksTotal = (S.tasksTotal || 0) + 1; grant(t, 'calendar', 'مهمة: ' + t.name); checkBadges(); celebrate(rewardText(t)); refreshMeta();
}
function claimBonus() {
  var d = daily();
  if (d.bonus) return toast('استلمت مكافأة النهارده', 'check');
  if (!allTasksClaimed()) return toast('استلم مكافآت المهام الأربعة الأول', 'lock');
  d.bonus = 1; grant(CONFIG.dailyBonus, 'gift', 'مكافأة إكمال المهام اليومية'); celebrate(rewardText(CONFIG.dailyBonus)); refreshMeta();
}
function goTask(t) {
  var c = continueLevel();
  if (t.go === 'hint') toast('دوس على زرار التلميح جوه المرحلة', 'bulb');
  if (c.n) return startLevel(c.n);
  if (S.last && hasLevel(S.last)) { toast('العب مرحلة خلّصتها تاني', 'retry'); return startLevel(S.last); }
  if (hasLevel(1)) return startLevel(1);
  toast('مفيش مراحل جاهزة دلوقتي — جرّب تاني بعد شوية', 'close'); show('worlds');
}
/* ---------- called by the game ---------- */
function onFound() { daily().found++; save(); }
function onHintUsed() { daily().hints++; S.hintsUsed = (S.hintsUsed || 0) + 1; save(); checkBadges(); }
function onWin(info) { var d = daily(); d.wins++; if (info.noHint) d.nohint++; S.chestStars += info.newStars; save(); checkBadges(); }

/* ---------- achievements (data in js/achievements.js) ---------- */
var ACH_STATS = {
  levelsDone: doneCount, worldsDone: function () { var n = 0; for (var w = 0; w < 10; w++) if (wDone(w)) n++; return n; },
  worldsOpen: function () { var n = 0; for (var w = 0; w < 10; w++) if (wOpen(w)) n++; return n; },
  found: function () { return S.found || 0; }, streak: function () { return Math.max(S.bestStreak || 0, S.streak || 0); },
  hintsUsed: function () { return S.hintsUsed || 0; }, starsAll: starBal, coinsEarned: function () { return S.coinsEarned || 0; },
  tasksDone: function () { return S.tasksTotal || 0; }, wins: function () { return S.wins || 0; }, perfect: function () { return S.perfect || 0; }, none: function () { return 0; }
};
function badgeVal(b) { return Math.min((ACH_STATS[b.stat] || ACH_STATS.none)(), b.goal); }
var BADGE_Q = [];
function checkBadges() {
  S.achAt = S.achAt || {};
  ACHIEVEMENTS.forEach(function (b) {
    if (b.future || S.ach[b.id] || badgeVal(b) < b.goal) return;
    S.ach[b.id] = 1; S.achAt[b.id] = nowMs(); grant({ coins: b.coins }, 'trophy', 'شارة: ' + b.name); BADGE_Q.push(b);
  });
  if (BADGE_Q.length) setTimeout(nextBadgePopup, 1500);
}
function nextBadgePopup() {
  if (!BADGE_Q.length || $('ovBadge').classList.contains('on')) return;
  if ($('ovWin').classList.contains('on')) return setTimeout(nextBadgePopup, 1500);
  var b = BADGE_Q.shift();
  $('nbImg').src = 'assets/ui/' + b.img + '.webp'; $('nbName').textContent = b.name; $('nbHow').textContent = b.how; $('nbRw').innerHTML = rewardChips({ coins: b.coins });
  openOv('ovBadge'); sfx.open(); confetti();
}
function achDate(id) { var t = S.achAt && S.achAt[id]; return t ? new Date(t).toLocaleDateString('ar-EG', { day: 'numeric', month: 'short', year: 'numeric', timeZone: CONFIG.timeZone }) : ''; }
function badgeCard(b) {
  var v = badgeVal(b), got = !!S.ach[b.id];
  var art = b.img ? '<img src="assets/ui/' + b.img + '.webp" alt="">' : '<div class="medal">' + ic('lock') + '</div>';
  return '<div class="badge' + (got ? ' got' : '') + (b.future ? ' future' : '') + '">' + art + '<b>' + b.name + '</b><small class="how">' + b.how + '</small>' +
    (b.future ? '' : '<small class="bv">' + (got ? 'معاك ✓' : '<span dir="ltr">' + fmtNum(v) + ' / ' + fmtNum(b.goal) + '</span>') + '</small>') + '</div>';
}
function playerXP() {
  var x = doneCount() * XP.perLevelDone + (S.found || 0) * XP.perFound + starBal() * XP.perStar + Object.keys(S.ach || {}).length * XP.perBadge + (S.tasksTotal || 0) * XP.perTask;
  var lvl = 1, need = XP.firstLevelNeed, left = x;
  while (left >= need) { left -= need; lvl++; need += XP.needGrowth; }
  return { lvl: lvl, cur: left, need: need, total: x };
}
var ACH_CAT = 'all';
function renderAchievements() {
  $('achTabs').innerHTML = ACH_CATS.map(function (c) {
    return '<button class="aTab' + (c.id === ACH_CAT ? ' on' : '') + '" data-cat="' + c.id + '">' + (c.img ? '<img src="assets/ui/' + c.img + '.webp" alt="">' : ic(c.icon)) + c.name + '</button>';
  }).join('');
  var list = ACHIEVEMENTS.filter(function (b) { return ACH_CAT === 'all' || b.cat === ACH_CAT; });
  $('achGrid').innerHTML = list.length ? list.map(function (b) {
    var v = badgeVal(b), got = !!S.ach[b.id], locked = !got && v === 0, pct = Math.round(v / b.goal * 100);
    var st = b.future ? 'future' : got ? 'got' : locked ? 'locked' : 'prog';
    return '<div class="aCard ' + st + '">' + (got ? '<span class="aTag">' + ic('check') + 'مكتمل</span>' : '') + (locked || b.future ? '<span class="aLock">' + ic('lock') + '</span>' : '') +
      (b.img ? '<img src="assets/ui/' + b.img + '.webp" alt="">' : '<div class="medal">' + ic('star') + '</div>') + '<b>' + b.name + '</b><small>' + b.how + '</small>' +
      (b.future ? '<small class="soonT">قريبًا</small>' : got ? '<small class="aDate">' + achDate(b.id) + '</small>' : '<div class="bar"><i style="width:' + pct + '%"></i><span dir="ltr">' + fmtNum(v) + ' / ' + fmtNum(b.goal) + '</span></div><small class="pct">' + pct + '%</small>') + '</div>';
  }).join('') : '<div class="emptyBox"><img src="assets/ui/lolo.webp" alt=""><b>مفيش شارات هنا لسه</b></div>';
  $$('#achTabs [data-cat]').forEach(function (b) { b.onclick = function () { sfx.tap(); ACH_CAT = b.dataset.cat; renderAchievements(); }; });
  var X = playerXP(), got = ACHIEVEMENTS.filter(function (b) { return S.ach[b.id]; }).length, real = ACHIEVEMENTS.filter(function (b) { return !b.future; }).length;
  $('plLvl').textContent = X.lvl; $('plXpBar').style.width = (X.cur / X.need * 100) + '%'; $('plXpT').textContent = fmtNum(X.cur) + ' / ' + fmtNum(X.need);
  $('achCount').textContent = got + ' / ' + real;
  $('plStats').innerHTML = [
    ['flag', 'المراحل المكتملة', doneCount()], ['grid', 'العوالم المفتوحة', ACH_STATS.worldsOpen()], ['search', 'الاختلافات المكتشفة', S.found || 0],
    ['bulb', 'التلميحات المستخدمة', S.hintsUsed || 0], ['calendar', 'أيام الدخول المتتالية', S.streak || 0], ['star', 'نجومك', starBal()]
  ].map(function (r) { return '<div class="stRow">' + ic(r[0]) + '<span>' + r[1] + '</span><b>' + fmtNum(r[2]) + '</b></div>'; }).join('');
  updPills();
}

/* ---------- treasure chest (from level stars) & level milestones ---------- */
var CHEST_STARS = CONFIG.chest.stars;
function openChest() {
  var C = CONFIG.chest;
  if (S.chestStars < C.stars) { sfx.soft(); return toast('محتاج ' + (C.stars - S.chestStars) + ' نجوم كمان عشان تفتح الصندوق', 'star'); }
  S.chestStars -= C.stars; S.chests++;
  var steps = Math.floor((C.maxCoins - C.minCoins) / 10) + 1, r = { coins: C.minCoins + Math.floor(Math.random() * steps) * 10, hints: S.chests % C.hintEvery === 0 ? 1 : 0 };
  grant(r, 'chest', 'صندوق الكنز');
  $$('.chestImg').forEach(function (e) { e.classList.remove('opening'); void e.offsetWidth; e.classList.add('opening'); });
  celebrate('الصندوق فيه ' + rewardText(r)); setTimeout(refreshMeta, 700);
}
function milesReady() { var n = doneCount(); return CONFIG.levelMilestones.filter(function (m) { return n >= m.n && !S.miles[m.n]; }).length; }
function claimMile(n) {
  var m = CONFIG.levelMilestones.filter(function (x) { return x.n === n; })[0];
  if (!m || S.miles[n]) return toast('استلمتها قبل كده', 'check');
  if (doneCount() < n) return toast('خلّص ' + n + ' مرحلة الأول', 'lock');
  S.miles[n] = 1; grant(m, 'flag', 'مكافأة ' + n + ' مرحلة'); celebrate(rewardText(m)); refreshMeta();
}
/* ---------- world rewards ---------- */
function worldReady(w) { return wDone(w) && !(S.worlds && S.worlds[w]); }
function claimWorld(w) {
  S.worlds = S.worlds || {};
  if (S.worlds[w]) return toast('استلمت مكافأة ' + WORLDS[w] + ' قبل كده', 'check');
  if (!wDone(w)) return toast('خلّص الـ10 مراحل في ' + WORLDS[w] + ' الأول', 'lock');
  S.worlds[w] = 1; grant(CONFIG.world, 'trophy', 'إكمال ' + WORLDS[w]); celebrate(rewardText(CONFIG.world)); refreshMeta();
}

/* ---------- pills & dots ---------- */
function updPills() {
  $$('[data-myav]').forEach(function (e) { e.src = avSrc(pf().av); });
  $$('[data-coins]').forEach(function (e) { e.textContent = fmtNum(S.coins); });
  $$('[data-stars]').forEach(function (e) { e.textContent = fmtNum(starBal()); });
  $$('[data-hints]').forEach(function (e) { e.textContent = S.extraHints; });
  var d = daily(), tasksReady = CONFIG.dailyTasks.filter(function (t) { return taskVal(t) >= t.goal && !d.claimed[t.id]; }).length + (allTasksClaimed() && !d.bonus ? 1 : 0);
  var wr = 0; for (var w = 0; w < 10; w++) if (worldReady(w)) wr++;
  var rewardsReady = (boxReady() ? 1 : 0) + (streakReady() ? 1 : 0) + wr + milesReady() + (S.chestStars >= CHEST_STARS ? 1 : 0);
  $$('[data-dot=tasks]').forEach(function (e) { e.textContent = tasksReady || ''; e.style.display = tasksReady ? '' : 'none'; });
  $$('[data-dot=rewards]').forEach(function (e) { e.textContent = ''; e.style.display = rewardsReady ? '' : 'none'; });
}

/* ================= DAILY TASKS SCREEN ================= */
var tkTimer = 0;
function taskRow(t) {
  var d = daily(), v = taskVal(t), done = v >= t.goal, got = !!d.claimed[t.id];
  var btn = got ? '<span class="tBtn done">' + ic('check') + 'مكتملة</span>'
    : done ? '<button class="btn sm y tBtn" data-claim="' + t.id + '">' + ic('gift') + 'استلم المكافأة</button>'
    : '<button class="btn sm y tBtn" data-gotask="' + t.id + '">' + ic('play', 'flip') + 'ابدأ الآن</button>';
  return '<div class="task2' + (got ? ' got' : done ? ' ready' : '') + '"><img class="tImg" src="assets/ui/' + t.img + '.webp" alt="">' +
    '<div class="tMid"><b>' + t.name + '</b><small>' + t.desc + '</small><div class="bar"><i style="width:' + (v / t.goal * 100) + '%"></i><span>' + v + ' / ' + t.goal + '</span></div></div>' +
    '<div class="tRw">' + rewardChips({ stars: t.stars, coins: t.coins }) + '</div>' + btn + '</div>';
}
function renderTasks() {
  var list = $('tkList');
  if (!READY) { list.innerHTML = '<div class="skel"></div><div class="skel"></div><div class="skel"></div><div class="skel"></div>'; return; }
  if (!CONFIG.dailyTasks.length) { list.innerHTML = '<div class="emptyBox"><img src="assets/ui/lolo.webp" alt=""><b>مفيش مهام النهارده</b><small>استنى المهام الجديدة بكرة</small></div>'; }
  else list.innerHTML = CONFIG.dailyTasks.map(taskRow).join('');
  var d = daily(), cl = tasksClaimed(), n = CONFIG.dailyTasks.length, B = CONFIG.dailyBonus;
  $('tkBonusRw').innerHTML = rewardChips(B);
  $('tkProg').style.width = (n ? cl / n * 100 : 0) + '%'; $('tkProgT').textContent = cl + ' / ' + n;
  var bb = $('tkBonusBtn'), chest = $('tkChest');
  chest.classList.toggle('ready', !d.bonus && allTasksClaimed() && !!S.fx);
  if (d.bonus) { bb.className = 'tBtn done'; bb.innerHTML = ic('check') + 'تم الاستلام'; }
  else if (allTasksClaimed()) { bb.className = 'btn y tBtn'; bb.innerHTML = ic('gift') + 'افتح الصندوق'; }
  else { bb.className = 'btn ghost tBtn dis'; bb.innerHTML = ic('lock') + 'استلم المهام الأربعة الأول'; }
  $$('#tkList [data-claim]').forEach(function (b) { b.onclick = function () { sfx.tap(); claimTask(b.dataset.claim); }; });
  $$('#tkList [data-gotask]').forEach(function (b) { b.onclick = function () { sfx.tap(); goTask(CONFIG.dailyTasks.filter(function (t) { return t.id === b.dataset.gotask; })[0]); }; });
  bb.onclick = function () { sfx.tap(); claimBonus(); };
  updPills();
}
function tickTasks() {
  var left = secsToNewDay(); $('tkTime').textContent = hms(left);
  if (S.day && S.day.k !== today()) { daily(); renderTasks(); toast('مهام جديدة النهارده!', 'calendar'); }
}

/* ================= REWARDS SCREEN ================= */
var RW_W = 0;
function renderRewards() {
  if (!READY) { $('rwStreak').innerHTML = '<div class="skel"></div>'; return; }
  // daily box
  var bx = boxReady();
  $('rwBoxRw').innerHTML = rewardChips(CONFIG.dailyBox);
  var bb = $('rwBoxBtn'); bb.className = bx ? 'btn mint tBtn' : 'tBtn done'; bb.innerHTML = bx ? ic('gift') + 'استلام الآن' : ic('check') + 'تم الاستلام';
  $('rwBoxImg').classList.toggle('wob', bx && !!S.fx);
  bb.onclick = function () { sfx.tap(); claimBox(); };
  // login streak
  var si = streakIdx(), ready = streakReady();
  $('rwStreak').innerHTML = CONFIG.loginStreak.map(function (r, k) {
    var cls = k < si || (k === si && !ready) ? 'ok' : k === si ? 'now' : '';
    var art = r.stars && !r.coins ? ic('star', 'starI') : r.hints ? ic('gift', 'giftI') : ic('coin', 'coinI');
    return '<div class="sday ' + cls + '"><small>اليوم ' + (k + 1) + '</small>' + art + '<b dir="ltr">' + (r.coins || r.stars || r.hints) + '</b>' + (cls === 'ok' ? '<span class="sok">' + ic('check') + '</span>' : '') + '</div>';
  }).join('');
  var sb = $('rwStreakBtn'); sb.className = ready ? 'btn y sm tBtn' : 'tBtn done sm'; sb.innerHTML = ready ? ic('gift') + 'استلم مكافأة اليوم ' + (si + 1) : ic('check') + 'تعالى بكرة لليوم ' + (si % 7 + 2 > 7 ? 1 : si + 2);
  sb.onclick = function () { sfx.tap(); claimStreak(); };
  $('rwStreakInfo').textContent = 'دخلت ' + (S.streak || 1) + ' يوم ورا بعض';
  // world reward (browse the 10 worlds)
  var w = RW_W, dc = wDoneCount(w), got = S.worlds && S.worlds[w];
  $('rwWName').textContent = 'مكافأة إكمال ' + WORLDS[w]; $('rwWImg').src = 'assets/worlds/w' + ('0' + (w + 1)).slice(-2) + '.webp';
  $('rwWBar').style.width = dc * 10 + '%'; $('rwWT').textContent = dc + ' / 10'; $('rwWPct').textContent = dc * 10 + '%';
  $('rwWRw').innerHTML = rewardChips(CONFIG.world);
  var wb = $('rwWBtn');
  if (got) { wb.className = 'tBtn done sm'; wb.innerHTML = ic('check') + 'تم الاستلام'; }
  else if (wDone(w)) { wb.className = 'btn y sm tBtn'; wb.innerHTML = ic('gift') + 'استلم'; }
  else { wb.className = 'btn ghost sm tBtn dis'; wb.innerHTML = ic('lock') + 'لسه'; }
  wb.onclick = function () { sfx.tap(); claimWorld(RW_W); };
  $('rwWPrev').classList.toggle('dis', w === 0); $('rwWNext').classList.toggle('dis', w === 9);
  // badges
  $('rwBadges').innerHTML = ACHIEVEMENTS.map(badgeCard).join('');
  // level milestones
  var n = doneCount();
  $('rwMiles').innerHTML = CONFIG.levelMilestones.map(function (m) {
    var g = !!S.miles[m.n], ok = n >= m.n;
    return '<button class="mile2' + (g ? ' got' : ok ? ' ready' : '') + '" data-mile="' + m.n + '"><b>' + m.n + '</b><small>مرحلة</small>' + rewardChips({ coins: m.coins }) + '<span class="ms">' + (g ? ic('check') : ok ? 'استلم' : '<span dir="ltr">' + Math.min(n, m.n) + '/' + m.n + '</span>') + '</span></button>';
  }).join('');
  $$('#rwMiles [data-mile]').forEach(function (b) { b.onclick = function () { sfx.tap(); claimMile(+b.dataset.mile); }; });
  updPills();
}
$('rwWPrev').onclick = function () { if (RW_W > 0) { sfx.tap(); RW_W--; renderRewards(); } };
$('rwWNext').onclick = function () { if (RW_W < 9) { sfx.tap(); RW_W++; renderRewards(); } };
$('rwBPrev').onclick = function () { $('rwBadges').scrollBy({ left: 260, behavior: 'smooth' }); };
$('rwBNext').onclick = function () { $('rwBadges').scrollBy({ left: -260, behavior: 'smooth' }); };
$('hPrice').textContent = CONFIG.hintPrice;
$('buyH').onclick = function () { if (S.coins < CONFIG.hintPrice) { sfx.soft(); return toast('محتاج ' + CONFIG.hintPrice + ' عملة', 'coin'); } S.coins -= CONFIG.hintPrice; S.extraHints++; addLog('bulb', 'اشتريت تلميح', 0, '-' + CONFIG.hintPrice + ' عملة'); save(); sfx.coin(); toast('تلميح زيادة +1', 'bulb'); refreshMeta(); };
$('rwLogBtn').onclick = function () { sfx.tap(); renderLog(); openOv('ovLog'); };
function renderLog() {
  $('logList').innerHTML = S.log.length ? S.log.map(function (l) {
    var d = new Date(l.t);
    return '<div class="logI"><span class="lI">' + ic(l.i) + '</span><span class="lT">' + l.x + (l.e ? ' <em>' + l.e + '</em>' : '') + '<small>' + d.toLocaleDateString('ar-EG', { day: 'numeric', month: 'long', timeZone: CONFIG.timeZone }) + ' · ' + d.toLocaleTimeString('ar-EG', { hour: 'numeric', minute: '2-digit', timeZone: CONFIG.timeZone }) + '</small></span><b dir="ltr">' + (l.c ? '+' + l.c : '') + '</b></div>';
  }).join('') : '<div class="emptyBox"><img src="assets/ui/lolo.webp" alt=""><b>لسه مفيش مكافآت</b><small>العب أول مرحلة واكسب أول عملاتك</small></div>';
}

/* ================= start page side panels ================= */
function chestCard() {
  var p = Math.min(S.chestStars, CHEST_STARS), ready = S.chestStars >= CHEST_STARS;
  return '<div class="chest' + (ready ? ' ready' : '') + '"><img class="chestImg" src="assets/ui/chest.webp" alt="صندوق الكنز">' +
    '<div class="cInfo"><b>صندوق الكنز</b><small>' + (ready ? 'جاهز تفتحه!' : 'اجمع ' + CHEST_STARS + ' نجوم من المراحل') + '</small><div class="bar"><i style="width:' + (p / CHEST_STARS * 100) + '%"></i><span>' + p + ' / ' + CHEST_STARS + '</span></div></div>' +
    '<button class="btn sm ' + (ready ? 'y' : 'ghost dis') + '" data-chest>' + (ready ? 'افتح' : ic('lock')) + '</button></div>';
}
function renderSidePanels() {
  var tp = $('sideTasks');
  if (tp) tp.innerHTML = CONFIG.dailyTasks.map(function (t) {
    var v = taskVal(t), d = daily(), got = d.claimed[t.id];
    return '<div class="task sm' + (got ? ' got' : v >= t.goal ? ' ready' : '') + '"><img class="tImg" src="assets/ui/' + t.img + '.webp" alt=""><div class="tBody"><b>' + t.name + '</b><div class="bar"><i style="width:' + (v / t.goal * 100) + '%"></i><span>' + v + ' / ' + t.goal + '</span></div></div>' + (got ? '<span class="tState ok">' + ic('check') + '</span>' : v >= t.goal ? '<button class="btn sm y" data-claim="' + t.id + '">خد</button>' : '<span class="tState"></span>') + '</div>';
  }).join('') + '<button class="btn sec wide" data-go="tasks">' + ic('calendar') + 'كل المهام</button>';
  $$('#sideTasks [data-claim]').forEach(function (b) { b.onclick = function () { sfx.tap(); claimTask(b.dataset.claim); }; });
  var rp = $('sideRewards');
  if (rp) rp.innerHTML = '<div class="miniBal"><span>' + ic('coin', 'coinI') + '<b data-coins>0</b></span><span>' + ic('star', 'starI') + '<b data-stars>0</b></span></div>' +
    '<div class="miniBadges">' + ACHIEVEMENTS.slice(0, 3).map(badgeCard).join('') + '</div>' + chestCard();
}
function refreshMeta() {
  renderSidePanels();
  if (CUR === 'rewards') renderRewards();
  if (CUR === 'tasks') renderTasks();
  if (CUR === 'achievements') renderAchievements();
  $$('[data-chest]').forEach(function (b) { b.onclick = openChest; });
  updPills();
}
