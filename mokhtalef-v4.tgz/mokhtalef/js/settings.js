/* مختلف — Settings screen (إعدادات اللعبة): sound, music, effects, vibration, full screen, celebrations, language,
   privacy, help, about, progress sync (cloud backup on our server), logout, and clearing this device's data.
   Saved on the device: every switch and level below. Clearing the device never touches what is saved on the server. */
'use strict';
var SET_DEF = { snd: 1, vol: 0.8, mus: 1, musVol: 0.5, sfxOn: 1, sfxVol: 0.8, vib: 1, fx: 1, lang: 'ar' };
(function () { var ch = false; for (var k in SET_DEF) if (S[k] === undefined) { S[k] = SET_DEF[k]; ch = true; } if (ch) save(); })();
var LANGS = { ar: 'العربية', en: 'English', fr: 'Français' };
var LANG_READY = { ar: true, en: false, fr: false };   // the game texts exist in Arabic only for now

/* ---------- full screen ---------- */
function fsEl() { return document.fullscreenElement || document.webkitFullscreenElement || null; }
function fsCan() { var d = document.documentElement; return !!(d.requestFullscreen || d.webkitRequestFullscreen) && (document.fullscreenEnabled !== false || document.webkitFullscreenEnabled); }
function fsSet(on) {
  try {
    if (on) { var d = document.documentElement, r = d.requestFullscreen ? d.requestFullscreen() : d.webkitRequestFullscreen(); return Promise.resolve(r); }
    var x = document.exitFullscreen ? document.exitFullscreen() : document.webkitExitFullscreen && document.webkitExitFullscreen(); return Promise.resolve(x);
  } catch (e) { return Promise.reject(e); }
}
['fullscreenchange', 'webkitfullscreenchange'].forEach(function (ev) { document.addEventListener(ev, function () { if (CUR === 'settings') renderSettings(); }); });

/* ---------- render ---------- */
function renderSettings() {
  var on = { snd: S.snd, mus: S.mus, sfx: S.sfxOn, vib: S.vib, fx: S.fx, fs: fsEl() ? 1 : 0 };
  $$('#settings [data-tg]').forEach(function (b) { b.classList.toggle('on', !!on[b.dataset.tg]); });
  var lv = { snd: S.vol, mus: S.musVol, sfx: S.sfxVol };
  $$('#settings [data-rng]').forEach(function (r) {
    var k = r.dataset.rng; r.value = Math.round(lv[k] * 100); r.style.setProperty('--p', r.value + '%');
    var off = !on[k] || (k !== 'snd' && !S.snd); r.disabled = off; r.closest('.aRow').classList.toggle('off', off);
  });
  var canV = !!navigator.vibrate; $('vibNote').textContent = canV ? '' : 'الجهاز ده مبيدعمش الاهتزاز';
  $('settings').querySelector('[data-tg="vib"]').classList.toggle('dis', !canV);
  var canF = fsCan(); $('fsNote').textContent = canF ? '' : 'مش متاح هنا';
  $('settings').querySelector('[data-tg="fs"]').classList.toggle('dis', !canF);
  $$('#langRow [data-lang]').forEach(function (b) {
    var l = b.dataset.lang; b.classList.toggle('on', S.lang === l); b.classList.toggle('soon', !LANG_READY[l]);
    b.innerHTML = (S.lang === l ? ic('check') : '') + LANGS[l] + (LANG_READY[l] ? '' : '<small>قريبًا</small>');
  });
  $('lgNote').textContent = '';
  renderSyncMsg(); updPills();
}
SCREENS.settings = function () { renderSettings(); };

/* ---------- switches & levels (saved right away) ---------- */
$$('#settings [data-tg]').forEach(function (b) {
  b.onclick = function () {
    var k = b.dataset.tg;
    if (b.classList.contains('dis')) { sfx.soft(); return toast(k === 'vib' ? 'الجهاز ده مبيدعمش الاهتزاز' : 'ملء الشاشة مش متاح هنا', 'close'); }
    if (k === 'snd') S.snd = S.snd ? 0 : 1;
    else if (k === 'mus') S.mus = S.mus ? 0 : 1;
    else if (k === 'sfx') S.sfxOn = S.sfxOn ? 0 : 1;
    else if (k === 'vib') { S.vib = S.vib ? 0 : 1; if (S.vib) buzz(60); }
    else if (k === 'fx') S.fx = S.fx ? 0 : 1;
    else if (k === 'fs') { sfx.tap(); return fsSet(!fsEl()).then(function () { setTimeout(renderSettings, 200); }, function () { toast('مش قادرين نفتح ملء الشاشة هنا', 'close'); renderSettings(); }); }
    save(); musicSync(); renderSettings(); sfx.tap();
  };
});
$$('#settings [data-rng]').forEach(function (r) {
  var k = { snd: 'vol', mus: 'musVol', sfx: 'sfxVol' }[r.dataset.rng], tt = 0;
  r.oninput = function () { S[k] = Math.max(0, Math.min(1, r.value / 100)); r.style.setProperty('--p', r.value + '%'); applyVolumes(); };
  r.onchange = function () { save(); clearTimeout(tt); tt = setTimeout(function () { sfx.tap(); }, 40); };
});
$$('#langRow [data-lang]').forEach(function (b) {
  b.onclick = function () {
    var l = b.dataset.lang; sfx.tap();
    if (!LANG_READY[l]) { $('lgNote').textContent = LANGS[l] + ' جاية قريب — اللعبة دلوقتي بالعربي بس'; return; }
    S.lang = l; save(); document.documentElement.lang = l; renderSettings(); toast('اللغة: ' + LANGS[l], 'check');
  };
});
$('setPriv').onclick = function () { sfx.tap(); openPrivacy(); };
$('setHelp').onclick = function () { sfx.tap(); openOv('ovHelp'); };
$('setAbout').onclick = function () { sfx.tap(); openOv('ovAbout'); };
$('setOut').onclick = function () {
  sfx.tap();
  ask('تسجيل الخروج من اللعبة؟', 'تقدّمك محفوظ على الجهاز ده، وتقدر ترجع تكمّل في أي وقت.', 'اخرج', function () {
    if (fsEl()) fsSet(false).catch(function () {});
    if (history.length > 1) history.back(); else location.href = '/';
  });
};

/* ================= progress sync (two-way, with our server) =================
   The device copy and the server copy are compared; the one with MORE progress wins, then both are the same.
   Sound/language settings stay as they are on this device. */
var SYNC = { state: 'idle', msg: '', at: 0 };
var LOCAL_ONLY = ['snd', 'vol', 'mus', 'musVol', 'sfxOn', 'sfxVol', 'vib', 'fx', 'lang', 'pf', 'syncAt', 'prizeAsked', 'parC'];
function progressOf(d) { var n = 0, st = 0; for (var k in (d && d.lv) || {}) if (d.lv[k] && d.lv[k].s) { n++; st += d.lv[k].s; } return n * 1000 + st * 10 + Math.min(9, Math.floor(((d && d.coinsEarned) || 0) / 1000)); }
function packSave() { var o = {}; for (var k in S) if (LOCAL_ONLY.indexOf(k) < 0) o[k] = S[k]; o.savedAt = nowMs(); return o; }
function syncErr(e) {
  if (e && e.status === 403) return 'المزامنة مقفولة من ولي الأمر';
  if (e && e.status === 413) return 'البيانات أكبر من المسموح';
  return errText(e);
}
function cloudSync(quiet) {
  if (SYNC.state === 'load') return Promise.resolve();
  SYNC = { state: 'load', msg: 'بنزامن تقدّمك…', at: SYNC.at }; renderSyncMsg();
  var restored = false;
  return ensureProfile().then(function (p) {
    return api('POST', '/load', { pid: p.pid, key: p.key }).then(function (srv) {
      if (srv.data && progressOf(srv.data) > progressOf(S)) {                    // the server has more progress → bring it back
        var keep = {}; LOCAL_ONLY.forEach(function (k) { if (S[k] !== undefined) keep[k] = S[k]; });
        for (var k in S) if (LOCAL_ONLY.indexOf(k) < 0) delete S[k];
        for (var j in srv.data) if (LOCAL_ONLY.indexOf(j) < 0) S[j] = srv.data[j];
        for (var x in DEFAULTS) if (S[x] === undefined) S[x] = JSON.parse(JSON.stringify(DEFAULTS[x]));
        for (var m in keep) S[m] = keep[m];
        save(); restored = true;
      }
      return api('POST', '/save', { pid: p.pid, key: p.key, data: packSave() });
    }).then(function () { return syncLevels().catch(function () {}); });
  }).then(function () {
    S.syncAt = nowMs(); save(); SYNC = { state: 'ok', msg: restored ? 'رجّعنا تقدّمك من السيرفر' : 'تقدّمك اتحفظ على السيرفر', at: S.syncAt };
    renderSyncMsg(); if (restored) { refreshMeta(); updPills(); if (SCREENS[CUR] && CUR !== 'game') SCREENS[CUR](); }
    if (!quiet) { sfx.ok(); toast(SYNC.msg, 'check'); }
  }, function (e) {
    if (e && e.status === 401) forgetServer();
    SYNC = { state: 'err', msg: syncErr(e), at: S.syncAt || 0 }; renderSyncMsg();
    if (!quiet) { sfx.soft(); toast('المزامنة ما نفعتش', 'close'); }
  });
}
function renderSyncMsg() {
  var el = $('syncMsg'); if (!el) return;
  var last = S.syncAt ? new Date(S.syncAt).toLocaleString('ar-EG', { timeZone: CONFIG.timeZone, hour: 'numeric', minute: '2-digit', day: 'numeric', month: 'short' }) : '';
  el.className = 'syncMsg ' + SYNC.state;
  el.innerHTML = SYNC.state === 'load' ? '<span class="spin"></span>' + SYNC.msg
    : SYNC.state === 'err' ? ic('close') + SYNC.msg + (/ولي الأمر/.test(SYNC.msg) ? '' : ' <button class="lnk" id="syncRetry">جرّب تاني</button>')
    : SYNC.state === 'ok' ? ic('check') + SYNC.msg + (last ? ' · ' + last : '')
    : last ? 'آخر مزامنة: ' + last : 'لسه ماعملتش مزامنة — دوس «مزامنة التقدّم» عشان تتحفظ نسخة من تقدّمك';
  $('setSync').classList.toggle('dis', SYNC.state === 'load');
  var r = $('syncRetry'); if (r) r.onclick = function () { sfx.tap(); cloudSync(); };
}
$('setSync').onclick = function () { sfx.tap(); if (PAR.st && PAR.st.hasPin && PAR.st.settings.sync === false) { SYNC = { state: 'err', msg: 'المزامنة مقفولة من ولي الأمر' }; return renderSyncMsg(); } cloudSync(); };
/* after each won level: a quiet backup when this player already uses sync */
var syncSoon = 0;
function afterWin() {
  playFoundFlush();
  if (!S.syncAt || !pf().pid || (PAR.st && PAR.st.hasPin && PAR.st.settings.sync === false)) return;
  clearTimeout(syncSoon); syncSoon = setTimeout(function () { cloudSync(true); }, 4000);
}

/* ================= clear this device's data =================
   Needs the parent (PIN) when parental controls are on, then a clear confirmation (tick + button).
   Kept: the link to the server profile, so the saved progress can come back with sync. Never deletes server data. */
$('setClear').onclick = function () {
  sfx.tap();
  parentCheck('مسح البيانات المحلية', function () {
    $('clrOk').checked = false; $('clrGo').classList.add('dis');
    $('clrInfo').textContent = pf().pid ? (S.syncAt ? 'آخر نسخة على السيرفر: ' + new Date(S.syncAt).toLocaleString('ar-EG', { timeZone: CONFIG.timeZone }) : 'تنبيه: لسه ماعملتش مزامنة — اعمل «مزامنة التقدّم» الأول لو عايز تحتفظ بتقدّمك.') : 'تنبيه: مفيش نسخة على السيرفر — اعمل «مزامنة التقدّم» الأول لو عايز تحتفظ بتقدّمك.';
    openOv('ovClear');
  });
};
$('clrOk').onchange = function () { $('clrGo').classList.toggle('dis', !this.checked); };
$('clrGo').onclick = function () {
  if (!$('clrOk').checked) return;
  var p = pf(), keep = { pf: { nick: p.nick, av: p.av, show: !!p.show, pid: p.pid, key: p.key } };
  try { localStorage.setItem(KEY, JSON.stringify(keep)); } catch (e) {}
  sfx.tap(); closeOv('ovClear'); toast('اتمسحت بيانات الجهاز', 'check');
  setTimeout(function () { location.reload(); }, 700);
};
