/* مختلف — achievements data. To add a new badge, add one line here (and its picture in assets/ui/).
   stat: which player number it follows (see ACH_STATS in meta.js) · goal: the number to reach · coins: gift when earned
   cat: play = اللعب والتقدم · explore = الاستكشاف · challenge = التحديات · special = الإنجازات الخاصة */
'use strict';
var ACH_CATS = [
  { id: 'all', name: 'الكل', icon: 'grid' },
  { id: 'play', name: 'اللعب والتقدم', img: 'c_play' },
  { id: 'explore', name: 'الاستكشاف', img: 'c_explore' },
  { id: 'challenge', name: 'التحديات', img: 'c_chall' },
  { id: 'special', name: 'الخاصة', img: 'c_special' }
];
var ACHIEVEMENTS = [
  { id: 'hero100', img: 'a_hero', name: 'بطل مختلف', how: 'أكمل 100 مرحلة', stat: 'levelsDone', goal: 100, coins: 300, cat: 'play' },
  { id: 'worlds10', img: 'a_worlds10', name: 'مستكشف بارع', how: 'أكمل 10 عوالم', stat: 'worldsDone', goal: 10, coins: 300, cat: 'play' },
  { id: 'find500', img: 'a_find', name: 'محترف الاختلافات', how: 'اكتشف 500 اختلاف', stat: 'found', goal: 500, coins: 200, cat: 'explore' },
  { id: 'login7', img: 'a_login', name: 'لاعب يومي', how: 'سجل دخولك 7 أيام متتالية', stat: 'streak', goal: 7, coins: 100, cat: 'challenge' },
  { id: 'hint10', img: 'a_hint', name: 'محقق ذكي', how: 'استخدم التلميح 10 مرات', stat: 'hintsUsed', goal: 10, coins: 50, cat: 'explore' },
  { id: 'allworlds', img: 'a_allworlds', name: 'رحالة العوالم', how: 'افتح جميع العوالم', stat: 'worldsOpen', goal: 10, coins: 200, cat: 'explore' },
  { id: 'lv50', img: 'a_lv50', name: 'خبير المراحل', how: 'أكمل 50 مرحلة', stat: 'levelsDone', goal: 50, coins: 150, cat: 'play' },
  { id: 'stars500', img: 'a_stars', name: 'جامع النجوم', how: 'اجمع 500 نجمة', stat: 'starsAll', goal: 500, coins: 150, cat: 'special' },
  { id: 'coins5000', img: 'a_coins', name: 'جامع الكنوز', how: 'اجمع 5,000 عملة', stat: 'coinsEarned', goal: 5000, coins: 250, cat: 'special' },
  { id: 'tasks30', img: 'a_chall', name: 'سيد التحديات', how: 'أكمل 30 مهمة يومية', stat: 'tasksDone', goal: 30, coins: 200, cat: 'challenge' },
  { id: 'future1', img: '', name: 'شارة جاية قريب', how: 'شارات جديدة في التحديث الجاي', stat: 'none', goal: 1, coins: 0, cat: 'special', future: true }
];
/* player level from experience points (XP) */
var XP = { perLevelDone: 100, perFound: 10, perStar: 20, perBadge: 250, perTask: 50, firstLevelNeed: 500, needGrowth: 250 };
