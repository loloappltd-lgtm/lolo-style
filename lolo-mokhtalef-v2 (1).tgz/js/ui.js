/* مختلف — shared UI helpers: icons, sounds, toasts, screens, popups */
'use strict';
var $ = function (id) { return document.getElementById(id); };
var $$ = function (q, r) { return Array.prototype.slice.call((r || document).querySelectorAll(q)); };
function ic(name, cls) { return '<svg class="i ' + (cls || '') + '" aria-hidden="true"><use href="#i-' + name + '"/></svg>'; }
function fmtNum(n) { return Number(n || 0).toLocaleString('en-US'); }

/* soft synth sounds — no files */
var AC = null;
function tone(f, t, type, v, to) {
  if (!S.snd) return;
  try {
    AC = AC || new (window.AudioContext || window.webkitAudioContext)(); if (AC.state === 'suspended') AC.resume();
    var o = AC.createOscillator(), g = AC.createGain(), n = AC.currentTime;
    o.type = type || 'sine'; o.frequency.setValueAtTime(f, n); if (to) o.frequency.exponentialRampToValueAtTime(to, n + t);
    g.gain.setValueAtTime(0.0001, n); g.gain.exponentialRampToValueAtTime(v || 0.12, n + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, n + t);
    o.connect(g); g.connect(AC.destination); o.start(n); o.stop(n + t + 0.05);
  } catch (e) {}
}
var sfx = {
  tap: function () { tone(620, 0.09, 'sine', 0.08); },
  ok: function () { tone(660, 0.16, 'sine', 0.12); setTimeout(function () { tone(990, 0.22, 'sine', 0.11); }, 110); },
  soft: function () { tone(300, 0.16, 'sine', 0.07, 240); },
  hint: function () { tone(740, 0.35, 'sine', 0.08, 1100); },
  win: function () { [523, 659, 784, 1047].forEach(function (f, i) { setTimeout(function () { tone(f, 0.3, 'sine', 0.11); }, i * 140); }); },
  coin: function () { tone(1046, 0.1, 'triangle', 0.06); setTimeout(function () { tone(1318, 0.14, 'triangle', 0.06); }, 80); },
  open: function () { [392, 523, 659, 784, 1046].forEach(function (f, i) { setTimeout(function () { tone(f, 0.22, 'triangle', 0.08); }, i * 90); }); }
};
function buzz(ms) { if (S.vib && navigator.vibrate) try { navigator.vibrate(ms); } catch (e) {} }

var tT;
function toast(t, icon) {
  var e = $('toast'); e.innerHTML = (icon ? ic(icon) : '') + '<span>' + t + '</span>'; e.classList.add('on');
  clearTimeout(tT); tT = setTimeout(function () { e.classList.remove('on'); }, 2200);
}
function confetti() {
  if (!S.fx) return;
  var c = ['#B9A5E8', '#8D78C7', '#A9D8EA', '#B8DCC2', '#F2C4D4', '#F6D98B'];
  for (var i = 0; i < 46; i++) {
    var e = document.createElement('i'); e.className = 'conf';
    e.style.left = Math.random() * 100 + 'vw'; e.style.background = c[i % c.length];
    e.style.animationDuration = 2 + Math.random() * 1.6 + 's'; e.style.animationDelay = Math.random() * 0.5 + 's';
    document.body.appendChild(e); setTimeout(function (x) { x.remove(); }.bind(null, e), 4400);
  }
}

/* screens slide in softly; each screen can register an onShow */
var SCREENS = {};
var CUR = 'start';
function show(id) {
  var to = $(id); if (!to) return;
  $$('.scr.on').forEach(function (s) { if (s !== to) s.classList.remove('on'); });
  to.classList.add('on'); CUR = id;
  if (SCREENS[id]) SCREENS[id]();
}
/* popups */
function openOv(id) { var o = $(id); o.classList.add('on'); var f = o.querySelector('[data-focus]'); if (f) setTimeout(function () { f.focus(); }, 50); }
function closeOv(id) { $(id).classList.remove('on'); }
function ask(h, t, yesTxt, yes) {
  $('askH').textContent = h; $('askT').textContent = t; $('askYes').textContent = yesTxt || 'أيوه';
  openOv('ovAsk');
  $('askYes').onclick = function () { sfx.tap(); closeOv('ovAsk'); yes(); };
  $('askNo').onclick = function () { sfx.tap(); closeOv('ovAsk'); };
}
document.addEventListener('click', function (e) {
  var c = e.target.closest('[data-close]'); if (c) { sfx.tap(); var o = c.closest('.ov'); o.classList.remove('on'); if (o.dataset.onclose && window[o.dataset.onclose]) window[o.dataset.onclose](); }
  var g = e.target.closest('[data-go]'); if (g) { sfx.tap(); show(g.dataset.go); }
});
/* the soft press effect also works for keyboard users */
document.addEventListener('keydown', function (e) { if (e.key === 'Escape') { var o = $$('.ov.on').pop(); if (o) { var x = o.querySelector('[data-close]'); if (x) x.click(); } } });
