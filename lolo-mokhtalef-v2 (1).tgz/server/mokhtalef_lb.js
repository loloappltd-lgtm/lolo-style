/* مختلف — leaderboard (ترتيب اللاعبين) for the LOLO backend.
   Child safety: players appear only after they choose to join; only a nickname built from fixed word lists and a ready-made
   avatar are stored and shown — no real name, email, phone, country, location, photos or messages. Leaving deletes the
   player's leaderboard data.
   Scores: the server never takes a score from the device. The device sends a finished level (number, stars, time, hints);
   the server checks it against the real level files and its own rules, keeps each player's best stars per level, and
   records only the stars that are NEW (an improvement) as an event with the server time, so the same stars are never
   counted twice.
   week  = stars gained since Saturday 00:00 (Africa/Cairo)   month = since the 1st 00:00 (Africa/Cairo)   all = every star.
   Ties (fixed rule): more stars first → the player who reached that total EARLIER first → the older player id first. */
'use strict';
const crypto = require('crypto'), fs = require('fs'), path = require('path');
const TZ = 'Africa/Cairo';
const NICK_A = ['النجم', 'البطل', 'المحقق', 'الصقر', 'القمر', 'الفراشة', 'الكابتن', 'النحلة', 'الأسد', 'الدلفين', 'الأميرة', 'الفارس', 'الكوكب', 'الشمس', 'الوردة', 'السنجاب'];
const NICK_B = ['الذكي', 'السريع', 'اللامع', 'الشجاع', 'المرح', 'الهادي', 'الشاطر', 'البطل', 'الصغير', 'المبدع', 'المكتشف', 'الطيّب'];
const AVATARS = ['lolo', 'boy', 'girl', 'bunny', 'squirrel', 'turtle', 'penguin', 'robot', 'dino', 'rocket'];
const PRIZES = [100, 60, 40];      // weekly gift coins for places 1, 2, 3 of the week that just ended
const ACH_MAX = 50, LVL_MAX = 200, PAGE_MAX = 50;

function tzParts(ms) {
  const f = new Intl.DateTimeFormat('en-GB', { timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', weekday: 'short', hourCycle: 'h23' });
  const o = {}; f.formatToParts(new Date(ms)).forEach((p) => { o[p.type] = p.value; }); return o;
}
/* the instant (UTC ms) of local midnight for a given local Y-M-D in TZ */
function localMidnight(y, m, d) {
  let guess = Date.UTC(y, m - 1, d);
  for (let i = 0; i < 2; i++) { const p = tzParts(guess); const off = Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute, +p.second) - guess; guess = Date.UTC(y, m - 1, d) - off; }
  return guess;
}
function periodStart(kind, now) {
  if (kind === 'all') return 0;
  const p = tzParts(now), y = +p.year, m = +p.month, d = +p.day;
  if (kind === 'month') return localMidnight(y, m, 1);
  const wd = { Sat: 0, Sun: 1, Mon: 2, Tue: 3, Wed: 4, Thu: 5, Fri: 6 }[p.weekday];   // week starts Saturday
  const base = new Date(Date.UTC(y, m - 1, d - wd));
  return localMidnight(base.getUTCFullYear(), base.getUTCMonth() + 1, base.getUTCDate());
}
function nextWeekStart(now) { const s = periodStart('week', now), b = new Date(s + 8 * 864e5), p = tzParts(b.getTime()); return periodStart('week', localMidnight(+p.year, +p.month, +p.day) + 3600e3); }
const sha = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');
const isNick = (n) => { const a = String(n || '').split(' '); return a.length === 2 && NICK_A.includes(a[0]) && NICK_B.includes(a[1]); };
class Fail extends Error { constructor(code, msg) { super(msg); this.code = code; } }

function makeLeaderboard(opts) {
  const store = opts.store, levelsDir = opts.levelsDir, now = opts.now || (() => Date.now());
  const lastResult = new Map(), joins = new Map();
  let cache = { k: '', t: 0, list: null };
  function levelInfo(n) {
    try {
      const id = ('00' + n).slice(-3), idx = JSON.parse(fs.readFileSync(path.join(levelsDir, 'index.json'), 'utf8'));
      if (!(idx.levels || []).includes(id)) return null;
      return JSON.parse(fs.readFileSync(path.join(levelsDir, id, 'level.json'), 'utf8'));
    } catch (e) { return null; }
  }
  async function auth(pid, key) {
    if (typeof pid !== 'string' || !/^[a-f0-9]{24}$/.test(pid) || typeof key !== 'string' || key.length < 20) throw new Fail(401, 'auth');
    const p = await store.getPlayer(pid);
    if (!p || p.keyHash !== sha(key)) throw new Fail(401, 'auth');
    return p;
  }
  async function join(body, ip) {
    const t = now(), j = (joins.get(ip) || []).filter((x) => t - x < 3600e3);
    if (j.length >= 10) throw new Fail(429, 'too many');
    if (!isNick(body.nick) || !AVATARS.includes(body.av)) throw new Fail(400, 'nick or avatar');
    j.push(t); joins.set(ip, j);
    const pid = crypto.randomBytes(12).toString('hex'), key = crypto.randomBytes(24).toString('hex');
    await store.insertPlayer({ pid, keyHash: sha(key), nick: body.nick, av: body.av, ach: 0, lvl: 1, show: body.show === true, created: t });
    cache.t = 0; return { pid, key };
  }
  async function profile(body) {
    await auth(body.pid, body.key); const set = {};
    if (body.nick !== undefined) { if (!isNick(body.nick)) throw new Fail(400, 'nick'); set.nick = body.nick; }
    if (body.av !== undefined) { if (!AVATARS.includes(body.av)) throw new Fail(400, 'avatar'); set.av = body.av; }
    if (body.show !== undefined) set.show = body.show === true;   // shown in the leaderboard only when the player agrees
    await store.updatePlayer(body.pid, set); cache.t = 0; return { ok: true };
  }
  async function leave(body) { await auth(body.pid, body.key); await store.deletePlayer(body.pid); cache.t = 0; return { ok: true }; }
  async function result(body) {
    const p = await auth(body.pid, body.key), t = now();
    if (t - (lastResult.get(p.pid) || 0) < 1500) throw new Fail(429, 'slow down');
    const out = await applyOne(p, body, t); lastResult.set(p.pid, t);
    await displayFields(p, body); return out;
  }
  /* first sync after joining: the levels already finished on this device, checked one by one in order */
  async function sync(body) {
    const p = await auth(body.pid, body.key), t = now(), list = Array.isArray(body.levels) ? body.levels.slice(0, 100) : [];
    if (t - (lastResult.get(p.pid) || 0) < 1500) throw new Fail(429, 'slow down');
    lastResult.set(p.pid, t);
    list.sort((a, b) => (a.level | 0) - (b.level | 0)); let added = 0, ok = 0;
    for (const L of list) { try { added += (await applyOne(p, L, t)).added; ok++; } catch (e) { break; } }
    await displayFields(p, body); return { ok: true, accepted: ok, added };
  }
  async function displayFields(p, body) {
    const set = {};
    if (body.ach !== undefined) set.ach = Math.max(0, Math.min(ACH_MAX, body.ach | 0));
    if (body.lvl !== undefined) set.lvl = Math.max(1, Math.min(LVL_MAX, body.lvl | 0));
    if (Object.keys(set).length) await store.updatePlayer(p.pid, set);
  }
  async function applyOne(p, body, t) {
    const n = body.level | 0, stars = body.stars | 0, secs = Number(body.time), hints = body.hints | 0;
    const L = n >= 1 && n <= 100 ? levelInfo(n) : null;
    if (!L) throw new Fail(400, 'level');
    if (stars < 1 || stars > 3 || hints < 0 || hints > 20) throw new Fail(400, 'stars');
    const cnt = (L.differences || []).length || 1;
    if (!(secs >= Math.max(3, cnt * 1.5)) || secs > 86400) throw new Fail(400, 'time');
    const maxStars = hints >= 2 ? 1 : hints === 1 ? 2 : 3;                       // same rule as the game
    if (stars > maxStars) throw new Fail(400, 'stars vs hints');
    if (n > 1 && !(await store.getBest(p.pid, n - 1))) throw new Fail(409, 'previous level');
    const prev = (await store.getBest(p.pid, n)) || 0, delta = stars - prev;
    if (delta > 0) { await store.setBest(p.pid, n, stars); await store.addEvent({ pid: p.pid, level: n, delta, at: t }); cache.t = 0; }
    return { ok: true, added: Math.max(0, delta) };
  }
  async function ranked(kind, at) {
    const from = periodStart(kind, at === undefined ? now() : at), to = at === undefined ? Infinity : at, k = kind + ':' + from + ':' + to;
    if (cache.k === k && now() - cache.t < 20000 && cache.list) return cache.list;
    const rows = await store.scores(from, to);                 // [{pid, score, at}] — players still in the board only
    const players = await store.getPlayers(rows.map((r) => r.pid));
    const list = rows.filter((r) => r.score > 0 && players[r.pid] && players[r.pid].show).sort((a, b) => b.score - a.score || a.at - b.at || (a.pid < b.pid ? -1 : 1))
      .map((r, i) => ({ rank: i + 1, pid: r.pid, stars: r.score, nick: players[r.pid].nick, av: players[r.pid].av, ach: players[r.pid].ach || 0, lvl: players[r.pid].lvl || 1 }));
    if (at === undefined) cache = { k, t: now(), list };
    return list;
  }
  const pub = (r) => ({ rank: r.rank, nick: r.nick, av: r.av, stars: r.stars, ach: r.ach, lvl: r.lvl });
  async function board(q) {
    const kind = ['week', 'month', 'all'].includes(q.period) ? q.period : 'week';
    const size = Math.max(1, Math.min(PAGE_MAX, q.size | 0 || 20)), page = Math.max(1, q.page | 0 || 1);
    const list = await ranked(kind), items = list.slice((page - 1) * size, page * size).map(pub);
    let me = null;
    if (q.pid && q.key) { try { const p = await auth(q.pid, q.key); const r = list.find((x) => x.pid === p.pid); me = r ? Object.assign(pub(r), { show: !!p.show }) : { rank: null, nick: p.nick, av: p.av, stars: 0, ach: p.ach || 0, lvl: p.lvl || 1, show: !!p.show }; } catch (e) { me = null; } }
    return { period: kind, page, size, total: list.length, pages: Math.max(1, Math.ceil(list.length / size)), items, me, resetIn: Math.max(0, Math.round((nextWeekStart(now()) - now()) / 1000)), prizes: PRIZES };
  }
  async function me(q) {
    const p = await auth(q.pid, q.key), out = { nick: p.nick, av: p.av, show: !!p.show, ranks: {} };
    for (const k of ['week', 'month', 'all']) { const r = (await ranked(k)).find((x) => x.pid === p.pid); out.ranks[k] = r ? r.rank : null; }
    return out;
  }
  async function prize(body) {
    const p = await auth(body.pid, body.key), weekStart = periodStart('week', now()), lastStart = periodStart('week', weekStart - 3600e3);
    if (p.prizeWeek === lastStart) return { coins: 0, place: null, already: true };
    const last = await ranked('week', weekStart - 1);
    const r = last.find((x) => x.pid === p.pid), place = r && r.rank <= PRIZES.length ? r.rank : null;
    if (!place) return { coins: 0, place: null };
    await store.updatePlayer(p.pid, { prizeWeek: lastStart });
    return { coins: PRIZES[place - 1], place };
  }
  return { join, profile, leave, result, sync, board, me, prize, lists: { NICK_A, NICK_B, AVATARS }, _periodStart: periodStart, _nextWeekStart: nextWeekStart, Fail };
}

/* storage on the backend's MongoDB (own collections, nothing else is touched) */
function mongoStore(db) {
  const P = db.collection('mk_lb_players'), B = db.collection('mk_lb_best'), E = db.collection('mk_lb_events');
  P.createIndex({ pid: 1 }, { unique: true }).catch(() => {}); B.createIndex({ pid: 1, level: 1 }, { unique: true }).catch(() => {}); E.createIndex({ at: 1 }).catch(() => {}); E.createIndex({ pid: 1 }).catch(() => {});
  return {
    getPlayer: (pid) => P.findOne({ pid }),
    getPlayers: async (pids) => { const o = {}; (await P.find({ pid: { $in: pids } }).project({ pid: 1, nick: 1, av: 1, ach: 1, lvl: 1, show: 1 }).toArray()).forEach((p) => { o[p.pid] = p; }); return o; },
    insertPlayer: (d) => P.insertOne(d),
    updatePlayer: (pid, set) => P.updateOne({ pid }, { $set: set }),
    deletePlayer: async (pid) => { await P.deleteOne({ pid }); await B.deleteMany({ pid }); await E.deleteMany({ pid }); },
    getBest: async (pid, level) => { const r = await B.findOne({ pid, level }); return r ? r.stars : 0; },
    setBest: (pid, level, stars) => B.updateOne({ pid, level }, { $set: { stars } }, { upsert: true }),
    addEvent: (e) => E.insertOne(e),
    scores: (from, to) => E.aggregate([{ $match: { at: to === Infinity ? { $gte: from } : { $gte: from, $lte: to } } }, { $group: { _id: '$pid', score: { $sum: '$delta' }, at: { $max: '$at' } } }]).toArray().then((a) => a.map((r) => ({ pid: r._id, score: r.score, at: r.at })))
  };
}
/* in-memory storage, for tests */
function memoryStore() {
  const P = new Map(), B = new Map(), E = [];
  return {
    getPlayer: async (pid) => P.get(pid) || null,
    getPlayers: async (pids) => { const o = {}; pids.forEach((p) => { if (P.has(p)) o[p] = P.get(p); }); return o; },
    insertPlayer: async (d) => { P.set(d.pid, Object.assign({}, d)); },
    updatePlayer: async (pid, set) => { if (P.has(pid)) Object.assign(P.get(pid), set); },
    deletePlayer: async (pid) => { P.delete(pid); for (const k of [...B.keys()]) if (k.startsWith(pid + ':')) B.delete(k); for (let i = E.length - 1; i >= 0; i--) if (E[i].pid === pid) E.splice(i, 1); },
    getBest: async (pid, l) => B.get(pid + ':' + l) || 0,
    setBest: async (pid, l, s) => { B.set(pid + ':' + l, s); },
    addEvent: async (e) => { E.push(e); },
    scores: async (from, to) => { const m = new Map(); E.forEach((e) => { if (e.at >= from && e.at <= to) { const r = m.get(e.pid) || { pid: e.pid, score: 0, at: 0 }; r.score += e.delta; r.at = Math.max(r.at, e.at); m.set(e.pid, r); } }); return [...m.values()]; },
    _E: E, _P: P
  };
}
/* express router: mount with  app.use('/api/mokhtalef/lb', require('./routes/mokhtalef_lb').router({ levelsDir, db }))  */
function router(o) {
  const express = require('express'), r = express.Router();
  let lb = null;
  const get = () => lb || (lb = makeLeaderboard({ store: mongoStore(o.db()), levelsDir: o.levelsDir }));
  r.use(express.json({ limit: '4kb' }));
  r.use((req, res, next) => { res.set('Cache-Control', 'no-store'); next(); });
  const wrap = (fn, src) => (req, res) => fn(src === 'q' ? req.query : req.body || {}, req.ip).then((x) => res.json(x)).catch((e) => res.status(e.code || 500).json({ error: e.code ? e.message : 'server' }));
  r.get('/lists', (req, res) => res.json(get().lists));
  r.get('/board', wrap((q) => get().board(q), 'q'));
  r.get('/me', wrap((q) => get().me(q), 'q'));
  r.post('/join', wrap((b, ip) => get().join(b, ip)));
  r.post('/profile', wrap((b) => get().profile(b)));
  r.post('/leave', wrap((b) => get().leave(b)));
  r.post('/result', wrap((b) => get().result(b)));
  r.post('/sync', wrap((b) => get().sync(b)));
  r.post('/prize', wrap((b) => get().prize(b)));
  return r;
}
module.exports = { makeLeaderboard, mongoStore, memoryStore, router };
