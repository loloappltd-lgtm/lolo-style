/* LOLO STYLE — layered character renderer.
   The girl is built from independent SVG layers (back hair, body, base clothes, shoes, bottoms, tops, dresses,
   face & makeup, front hair, accessories). Every item is drawn from data (see data.js); an item may instead
   point to an image asset (item.img + item.box) and it is placed in the same layer — so final art can replace
   any placeholder drawing without touching this code. */
(function (G) {
  'use strict';
  const VB = { w: 400, h: 760 };
  const LAYERS = ['hairBack', 'body', 'base', 'shoes', 'bottom', 'top', 'dress', 'arms', 'bracelet', 'bag', 'necklace', 'face', 'makeup', 'sticker', 'hairFront', 'hairacc', 'headwear', 'glasses', 'earrings'];

  // ---------- colour helpers ----------
  function hex2rgb(h) { h = h.replace('#', ''); if (h.length === 3) h = h.split('').map((c) => c + c).join(''); const n = parseInt(h, 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
  function rgb2hex(r, g, b) { return '#' + [r, g, b].map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join(''); }
  function mix(a, b, t) { const A = hex2rgb(a), B = hex2rgb(b); return rgb2hex(A[0] + (B[0] - A[0]) * t, A[1] + (B[1] - A[1]) * t, A[2] + (B[2] - A[2]) * t); }
  const light = (c, t) => mix(c, '#ffffff', t), dark = (c, t) => mix(c, '#1a0a2a', t);

  // ---------- defs (gradients / patterns), collected per render ----------
  function Defs(uid) { this.uid = uid; this.map = new Map(); this.out = []; }
  Defs.prototype.grad = function (c, kind) { // glossy vertical gradient → looks "3D cartoon"
    if (c === 'rainbow') return this.rainbow();
    const k = (kind || 'v') + c; if (this.map.has(k)) return this.map.get(k);
    const id = this.uid + 'g' + this.map.size; this.map.set(k, 'url(#' + id + ')');
    if (kind === 'r') this.out.push('<radialGradient id="' + id + '" cx="40%" cy="32%" r="75%"><stop offset="0" stop-color="' + light(c, 0.35) + '"/><stop offset=".55" stop-color="' + c + '"/><stop offset="1" stop-color="' + dark(c, 0.18) + '"/></radialGradient>');
    else this.out.push('<linearGradient id="' + id + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + light(c, 0.32) + '"/><stop offset=".45" stop-color="' + c + '"/><stop offset="1" stop-color="' + dark(c, 0.2) + '"/></linearGradient>');
    return this.map.get(k);
  };
  Defs.prototype.rainbow = function () {
    if (this.map.has('rainbow')) return this.map.get('rainbow');
    const id = this.uid + 'rb'; this.map.set('rainbow', 'url(#' + id + ')');
    const cs = ['#ff5f8f', '#ff9f43', '#ffd93d', '#6bd66b', '#4fb3ff', '#9b6bff'];
    this.out.push('<linearGradient id="' + id + '" x1="0" y1="0" x2="1" y2="1">' + cs.map((c, i) => '<stop offset="' + (i / (cs.length - 1)) + '" stop-color="' + c + '"/>').join('') + '</linearGradient>');
    return this.map.get('rainbow');
  };
  Defs.prototype.pattern = function (kind, c) {
    const k = 'p' + kind + c; if (this.map.has(k)) return this.map.get(k);
    const id = this.uid + 'p' + this.map.size; this.map.set(k, 'url(#' + id + ')');
    const s = 34; let m = '';
    if (kind === 'dots') m = '<circle cx="8" cy="8" r="4" fill="' + c + '"/><circle cx="25" cy="25" r="4" fill="' + c + '"/>';
    else if (kind === 'hearts') m = heart(9, 9, 7, c) + heart(26, 26, 7, c);
    else if (kind === 'stars') m = star(9, 9, 6, c) + star(26, 26, 5, c);
    else if (kind === 'snow') m = snow(9, 9, 7, c) + snow(26, 26, 5, c);
    else if (kind === 'flowers') m = flower(9, 9, 6, c, '#ffd93d') + flower(26, 26, 5, '#ffffff', '#ffd93d');
    else if (kind === 'sparkle') m = sparkle(8, 9, 5, c) + sparkle(25, 26, 4, c) + '<circle cx="25" cy="7" r="1.6" fill="' + c + '"/>';
    else if (kind === 'stripes') m = '<rect width="34" height="9" fill="' + c + '"/><rect y="17" width="34" height="9" fill="' + c + '"/>';
    else if (kind === 'quilt') m = '<path d="M0 17L17 0M17 34L34 17M0 17L17 34M17 0L34 17" stroke="' + c + '" stroke-width="2" fill="none"/>';
    else if (kind === 'kente') m = '<rect width="17" height="17" fill="' + c + '"/><rect x="17" y="17" width="17" height="17" fill="#ffd93d"/><circle cx="25" cy="8" r="4" fill="#ff5f8f"/><circle cx="8" cy="25" r="4" fill="#4fb3ff"/>';
    else if (kind === 'embroidery') m = '<path d="M2 17h30" stroke="' + c + '" stroke-width="2" stroke-dasharray="3 3"/>' + flower(17, 8, 4, c, '#2fa84f') + '<circle cx="5" cy="27" r="2.5" fill="#2fa84f"/><circle cx="29" cy="27" r="2.5" fill="' + c + '"/>';
    this.out.push('<pattern id="' + id + '" width="' + s + '" height="' + s + '" patternUnits="userSpaceOnUse">' + m + '</pattern>');
    return this.map.get(k);
  };

  // ---------- small shapes ----------
  function star(cx, cy, r, fill, stroke) {
    let p = ''; for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, rr = i % 2 ? r * 0.45 : r; p += (i ? 'L' : 'M') + (cx + rr * Math.cos(a)).toFixed(1) + ',' + (cy + rr * Math.sin(a)).toFixed(1); }
    return '<path d="' + p + 'Z" fill="' + fill + '"' + (stroke ? ' stroke="' + stroke + '" stroke-width="1.5" stroke-linejoin="round"' : '') + '/>';
  }
  function heartPath(cx, cy, r) { return 'M' + cx + ',' + (cy + r * 0.9) + 'C' + (cx - r * 1.6) + ',' + (cy - r * 0.2) + ' ' + (cx - r * 0.7) + ',' + (cy - r * 1.3) + ' ' + cx + ',' + (cy - r * 0.45) + 'C' + (cx + r * 0.7) + ',' + (cy - r * 1.3) + ' ' + (cx + r * 1.6) + ',' + (cy - r * 0.2) + ' ' + cx + ',' + (cy + r * 0.9) + 'Z'; }
  function heart(cx, cy, r, fill, stroke) { return '<path d="' + heartPath(cx, cy, r) + '" fill="' + fill + '"' + (stroke ? ' stroke="' + stroke + '" stroke-width="2"' : '') + '/>'; }
  function snow(cx, cy, r, c) { let s = ''; for (let i = 0; i < 3; i++) { const a = i * Math.PI / 3; s += '<path d="M' + (cx - r * Math.cos(a)) + ',' + (cy - r * Math.sin(a)) + 'L' + (cx + r * Math.cos(a)) + ',' + (cy + r * Math.sin(a)) + '" stroke="' + c + '" stroke-width="1.6" stroke-linecap="round"/>'; } return s; }
  function flower(cx, cy, r, c, mid) { cx = +cx; cy = +cy; r = +r; let s = ''; for (let i = 0; i < 5; i++) { const a = i * 2 * Math.PI / 5 - Math.PI / 2; s += '<circle cx="' + (cx + r * 0.75 * Math.cos(a)).toFixed(1) + '" cy="' + (cy + r * 0.75 * Math.sin(a)).toFixed(1) + '" r="' + (r * 0.55).toFixed(1) + '" fill="' + c + '"/>'; } return s + '<circle cx="' + cx + '" cy="' + cy + '" r="' + (r * 0.42).toFixed(1) + '" fill="' + (mid || '#ffd93d') + '"/>'; }
  function sparkle(cx, cy, r, c) { cx = +cx; cy = +cy; r = +r; return '<path d="M' + cx + ',' + (cy - r) + 'Q' + cx + ',' + cy + ' ' + (cx + r) + ',' + cy + 'Q' + cx + ',' + cy + ' ' + cx + ',' + (cy + r) + 'Q' + cx + ',' + cy + ' ' + (cx - r) + ',' + cy + 'Q' + cx + ',' + cy + ' ' + cx + ',' + (cy - r) + 'Z" fill="' + c + '"/>'; }
  function bowShape(cx, cy, s, c, D, opt) {
    opt = opt || {}; const f = D.grad(c), d = dark(c, 0.25);
    let o = '<g transform="translate(' + cx + ',' + cy + ') scale(' + s + ')">';
    if (opt.tails !== false) o += '<path d="M-6,6 L-20,40 L-10,36 L-4,44 L2,10Z M6,6 L20,40 L10,36 L4,44 L-2,10Z" fill="' + f + '" stroke="' + d + '" stroke-width="1.5"/>';
    o += '<path d="M0,0 C-20,-28 -52,-24 -48,0 C-52,24 -20,28 0,0Z" fill="' + f + '" stroke="' + d + '" stroke-width="2"/><path d="M0,0 C20,-28 52,-24 48,0 C52,24 20,28 0,0Z" fill="' + f + '" stroke="' + d + '" stroke-width="2"/>';
    o += '<path d="M-10,-8 C-26,-18 -38,-12 -36,-2" stroke="' + light(c, 0.5) + '" stroke-width="3" fill="none" stroke-linecap="round" opacity=".8"/>';
    o += '<ellipse rx="10" ry="12" fill="' + D.grad(c) + '" stroke="' + d + '" stroke-width="2"/>';
    if (opt.star) o += star(0, 0, 15, '#ffd93d', '#e0a000');
    return o + '</g>';
  }
  // closed blobby outline through points (bumps outward from centroid) → hair volume, curls, ruffles
  function blob(pts, amp) {
    let cx = 0, cy = 0; pts.forEach((p) => { cx += p[0]; cy += p[1]; }); cx /= pts.length; cy /= pts.length;
    let d = 'M' + pts[0][0] + ',' + pts[0][1];
    for (let i = 0; i < pts.length; i++) {
      const a = pts[i], b = pts[(i + 1) % pts.length], mx = (a[0] + b[0]) / 2, my = (a[1] + b[1]) / 2;
      let nx = mx - cx, ny = my - cy; const l = Math.hypot(nx, ny) || 1; nx /= l; ny /= l;
      d += 'Q' + (mx + nx * amp).toFixed(1) + ',' + (my + ny * amp).toFixed(1) + ' ' + b[0] + ',' + b[1];
    }
    return d + 'Z';
  }
  function scallopLine(x1, x2, y, n, depth) { // bottom edge from right→left with round scallops
    let d = ''; const w = (x2 - x1) / n;
    for (let i = n; i > 0; i--) { const xa = x1 + i * w, xb = x1 + (i - 1) * w; d += 'Q' + ((xa + xb) / 2).toFixed(1) + ',' + (y + depth) + ' ' + xb.toFixed(1) + ',' + y; }
    return d;
  }

  // ---------- body geometry ----------
  const ARM = { L: { s: [160, 342], w: [121, 455] }, R: { s: [240, 342], w: [279, 455] } };
  const at = (side, t) => { const a = ARM[side]; return [a.s[0] + (a.w[0] - a.s[0]) * t, a.s[1] + (a.w[1] - a.s[1]) * t]; };

  function drawBody(ch, D) {
    const sk = ch.skin, sf = D.grad(sk, 'r'), sd = dark(sk, 0.14);
    let o = '';
    // legs
    o += '<rect x="164" y="430" width="28" height="240" rx="14" fill="' + D.grad(sk) + '"/><rect x="208" y="430" width="28" height="240" rx="14" fill="' + D.grad(sk) + '"/>';
    o += '<ellipse cx="176" cy="676" rx="20" ry="11" fill="' + sd + '"/><ellipse cx="224" cy="676" rx="20" ry="11" fill="' + sd + '"/>';
    // arms
    ['L', 'R'].forEach((s) => { const a = ARM[s]; o += '<path d="M' + a.s + 'L' + a.w + '" stroke="' + sk + '" stroke-width="26" stroke-linecap="round"/><path d="M' + a.s + 'L' + a.w + '" stroke="' + sd + '" stroke-width="26" stroke-linecap="round" opacity=".18" transform="translate(' + (s === 'L' ? 3 : -3) + ',2)"/><circle cx="' + a.w[0] + '" cy="' + (a.w[1] + 12) + '" r="16" fill="' + sf + '"/>'; });
    // torso + neck
    o += '<path d="M152,330 Q200,318 248,330 L250,440 Q200,452 150,440Z" fill="' + D.grad(sk) + '"/>';
    o += '<rect x="186" y="290" width="28" height="44" rx="12" fill="' + sk + '"/><path d="M186,318 Q200,330 214,318" stroke="' + sd + '" stroke-width="6" fill="none" opacity=".35"/>';
    return o;
  }
  function drawForearms(ch, D) { // image clothes cover the arms, so forearms + hands are redrawn above them
    const sk = ch.skin, sf = D.grad(sk, 'r'); let o = '';
    ['L', 'R'].forEach((s) => { const a = ARM[s], m = at(s, 0.55); o += '<path d="M' + m + 'L' + a.w + '" stroke="' + sk + '" stroke-width="24" stroke-linecap="round"/><circle cx="' + a.w[0] + '" cy="' + (a.w[1] + 12) + '" r="16" fill="' + sf + '"/>'; });
    return o;
  }
  function drawBase(ch, look, D) { // modest base outfit shown when nothing is worn
    let o = '';
    const hasDress = !!look.slots.dress, hasTop = !!look.slots.top, hasBottom = !!look.slots.bottom;
    if (!hasDress && !hasTop) o += '<path d="M150,328 Q200,318 250,328 L252,446 Q200,456 148,446Z" fill="' + D.grad('#fff6fb') + '" stroke="#f3c6dc" stroke-width="2"/><path d="M160,342L150,372M240,342L250,372" stroke="#fff6fb" stroke-width="34" stroke-linecap="round"/>';
    if (!hasDress && !hasBottom) o += '<path d="M148,436 L252,436 L256,498 L206,500 L200,470 L194,500 L144,498Z" fill="' + D.grad('#f7d6ff') + '" stroke="#d9a8ec" stroke-width="2"/>';
    return o;
  }

  // ---------- face ----------
  function drawFace(ch, look, D) {
    const sk = ch.skin, sd = dark(sk, 0.16), m = look.makeup || {};
    const hairDark = look.hair.color === 'rainbow' ? '#5a3a7a' : dark(look.hair.color, 0.35);
    const iris = m.eyes || ch.eyes || '#6b3a1a';
    let o = '';
    o += '<ellipse cx="100" cy="232" rx="17" ry="22" fill="' + sk + '"/><ellipse cx="300" cy="232" rx="17" ry="22" fill="' + sk + '"/><ellipse cx="103" cy="234" rx="8" ry="12" fill="' + sd + '" opacity=".4"/><ellipse cx="297" cy="234" rx="8" ry="12" fill="' + sd + '" opacity=".4"/>';
    o += '<ellipse cx="200" cy="215" rx="101" ry="97" fill="' + D.grad(sk, 'r') + '"/>';
    o += '<ellipse cx="200" cy="298" rx="46" ry="12" fill="' + sd + '" opacity=".18"/>';
    // eyeshadow (makeup, under lashes)
    if (m.shadow) o += '<g class="mk" opacity=".55"><ellipse cx="158" cy="214" rx="31" ry="14" fill="' + m.shadow + '"/><ellipse cx="242" cy="214" rx="31" ry="14" fill="' + m.shadow + '"/></g>';
    // eyes
    [[158, 236], [242, 236]].forEach(([x, y], i) => {
      o += '<g class="eye" style="transform-origin:' + x + 'px ' + y + 'px">';
      o += '<ellipse cx="' + x + '" cy="' + y + '" rx="25" ry="29" fill="#fff"/>';
      o += '<circle cx="' + x + '" cy="' + (y + 4) + '" r="20.5" fill="' + D.grad(iris, 'r') + '"/><circle cx="' + x + '" cy="' + (y + 5) + '" r="10" fill="#1d0f12"/>';
      o += '<circle cx="' + (x - 8) + '" cy="' + (y - 6) + '" r="7" fill="#fff"/><circle cx="' + (x + 7) + '" cy="' + (y + 11) + '" r="3.2" fill="#fff"/>';
      const s = i ? 1 : -1;
      o += '<path d="M' + (x - 27) + ',' + (y - 6) + ' Q' + x + ',' + (y - 38) + ' ' + (x + 27) + ',' + (y - 6) + '" stroke="#2a1416" stroke-width="5" fill="none" stroke-linecap="round"/>';
      o += '<path d="M' + (x + s * 25) + ',' + (y - 10) + ' l' + (s * 9) + ',-7 M' + (x + s * 21) + ',' + (y - 17) + ' l' + (s * 7) + ',-9" stroke="#2a1416" stroke-width="3.5" stroke-linecap="round"/>';
      o += '</g>';
    });
    // brows, nose, mouth
    o += '<path d="M134,190 Q157,178 180,188" stroke="' + hairDark + '" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M220,188 Q243,178 266,190" stroke="' + hairDark + '" stroke-width="5" fill="none" stroke-linecap="round"/>';
    o += '<ellipse cx="200" cy="268" rx="6" ry="4.5" fill="' + sd + '"/>';
    const lip = m.lips || '#d9455f';
    o += '<path d="M176,284 Q200,320 224,284 Q200,292 176,284Z" fill="#8a1f2f" stroke="' + lip + '" stroke-width="' + (m.lips ? 4 : 2.5) + '" stroke-linejoin="round"/><path d="M186,290 Q200,294 214,290 L212,295 Q200,298 188,295Z" fill="#fff"/><ellipse cx="200" cy="305" rx="11" ry="6" fill="#ff8aa0"/>';
    // blush & freckles
    const bl = m.blush || '#ff8fb1';
    o += '<g class="mk" opacity="' + (m.blush ? 0.6 : 0.35) + '"><ellipse cx="136" cy="276" rx="21" ry="12" fill="' + bl + '"/><ellipse cx="264" cy="276" rx="21" ry="12" fill="' + bl + '"/></g>';
    if (ch.freckles) o += '<g fill="' + dark(sk, 0.3) + '" opacity=".5"><circle cx="128" cy="262" r="2"/><circle cx="138" cy="258" r="2"/><circle cx="133" cy="268" r="1.8"/><circle cx="272" cy="262" r="2"/><circle cx="262" cy="258" r="2"/><circle cx="267" cy="268" r="1.8"/></g>';
    return o;
  }
  function drawSticker(kind) {
    if (!kind) return '';
    if (kind === 'star') return star(284, 252, 12, '#ffd93d', '#e0a000');
    if (kind === 'heart') return heart(282, 254, 10, '#ff5f8f', '#fff');
    if (kind === 'sparkle') return sparkle(282, 250, 13, '#fff') + sparkle(118, 214, 8, '#fff');
    if (kind === 'rainbow') return '<g transform="translate(282,262)" fill="none" stroke-linecap="round" stroke-width="3"><path d="M-12,0 A12,12 0 0 1 12,0" stroke="#ff5f8f"/><path d="M-8,0 A8,8 0 0 1 8,0" stroke="#ffd93d"/><path d="M-4,0 A4,4 0 0 1 4,0" stroke="#4fb3ff"/></g>';
    if (kind === 'stars2') return star(120, 220, 8, '#ffd93d', '#e0a000') + star(282, 222, 8, '#ffd93d', '#e0a000') + star(272, 258, 5, '#ff8fd0');
    return '';
  }

  // ---------- hair ----------
  function hairPaint(color, D) { return color === 'rainbow' ? D.rainbow() : D.grad(color); }
  function strands(color, lines) { const c = color === 'rainbow' ? '#6b3f9e' : dark(color, 0.28); return lines.map((l) => '<path d="' + l + '" stroke="' + c + '" stroke-width="3.5" fill="none" stroke-linecap="round" opacity=".55"/>').join(''); }
  function shine(color) { const c = color === 'rainbow' ? '#ffffff' : light(color, 0.55); return '<path d="M150,128 Q200,108 250,128" stroke="' + c + '" stroke-width="7" fill="none" stroke-linecap="round" opacity=".55"/>'; }
  const CAP = 'M92,236 C84,150 140,96 200,96 C262,96 318,150 308,236 C300,200 286,176 268,166 L132,166 C114,176 100,200 92,236Z';
  const HAIR = {
    wavy: {
      back: (c, D) => '<path d="' + blob([[200, 92], [140, 100], [100, 140], [86, 210], [80, 290], [76, 370], [84, 440], [112, 486], [150, 492], [200, 478], [250, 492], [288, 486], [316, 440], [324, 370], [320, 290], [314, 210], [300, 140], [260, 100]], 14) + '" fill="' + hairPaint(c, D) + '"/>' + strands(c, ['M100,300 Q86,360 104,430', 'M300,300 Q314,360 296,430', 'M120,420 Q110,450 130,480', 'M280,420 Q290,450 270,480']),
      front: (c, D) => '<path d="M92,250 C80,150 140,94 204,96 C270,98 318,150 308,250 C298,206 282,182 258,172 C236,188 196,190 172,174 C150,188 120,196 104,214 C98,226 94,238 92,250Z" fill="' + hairPaint(c, D) + '"/>' + '<path d="' + blob([[96, 218], [80, 270], [88, 330], [78, 392], [100, 420], [122, 392], [116, 330], [122, 268]], 8) + '" fill="' + hairPaint(c, D) + '"/><path d="' + blob([[304, 218], [320, 270], [312, 330], [322, 392], [300, 420], [278, 392], [284, 330], [278, 268]], 8) + '" fill="' + hairPaint(c, D) + '"/>' + strands(c, ['M170,110 Q150,140 160,172', 'M232,108 Q262,130 256,170', 'M98,280 Q92,330 100,380', 'M302,280 Q308,330 300,380']) + shine(c),
    },
    straight: {
      back: (c, D) => '<path d="M200,92 C130,92 92,140 88,220 L80,488 Q200,500 320,488 L312,220 C308,140 270,92 200,92Z" fill="' + hairPaint(c, D) + '"/>' + strands(c, ['M110,300 L104,470', 'M290,300 L296,470', 'M150,440 L148,488', 'M250,440 L252,488']),
      front: (c, D) => '<path d="M92,250 C84,146 140,96 200,96 C262,96 316,146 308,250 L300,180 Q280,160 250,166 L250,180 L226,166 L200,182 L176,166 L150,180 L150,166 Q118,160 100,184Z" fill="' + hairPaint(c, D) + '"/><path d="M92,220 L84,410 Q100,420 116,410 L118,230Z M308,220 L316,410 Q300,420 284,410 L282,230Z" fill="' + hairPaint(c, D) + '"/>' + shine(c),
    },
    bob: {
      back: (c, D) => '<path d="' + blob([[200, 92], [130, 100], [92, 150], [84, 230], [88, 300], [120, 330], [200, 320], [280, 330], [312, 300], [316, 230], [308, 150], [270, 100]], 8) + '" fill="' + hairPaint(c, D) + '"/>',
      front: (c, D) => '<path d="M92,250 C84,146 140,96 200,96 C262,96 316,146 308,250 L302,186 Q260,176 200,180 Q140,176 98,186Z" fill="' + hairPaint(c, D) + '"/><path d="M96,200 Q84,280 104,326 L120,320 Q112,260 120,210Z M304,200 Q316,280 296,326 L280,320 Q288,260 280,210Z" fill="' + hairPaint(c, D) + '"/>' + shine(c),
    },
    pigtails: {
      back: (c, D) => '<path d="' + CAP.replace('Z', '') + 'L300,250 L100,250Z" fill="' + hairPaint(c, D) + '"/>' + ['L', 'R'].map((s) => { const x = s === 'L' ? 74 : 326, k = s === 'L' ? -1 : 1; return '<path d="' + blob([[x - k * 6, 190], [x + k * 22, 220], [x + k * 26, 300], [x + k * 14, 380], [x - k * 4, 410], [x - k * 18, 370], [x - k * 20, 290], [x - k * 14, 220]], 10) + '" fill="' + hairPaint(c, D) + '"/>'; }).join('') + strands(c, ['M70,250 Q60,320 74,390', 'M330,250 Q340,320 326,390']),
      front: (c, D) => '<path d="M92,240 C84,146 140,96 200,96 C262,96 316,146 308,240 C300,196 270,170 214,168 L200,120 L186,168 C130,170 100,196 92,240Z" fill="' + hairPaint(c, D) + '"/>' + shine(c) + '<circle cx="92" cy="196" r="10" fill="#ff5fa2"/><circle cx="308" cy="196" r="10" fill="#ff5fa2"/>',
    },
    bun: {
      back: (c, D) => '<path d="' + CAP.replace('Z', '') + 'L300,250 L100,250Z" fill="' + hairPaint(c, D) + '"/>',
      front: (c, D) => '<circle cx="200" cy="82" r="44" fill="' + hairPaint(c, D) + '"/>' + strands(c, ['M172,70 Q200,52 228,70', 'M168,92 Q200,110 232,92']) + '<path d="M92,236 C84,146 140,98 200,98 C262,98 316,146 308,236 C300,196 276,170 240,164 C200,180 150,176 128,168 C110,180 98,206 92,236Z" fill="' + hairPaint(c, D) + '"/><path d="M98,230 Q92,270 104,300 M302,230 Q308,270 296,300" stroke="' + (c === 'rainbow' ? '#8a4fd8' : c) + '" stroke-width="7" fill="none" stroke-linecap="round"/>' + shine(c),
    },
    spacebuns: {
      back: (c, D) => '<path d="' + blob([[200, 96], [130, 104], [92, 150], [86, 230], [92, 320], [130, 360], [200, 350], [270, 360], [308, 320], [314, 230], [308, 150], [270, 104]], 12) + '" fill="' + hairPaint(c, D) + '"/>',
      front: (c, D) => ['L', 'R'].map((s) => { const x = s === 'L' ? 128 : 272; return '<path d="' + blob([[x, 62], [x + 30, 76], [x + 36, 108], [x + 20, 132], [x - 8, 136], [x - 32, 118], [x - 34, 88], [x - 20, 66]], 9) + '" fill="' + hairPaint(c, D) + '"/>'; }).join('') + '<path d="' + blob([[92, 240], [96, 180], [130, 130], [200, 112], [270, 130], [304, 180], [308, 240], [282, 196], [244, 180], [200, 192], [156, 180], [118, 196]], 9) + '" fill="' + hairPaint(c, D) + '"/>' + strands(c, ['M120,90 Q130,110 120,124', 'M280,90 Q270,110 280,124']) + shine(c),
    },
    ponytail: {
      back: (c, D) => '<path d="' + CAP.replace('Z', '') + 'L300,250 L100,250Z" fill="' + hairPaint(c, D) + '"/><path d="' + blob([[290, 120], [336, 150], [350, 230], [344, 320], [330, 400], [306, 420], [300, 360], [310, 270], [300, 190]], 12) + '" fill="' + hairPaint(c, D) + '"/>' + strands(c, ['M318,170 Q336,260 318,380']),
      front: (c, D) => '<path d="M92,240 C84,146 140,96 204,96 C266,98 318,146 308,240 C302,200 290,180 262,168 C230,190 160,190 120,176 C104,192 96,214 92,240Z" fill="' + hairPaint(c, D) + '"/>' + '<ellipse cx="298" cy="128" rx="14" ry="10" fill="#ff5fa2"/>' + shine(c),
    },
    braids: {
      back: (c, D) => '<path d="' + CAP.replace('Z', '') + 'L300,250 L100,250Z" fill="' + hairPaint(c, D) + '"/>',
      front: (c, D) => '<path d="M92,240 C84,146 140,96 200,96 C262,96 316,146 308,240 C300,196 270,168 214,166 L200,118 L186,166 C130,168 100,196 92,240Z" fill="' + hairPaint(c, D) + '"/>' + ['L', 'R'].map((s) => { const x = s === 'L' ? 104 : 296; let o = ''; for (let i = 0; i < 7; i++) { const y = 250 + i * 30, w = 22 - i * 1.4; o += '<ellipse cx="' + (x + (i % 2 ? 3 : -3) * (s === 'L' ? 1 : -1)) + '" cy="' + y + '" rx="' + w + '" ry="18" fill="' + hairPaint(c, D) + '" stroke="' + (c === 'rainbow' ? '#7a4aa8' : dark(c, 0.25)) + '" stroke-width="2.5"/>'; } return o + '<path d="M' + x + ',452 l-10,26 h20z" fill="' + hairPaint(c, D) + '"/><circle cx="' + x + '" cy="448" r="8" fill="#ff5fa2"/>'; }).join('') + shine(c),
    },
    curly: {
      back: (c, D) => { let o = '<path d="' + blob([[200, 84], [120, 96], [76, 150], [64, 240], [66, 330], [84, 410], [130, 450], [200, 440], [270, 450], [316, 410], [334, 330], [336, 240], [324, 150], [280, 96]], 18) + '" fill="' + hairPaint(c, D) + '"/>'; [[86, 300], [74, 360], [100, 420], [314, 300], [326, 360], [300, 420], [150, 446], [250, 446]].forEach(([x, y]) => { o += '<circle cx="' + x + '" cy="' + y + '" r="22" fill="' + hairPaint(c, D) + '"/>'; }); return o + strands(c, ['M90,300 a12,12 0 1 1 18,10', 'M310,300 a12,12 0 1 0 -18,10', 'M110,400 a12,12 0 1 1 18,10', 'M290,400 a12,12 0 1 0 -18,10']); },
      front: (c, D) => '<path d="' + blob([[90, 246], [92, 170], [130, 120], [200, 104], [270, 120], [308, 170], [310, 246], [290, 200], [256, 178], [222, 186], [200, 176], [178, 186], [144, 178], [110, 200]], 11) + '" fill="' + hairPaint(c, D) + '"/>' + strands(c, ['M150,140 a10,10 0 1 1 14,8', 'M230,136 a10,10 0 1 1 14,8', 'M190,124 a10,10 0 1 1 14,8']) + shine(c),
    },
    afro: {
      back: (c, D) => { let o = ''; for (let i = 0; i < 16; i++) { const a = Math.PI * (0.9 + i * 1.2 / 15) , x = 200 + 132 * Math.cos(a) * 1, y = 220 + 128 * Math.sin(a); o += '<circle cx="' + x.toFixed(0) + '" cy="' + y.toFixed(0) + '" r="40" fill="' + hairPaint(c, D) + '"/>'; } return '<ellipse cx="200" cy="230" rx="150" ry="150" fill="' + hairPaint(c, D) + '"/>' + o + '<path d="M80,320 Q70,380 110,420 L290,420 Q330,380 320,320Z" fill="' + hairPaint(c, D) + '"/>'; },
      front: (c, D) => '<path d="' + blob([[90, 240], [92, 170], [130, 122], [200, 108], [270, 122], [308, 170], [310, 240], [288, 196], [250, 176], [200, 172], [150, 176], [112, 196]], 10) + '" fill="' + hairPaint(c, D) + '"/>' + strands(c, ['M140,140 a8,8 0 1 1 12,6', 'M200,126 a8,8 0 1 1 12,6', 'M250,140 a8,8 0 1 1 12,6']),
    },
    hijab: {
      back: (c, D) => '<path d="M200,82 C112,82 74,150 74,236 C74,300 92,350 120,380 L280,380 C308,350 326,300 326,236 C326,150 288,82 200,82Z" fill="' + D.grad(c === 'rainbow' ? '#f4eef6' : c) + '"/>',
      front: (c, D) => { const f = D.grad(c === 'rainbow' ? '#f4eef6' : c), d = dark(c === 'rainbow' ? '#f4eef6' : c, 0.18); return '<path d="M200,88 C120,88 84,150 86,236 C88,290 108,326 140,346 C120,370 118,410 138,440 L262,440 C282,410 280,370 260,346 C292,326 312,290 314,236 C316,150 280,88 200,88Z M200,124 C142,124 108,170 110,230 C112,290 150,320 200,322 C250,320 288,290 290,230 C292,170 258,124 200,124Z" fill="' + f + '" fill-rule="evenodd"/><path d="M110,230 C112,290 150,320 200,322 C250,320 288,290 290,230" stroke="' + d + '" stroke-width="4" fill="none" opacity=".5"/><path d="M160,360 Q200,380 240,360 M150,400 Q200,420 250,400" stroke="' + d + '" stroke-width="3" fill="none" opacity=".45"/>'; },
      hidesHair: true,
    },
  };

  // ---------- clothing drawers (item.draw → function(params, D)) ----------
  function sleeve(side, t, w, color, D, cuff) {
    const a = ARM[side].s, b = at(side, t);
    return '<path d="M' + a + 'L' + b + '" stroke="' + color + '" stroke-width="' + w + '" stroke-linecap="round"/>' + (cuff ? '<circle cx="' + b[0].toFixed(1) + '" cy="' + b[1].toFixed(1) + '" r="' + (w / 2 - 2) + '" fill="none" stroke="' + cuff + '" stroke-width="4"/>' : '');
  }
  const DRAW = {
    top: (p, D) => {
      const f = D.grad(p.color), d = dark(p.color, 0.22); let o = '';
      if (p.hood) o += '<path d="M146,336 Q150,296 200,296 Q250,296 254,336 Q200,322 146,336Z" fill="' + D.grad(dark(p.color, 0.08)) + '"/>';
      const long = p.sleeves === 'long';
      ['L', 'R'].forEach((s) => { o += sleeve(s, long ? 0.92 : 0.36, long ? 34 : 40, p.sleeveColor || p.color, D, long ? (p.cuff || light(p.color, 0.4)) : null); });
      o += '<path d="M146,328 Q200,318 254,328 L258,' + (p.len || 456) + ' Q200,' + ((p.len || 456) + 8) + ' 142,' + (p.len || 456) + 'Z" fill="' + f + '" stroke="' + d + '" stroke-width="2"/>';
      if (p.pattern) o += '<path d="M146,328 Q200,318 254,328 L258,' + (p.len || 456) + ' Q200,' + ((p.len || 456) + 8) + ' 142,' + (p.len || 456) + 'Z" fill="' + D.pattern(p.pattern, p.patternColor || '#ffffff') + '" opacity=".85"/>';
      o += '<path d="M180,324 Q200,340 220,324" stroke="' + (p.collar || d) + '" stroke-width="5" fill="none" stroke-linecap="round"/>';
      if (p.ruffle) o += '<path d="M150,346 ' + scallopLine(150, 250, 346, 8, 10).replace(/^Q/, 'Q') + '" fill="none" stroke="' + light(p.color, 0.6) + '" stroke-width="5"/>';
      if (p.badge === 'star') o += star(200, 380, 18, '#ffd93d', '#e0a000');
      if (p.badge === 'heart') o += heart(200, 382, 16, '#ff5f8f', '#fff');
      if (p.pocket) o += '<path d="M170,410 Q200,402 230,410 L226,440 L174,440Z" fill="' + dark(p.color, 0.1) + '"/>';
      if (p.hood) o += '<path d="M190,330 L186,372 M210,330 L214,372" stroke="#fff" stroke-width="3"/><circle cx="186" cy="374" r="4" fill="#fff"/><circle cx="214" cy="374" r="4" fill="#fff"/>';
      if (p.buttons) o += '<circle cx="200" cy="364" r="4" fill="' + p.buttons + '"/><circle cx="200" cy="390" r="4" fill="' + p.buttons + '"/><circle cx="200" cy="416" r="4" fill="' + p.buttons + '"/>';
      return o;
    },
    shorts: (p, D) => { const f = D.grad(p.color); let o = '<path d="M146,432 L254,432 L260,' + (p.len || 506) + ' L206,' + ((p.len || 506) + 4) + ' L200,470 L194,' + ((p.len || 506) + 4) + ' L140,' + (p.len || 506) + 'Z" fill="' + f + '" stroke="' + dark(p.color, 0.22) + '" stroke-width="2"/><rect x="146" y="430" width="108" height="12" rx="5" fill="' + dark(p.color, 0.1) + '"/>'; if (p.heart) o += heart(230, 476, 9, '#ff5f8f'); if (p.cuffs) o += '<path d="M142,' + ((p.len || 506) - 6) + 'L194,' + ((p.len || 506) - 2) + 'M206,' + ((p.len || 506) - 2) + 'L258,' + ((p.len || 506) - 6) + '" stroke="' + light(p.color, 0.45) + '" stroke-width="6"/>'; return o; },
    pants: (p, D) => { const f = D.grad(p.color); let o = '<path d="M148,432 L252,432 L248,662 L208,662 L200,486 L192,662 L152,662Z" fill="' + f + '" stroke="' + dark(p.color, 0.22) + '" stroke-width="2"/><rect x="148" y="430" width="104" height="12" rx="5" fill="' + dark(p.color, 0.1) + '"/>'; if (p.seams) o += '<path d="M172,446 L170,660 M228,446 L230,660" stroke="' + light(p.color, 0.35) + '" stroke-width="2" stroke-dasharray="5 4"/>'; if (p.heart) o += heart(176, 560, 10, '#ff5f8f') + heart(226, 520, 8, '#ffd93d'); if (p.pattern) o += '<path d="M148,432 L252,432 L248,662 L208,662 L200,486 L192,662 L152,662Z" fill="' + D.pattern(p.pattern, p.patternColor || '#fff') + '" opacity=".7"/>'; return o; },
    overalls: (p, D) => { const f = D.grad(p.color), d = dark(p.color, 0.22); const bottom = p.short ? '<path d="M146,430 L254,430 L260,508 L206,512 L200,470 L194,512 L140,508Z" fill="' + f + '" stroke="' + d + '" stroke-width="2"/>' : '<path d="M148,430 L252,430 L248,662 L208,662 L200,486 L192,662 L152,662Z" fill="' + f + '" stroke="' + d + '" stroke-width="2"/>'; return bottom + '<path d="M166,366 L234,366 L240,436 L160,436Z" fill="' + f + '" stroke="' + d + '" stroke-width="2"/><path d="M168,368 L156,330 M232,368 L244,330" stroke="' + p.color + '" stroke-width="10" stroke-linecap="round"/><circle cx="168" cy="372" r="5" fill="#ffd93d"/><circle cx="232" cy="372" r="5" fill="#ffd93d"/><path d="M182,392 Q200,386 218,392 L216,414 L184,414Z" fill="' + dark(p.color, 0.1) + '"/>' + (p.badge === 'star' ? star(200, 402, 9, '#ffd93d') : ''); },
    skirt: (p, D) => {
      const len = p.len || 548, f = D.grad(p.color), d = dark(p.color, 0.22);
      const wb = p.flare || 30; let o = '';
      if (p.tutu) { for (let i = 2; i >= 0; i--) { const y = 470 + i * 18, w = 70 + i * 14; o += '<path d="M' + (200 - w) + ',' + (y - 30) + ' L' + (200 + w) + ',' + (y - 30) + ' L' + (200 + w + 8) + ',' + y + scallopLine(200 - w - 8, 200 + w + 8, y, 9, 10) + 'Z" fill="' + D.grad(i % 2 ? light(p.color, 0.25) : p.color) + '" opacity=".95"/>'; } return o + '<rect x="148" y="430" width="104" height="14" rx="6" fill="' + dark(p.color, 0.1) + '"/>' + (p.sparkle ? '<path d="M150,450 L250,500" fill="' + D.pattern('sparkle', '#fff') + '"/>' : ''); }
      const path = 'M150,432 L250,432 L' + (250 + wb) + ',' + len + ' Q200,' + (len + 12) + ' ' + (150 - wb) + ',' + len + 'Z';
      o += '<path d="' + path + '" fill="' + f + '" stroke="' + d + '" stroke-width="2"/>';
      if (p.pattern) o += '<path d="' + path + '" fill="' + D.pattern(p.pattern, p.patternColor || '#fff') + '" opacity=".8"/>';
      if (p.pleats) for (let i = 1; i < 6; i++) { const t = i / 6; o += '<path d="M' + (150 + 100 * t) + ',436 L' + (150 - wb + (100 + 2 * wb) * t) + ',' + (len + 4) + '" stroke="' + d + '" stroke-width="2" opacity=".5"/>'; }
      o += '<rect x="148" y="430" width="104" height="13" rx="6" fill="' + dark(p.color, 0.1) + '"/>';
      if (p.bow) o += bowShape(200, 438, 0.32, p.bow, D, { tails: false });
      return o;
    },
    dress: (p, D) => {
      const long = p.len === 'long', hem = long ? 660 : 588, W = long ? 116 : 104, tiers = p.tiers || 1, f = D.grad(p.color), d = dark(p.color, 0.22);
      const cols = p.rainbow ? ['#ff6f9f', '#ffb03b', '#ffd93d', '#62d27a', '#4fb3ff', '#a07bff'] : null;
      let o = '';
      // sleeves
      if (p.sleeves === 'long') ['L', 'R'].forEach((s) => { o += sleeve(s, 0.92, 34, p.color, D, light(p.color, 0.5)); });
      else if (p.sleeves !== 'none') ['L', 'R'].forEach((s) => { const c = ARM[s].s, x = c[0] + (s === 'L' ? -8 : 8); o += '<ellipse cx="' + x + '" cy="' + (c[1] + 6) + '" rx="26" ry="24" fill="' + f + '" stroke="' + d + '" stroke-width="2"/><path d="M' + (x - 22) + ',' + (c[1] + 22) + ' Q' + x + ',' + (c[1] + 34) + ' ' + (x + 22) + ',' + (c[1] + 22) + '" stroke="#fff" stroke-width="5" fill="none" stroke-linecap="round"/>'; });
      // skirt tiers (bottom first)
      const top = 424, h = hem - top;
      for (let i = tiers - 1; i >= 0; i--) {
        const y2 = top + h * (i + 1) / tiers, y1 = i ? top + h * i / tiers - 18 : top, w2 = 54 + (W - 54) * ((i + 1) / tiers), w1 = i ? 54 + (W - 54) * (i / tiers) - 6 : 50;
        const col = cols ? cols[(i * 2) % cols.length] : (i % 2 && p.color2 ? p.color2 : p.color);
        const path = 'M' + (200 - w1) + ',' + y1 + ' L' + (200 + w1) + ',' + y1 + ' L' + (200 + w2) + ',' + y2 + scallopLine(200 - w2, 200 + w2, y2, 8 + i * 2, 12) + 'Z';
        o += '<path d="' + path + '" fill="' + D.grad(col) + '" stroke="' + dark(col, 0.2) + '" stroke-width="2"/>';
        if (p.pattern) o += '<path d="' + path + '" fill="' + D.pattern(p.pattern, p.patternColor || '#ffffff') + '" opacity=".75"/>';
        if (p.trim !== false) o += '<path d="M' + (200 + w2) + ',' + (y2 - 4) + scallopLine(200 - w2, 200 + w2, y2 - 4, 8 + i * 2, 12) + '" fill="none" stroke="' + light(col, 0.6) + '" stroke-width="3" opacity=".8"/>';
      }
      // bodice
      o += '<path d="M148,328 Q200,316 252,328 L254,432 Q200,440 146,432Z" fill="' + (cols ? D.grad(cols[0]) : f) + '" stroke="' + d + '" stroke-width="2"/>';
      if (p.pattern && p.bodicePattern !== false) o += '<path d="M148,328 Q200,316 252,328 L254,432 Q200,440 146,432Z" fill="' + D.pattern(p.pattern, p.patternColor || '#ffffff') + '" opacity=".6"/>';
      if (p.collar !== false) o += '<path d="M172,324 ' + scallopLine(172, 228, 324, 5, 10) + '" fill="none"/><path d="M174,322 Q200,346 226,322" stroke="#fff" stroke-width="7" fill="none" stroke-linecap="round"/>';
      if (p.wrap) o += '<path d="M168,326 L232,420 M232,326 L176,380" stroke="' + light(p.color, 0.5) + '" stroke-width="6"/>';
      // waist
      o += '<rect x="146" y="418" width="108" height="16" rx="7" fill="' + D.grad(p.sash || dark(p.color, 0.08)) + '"/>';
      if (p.bow) o += bowShape(200, 426, 0.42, p.bow, D, { star: p.bowStar, tails: false });
      if (p.star) o += star(200, 426, 18, '#ffd93d', '#e0a000');
      if (p.flowerBelt) o += flower(200, 426, 14, '#fff', '#ffd93d');
      return o;
    },
    shoes: (p, D) => {
      const f = D.grad(p.color), d = dark(p.color, 0.25); let o = '';
      [176, 224].forEach((x, i) => {
        const s = i ? 1 : -1;
        if (p.socks) o += '<rect x="' + (x - 14) + '" y="' + (p.socks === 'high' ? 590 : 630) + '" width="28" height="' + (p.socks === 'high' ? 70 : 34) + '" rx="10" fill="' + (p.sockColor || '#ffffff') + '" stroke="#e6dff0" stroke-width="2"/>';
        if (p.style === 'boots') o += '<path d="M' + (x - 17) + ',598 L' + (x + 17) + ',598 L' + (x + 18) + ',668 Q' + (x + 26 * -s * -1) + ',692 ' + x + ',694 Q' + (x - 26) + ',692 ' + (x - 20) + ',672Z" fill="' + f + '" stroke="' + d + '" stroke-width="2"/><rect x="' + (x - 19) + '" y="596" width="38" height="12" rx="6" fill="' + light(p.color, 0.4) + '"/>';
        if (p.style === 'sandals') { o += '<ellipse cx="' + x + '" cy="684" rx="24" ry="9" fill="' + f + '"/><path d="M' + (x - 16) + ',668 L' + (x + 16) + ',676 M' + (x + 16) + ',668 L' + (x - 16) + ',676" stroke="' + p.color + '" stroke-width="5" stroke-linecap="round"/>' + flower(x, 664, 7, '#fff', '#ffd93d'); return; }
        if (p.style !== 'boots') o += '<path d="M' + (x - 20) + ',' + (p.style === 'sneakers' ? 660 : 666) + ' Q' + x + ',' + (p.style === 'sneakers' ? 650 : 658) + ' ' + (x + 20) + ',' + (p.style === 'sneakers' ? 660 : 666) + ' L' + (x + 24) + ',684 Q' + x + ',696 ' + (x - 24) + ',684Z" fill="' + f + '" stroke="' + d + '" stroke-width="2"/>';
        o += '<path d="M' + (x - 25) + ',684 Q' + x + ',698 ' + (x + 25) + ',684 L' + (x + 25) + ',690 Q' + x + ',704 ' + (x - 25) + ',690Z" fill="' + (p.sole || '#ffffff') + '"/>';
        if (p.style === 'sneakers') o += '<path d="M' + (x - 8) + ',662 l16,4 M' + (x - 9) + ',670 l18,4" stroke="#fff" stroke-width="3" stroke-linecap="round"/>';
        if (p.style === 'maryjane') o += '<path d="M' + (x - 16) + ',668 L' + (x + 16) + ',668" stroke="' + d + '" stroke-width="4"/>';
        if (p.bow) o += bowShape(x, 666, 0.16, p.bow, D, { tails: false });
        if (p.star) o += star(x, 672, 8, '#ffd93d', '#e0a000');
      });
      return o;
    },
    // ----- accessories -----
    crown: (p, D) => { const g = D.grad(p.color), dd = dark(p.color, 0.3); let o = '<path d="M140,128 L150,72 L172,104 L200,58 L228,104 L250,72 L260,128 Q200,140 140,128Z" fill="' + g + '" stroke="' + dd + '" stroke-width="3" stroke-linejoin="round"/>'; o += '<circle cx="150" cy="72" r="6" fill="' + (p.gem2 || '#ff5fa2') + '"/><circle cx="250" cy="72" r="6" fill="' + (p.gem2 || '#ff5fa2') + '"/><circle cx="200" cy="58" r="7" fill="' + (p.gem || '#4fb3ff') + '"/>'; o += (p.heart ? heart(200, 112, 12, p.gem || '#ff5fa2', '#fff') : '<ellipse cx="200" cy="112" rx="10" ry="12" fill="' + (p.gem || '#4fb3ff') + '" stroke="#fff" stroke-width="2"/>') + '<circle cx="166" cy="118" r="5" fill="' + (p.gem2 || '#ff5fa2') + '"/><circle cx="234" cy="118" r="5" fill="' + (p.gem2 || '#ff5fa2') + '"/>'; return o; },
    tiara: (p, D) => { const g = D.grad(p.color), dd = dark(p.color, 0.3); return '<path d="M130,140 Q200,96 270,140 L262,146 Q200,112 138,146Z" fill="' + g + '" stroke="' + dd + '" stroke-width="2"/><path d="M168,122 L176,98 L186,116 L200,84 L214,116 L224,98 L232,122Z" fill="' + g + '" stroke="' + dd + '" stroke-width="2" stroke-linejoin="round"/><ellipse cx="200" cy="112" rx="9" ry="11" fill="' + (p.gem || '#4fb3ff') + '" stroke="#fff" stroke-width="2"/><circle cx="176" cy="98" r="4" fill="#fff"/><circle cx="224" cy="98" r="4" fill="#fff"/>'; },
    flowercrown: (p) => { let o = '<path d="M108,180 Q200,80 292,180" stroke="#4caf50" stroke-width="6" fill="none"/>'; for (let i = 0; i < 9; i++) { const a = Math.PI * (1.08 + i * 0.84 / 8), x = 200 + 104 * Math.cos(a), y = 200 + 100 * Math.sin(a); o += flower(x.toFixed(1), y.toFixed(1), p.rose ? 12 : 11, i % 2 ? (p.color2 || '#ffffff') : p.color, p.rose ? '#c2185b' : '#ffd93d'); if (i % 2 === 0) o += '<ellipse cx="' + (x + 10).toFixed(1) + '" cy="' + (y + 6).toFixed(1) + '" rx="7" ry="4" fill="#5cbf60" transform="rotate(30 ' + (x + 10).toFixed(1) + ' ' + (y + 6).toFixed(1) + ')"/>'; } return o; },
    strawhat: (p, D) => '<ellipse cx="200" cy="138" rx="156" ry="42" fill="' + D.grad('#f2cf7c') + '" stroke="#c9a04b" stroke-width="3"/><path d="M128,138 Q126,64 200,60 Q274,64 272,138Z" fill="' + D.grad('#f2cf7c') + '" stroke="#c9a04b" stroke-width="3"/><path d="M130,118 Q200,130 270,118 L271,136 Q200,148 129,136Z" fill="' + (p.ribbon || '#ff5fa2') + '"/>' + flower(140, 120, 14, '#ff8fb1', '#ffd93d') + flower(162, 130, 10, '#ffffff', '#ffd93d') + flower(122, 132, 9, '#7bc8ff', '#ffd93d'),
    cap: (p, D) => '<path d="M104,170 Q100,84 200,80 Q300,84 296,170 Q200,150 104,170Z" fill="' + D.grad(p.color) + '" stroke="' + dark(p.color, 0.3) + '" stroke-width="3"/><path d="M104,168 Q60,176 52,196 Q120,190 170,164Z" fill="' + D.grad(dark(p.color, 0.1)) + '" stroke="' + dark(p.color, 0.3) + '" stroke-width="3"/><circle cx="200" cy="82" r="8" fill="' + dark(p.color, 0.15) + '"/>' + star(240, 128, 12, '#ffd93d', '#e0a000'),
    bow: (p, D) => bowShape(p.x || 128, p.y || 128, p.s || 0.85, p.color, D, { star: p.star }),
    twinbows: (p, D) => bowShape(118, 92, 0.42, p.color, D, { tails: false }) + bowShape(282, 92, 0.42, p.color, D, { tails: false }),
    catears: (p, D) => '<path d="M112,170 Q200,70 288,170" stroke="' + p.color + '" stroke-width="10" fill="none" stroke-linecap="round"/><path d="M128,140 L118,84 L170,112Z M272,140 L282,84 L230,112Z" fill="' + D.grad(p.color) + '" stroke="' + dark(p.color, 0.25) + '" stroke-width="3" stroke-linejoin="round"/><path d="M134,128 L128,98 L158,114Z M266,128 L272,98 L242,114Z" fill="#ffd93d"/>',
    headband: (p, D) => '<path d="M104,182 Q200,70 296,182" stroke="' + D.grad(p.color) + '" stroke-width="16" fill="none" stroke-linecap="round"/>' + (p.dots ? '<g fill="#fff"><circle cx="150" cy="120" r="3"/><circle cx="200" cy="104" r="3"/><circle cx="250" cy="120" r="3"/></g>' : ''),
    flowerclip: (p) => flower(124, 170, 22, p.color, '#ffd93d') + '<ellipse cx="146" cy="186" rx="12" ry="6" fill="#4caf50" transform="rotate(30 146 186)"/>',
    hairpins: () => '<path d="M150,60 L250,108 M250,60 L150,108" stroke="#e8823a" stroke-width="5" stroke-linecap="round"/><circle cx="150" cy="60" r="7" fill="#ff5f8f"/><circle cx="250" cy="60" r="7" fill="#ff5f8f"/>' + flower(232, 116, 9, '#ff8fb1', '#ffd93d'),
    headwrap: (p, D) => '<path d="M96,196 Q90,110 200,96 Q310,110 304,196 Q200,150 96,196Z" fill="' + D.grad(p.color) + '"/><path d="M96,196 Q90,110 200,96 Q310,110 304,196 Q200,150 96,196Z" fill="' + D.pattern('kente', p.color) + '" opacity=".75"/>' + bowShape(214, 88, 0.6, '#ffd93d', D, { tails: true }),
    glasses: (p, D) => {
      const lens = p.lens || 'rgba(120,40,140,.55)', fr = p.color; let o = '<path d="M184,230 Q200,222 216,230" stroke="' + fr + '" stroke-width="5" fill="none"/>';
      [158, 242].forEach((x) => {
        if (p.shape === 'heart') o += '<path d="' + heartPath(x, 232, 30) + '" fill="' + lens + '" stroke="' + fr + '" stroke-width="6"/>';
        else if (p.shape === 'star') o += star(x, 234, 36, lens, fr).replace('stroke-width="1.5"', 'stroke-width="6"');
        else o += '<circle cx="' + x + '" cy="236" r="28" fill="' + lens + '" stroke="' + fr + '" stroke-width="6"/>';
        if (p.flowers) o += flower(x - 24, 210, 8, '#fff', '#ffd93d') + flower(x + 24, 210, 8, '#fff', '#ffd93d');
      });
      return o + '<path d="M130,226 L96,222 M270,226 L304,222" stroke="' + fr + '" stroke-width="5" stroke-linecap="round"/>';
    },
    earrings: (p, D) => [100, 300].map((x) => { const y = 256; if (p.shape === 'hoop') return '<circle cx="' + x + '" cy="' + (y + 12) + '" r="13" fill="none" stroke="' + D.grad('#ffc93c') + '" stroke-width="5"/>'; if (p.shape === 'pearl') return '<circle cx="' + x + '" cy="' + (y + 4) + '" r="8" fill="' + D.grad('#fffaf0', 'r') + '" stroke="#e8dcc0" stroke-width="1.5"/>'; return '<path d="M' + x + ',' + (y - 2) + 'v8" stroke="#e0a000" stroke-width="2"/>' + (p.shape === 'heart' ? heart(x, y + 16, 9, p.color, '#fff') : star(x, y + 16, 12, p.color, '#fff')); }).join(''),
    necklace: (p, D) => { let o = '<path d="M168,322 Q200,354 232,322" stroke="' + (p.chain || '#ffd27a') + '" stroke-width="3" fill="none"/>'; if (p.beads) for (let i = 0; i <= 10; i++) { const t = i / 10, x = 168 + 64 * t, y = 322 + 4 * 32 * t * (1 - t) * 1.0; o += '<circle cx="' + x.toFixed(1) + '" cy="' + y.toFixed(1) + '" r="4.5" fill="' + (p.beads === 'rainbow' ? ['#ff5f8f', '#ffb03b', '#ffd93d', '#62d27a', '#4fb3ff', '#a07bff'][i % 6] : p.beads) + '"/>'; } if (p.pendant === 'heart') o += heart(200, 354, 11, '#ff5f8f', '#fff'); if (p.pendant === 'star') o += star(200, 354, 12, '#ffd93d', '#e0a000'); return o; },
    bracelet: (p) => [ARM.L.w, ARM.R.w].map((w) => { let o = ''; for (let i = 0; i < 7; i++) { const a = Math.PI * (0.1 + i * 0.8 / 6); o += '<circle cx="' + (w[0] - 15 * Math.cos(a)).toFixed(1) + '" cy="' + (w[1] - 6 + 7 * Math.sin(a)).toFixed(1) + '" r="4.5" fill="' + (p.multi ? ['#ff5f8f', '#ffd93d', '#4fb3ff'][i % 3] : p.color) + '" stroke="#fff" stroke-width="1"/>'; } return o; }).join(''),
    bag: (p, D) => { const x = 262, y = 488, f = D.grad(p.color), d = dark(p.color, 0.25); let o = '<path d="M' + (x + 8) + ',' + (y + 4) + ' Q' + (x + 30) + ',' + (y - 44) + ' ' + (x + 54) + ',' + (y + 4) + '" stroke="' + (p.chain || '#ffc93c') + '" stroke-width="5" fill="none"/>'; if (p.shape === 'heart') o += '<path d="' + heartPath(x + 31, y + 26, 30) + '" fill="' + f + '" stroke="' + d + '" stroke-width="2.5"/>'; else if (p.shape === 'rainbow') o += '<path d="M' + x + ',' + (y + 46) + ' A32,32 0 0 1 ' + (x + 64) + ',' + (y + 46) + 'Z" fill="' + D.rainbow() + '" stroke="#fff" stroke-width="3"/><circle cx="' + (x + 2) + '" cy="' + (y + 48) + '" r="10" fill="#fff"/><circle cx="' + (x + 62) + '" cy="' + (y + 48) + '" r="10" fill="#fff"/>'; else { o += '<rect x="' + x + '" y="' + y + '" width="64" height="48" rx="12" fill="' + f + '" stroke="' + d + '" stroke-width="2.5"/>'; if (p.quilt) o += '<rect x="' + x + '" y="' + y + '" width="64" height="48" rx="12" fill="' + D.pattern('quilt', light(p.color, 0.45)) + '"/>'; o += '<path d="M' + x + ',' + (y + 16) + ' Q' + (x + 32) + ',' + (y + 30) + ' ' + (x + 64) + ',' + (y + 16) + '" fill="' + dark(p.color, 0.08) + '"/>'; } if (p.charm === 'heart') o += heart(x + 32, y + 28, 8, '#ffd93d', '#e0a000'); if (p.charm === 'star') o += star(x + 32, y + 28, 10, '#ffd93d', '#e0a000'); if (p.charm === 'bow') o += bowShape(x + 32, y + 24, 0.25, '#ffb3e0', D, { tails: false }); return o; },
  };


  // ---------- real-art characters (approved 3D-cartoon body + separate hair layers) ----------
  const ART_IMG = (src, extra) => '<image href="' + src + '" x="4.7" y="6" width="372.5" height="745" preserveAspectRatio="none"' + (extra || '') + '/>';
  const TF = { face: 'translate(200,164) scale(0.93) translate(-200,-236)', head: 'translate(0,-52)', torso: 'translate(200,254) scale(1.2,0.95) translate(-200,-312)', bottom: 'translate(200,376) scale(1.43,1.38) translate(-200,-436)' };
  const g = (t, body) => (body ? '<g transform="' + t + '">' + body + '</g>' : '');
  function hairFilter(D, color) {
    if (color === 'rainbow') color = '#ff6fae';
    const c = [1, 3, 5].map((i) => parseInt(color.slice(i, i + 2), 16) / 255), k = 2.1, row = (v) => [0.3 * v * k, 0.59 * v * k, 0.11 * v * k, 0, 0.04].join(' ');
    const id = D.uid + 'hf' + (++uidSeq);
    D.out.push('<filter id="' + id + '" color-interpolation-filters="sRGB"><feColorMatrix type="matrix" values="' + row(c[0]) + ' ' + row(c[1]) + ' ' + row(c[2]) + ' 0 0 0 1 0"/></filter>');
    return ' filter="url(#' + id + ')"';
  }
  function artHair(ch, hair, D) {
    const A = ch.art, style = A.hair[hair.style] !== undefined ? hair.style : Object.keys(A.hair)[0];
    const recolor = hair.color && hair.color !== ch.hair.color ? hairFilter(D, hair.color) : '';
    let o = recolor ? ART_IMG(A.bunHair, recolor) : '';
    if (A.hair[style]) o += ART_IMG(A.hair[style], recolor);
    return o;
  }
  function renderArt(ch, look, opt) {
    const D = new Defs('r' + (++uidSeq) + '_'), A = ch.art, items = G.LS_DATA.itemsById, m = look.makeup || {};
    const L = {}; ['body', 'hair', 'shoes', 'bottom', 'top', 'dress', 'arms', 'bracelet', 'bag', 'necklace', 'makeup', 'sticker', 'hairacc', 'headwear', 'glasses', 'earrings'].forEach((k) => (L[k] = ''));
    L.body = ART_IMG(A.base);
    L.hair = artHair(ch, look.hair, D);
    let mk = '';
    if (m.shadow) mk += '<g opacity=".5"><ellipse cx="158" cy="206" rx="30" ry="13" fill="' + m.shadow + '"/><ellipse cx="242" cy="206" rx="30" ry="13" fill="' + m.shadow + '"/></g>';
    if (m.blush) mk += '<g opacity=".45"><ellipse cx="128" cy="284" rx="24" ry="14" fill="' + m.blush + '"/><ellipse cx="272" cy="284" rx="24" ry="14" fill="' + m.blush + '"/></g>';
    L.makeup = g(TF.face, mk);
    L.sticker = g(TF.face, drawSticker(m.sticker));
    const cl = D.uid + 'cl', cr = D.uid + 'cr';
    D.out.push('<clipPath id="' + cl + '"><rect x="0" y="0" width="200" height="760"/></clipPath><clipPath id="' + cr + '"><rect x="200" y="0" width="200" height="760"/></clipPath>');
    let needArms = false;
    Object.keys(look.slots).forEach((slot) => {
      const it = items[look.slots[slot]]; if (!it) return;
      if (it.img) {
        if (it.layer === 'dress') { const W = 190 / (it.sf || 0.62), ar = it.box ? it.box[3] / it.box[2] : 1; L.dress += '<image href="' + it.img + '" x="' + (200 - W / 2) + '" y="250" width="' + W + '" height="' + W * ar + '" preserveAspectRatio="xMidYMin meet"/>'; needArms = true; }
        else { L[it.layer] += ART_IMG(it.img); if (it.layer === 'top') needArms = true; }
        return;
      }
      const v = (DRAW[it.draw] || (() => ''))(it.p || {}, D);
      if (it.layer === 'shoes') L.shoes += '<g transform="translate(131,733) scale(1.45) translate(-178,-688)"><g clip-path="url(#' + cl + ')">' + v + '</g></g><g transform="translate(258,733) scale(1.45) translate(-222,-688)"><g clip-path="url(#' + cr + ')">' + v + '</g></g>';
      else if (it.layer === 'bracelet') L.bracelet += '<g transform="translate(-41,-42)"><g clip-path="url(#' + cl + ')">' + v + '</g></g><g transform="translate(34,-42)"><g clip-path="url(#' + cr + ')">' + v + '</g></g>';
      else if (it.layer === 'bag') L.bag += g('translate(34,-42)', v);
      else if (it.layer === 'top' || it.layer === 'necklace' || it.layer === 'dress') L[it.layer] += g(TF.torso, v);
      else if (it.layer === 'bottom') L.bottom += g(TF.bottom, v);
      else if (it.layer === 'glasses' || it.layer === 'earrings') L[it.layer] += g(TF.face, v);
      else if (it.layer === 'hairacc') L.hairacc += g('translate(200,90) scale(1.25) translate(-200,-128)', v);
      else L[it.layer] += g(TF.head, v);
    });
    if (needArms) L.arms = ART_IMG(A.arms);
    const vb = opt.viewBox || '0 0 ' + VB.w + ' ' + VB.h;
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="' + vb + '" class="' + (opt.cls || 'avatar') + '"><defs>' + D.out.join('') + '</defs><g class="doll">' + Object.keys(L).map((k) => '<g class="ly ly-' + k + '">' + L[k] + '</g>').join('') + '</g></svg>';
  }
  function renderArtHairThumb(ch, style, color) {
    const D = new Defs('t' + (++uidSeq) + '_');
    const body = ART_IMG(ch.art.base) + artHair(ch, { style, color }, D);
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="40 0 320 320"><defs>' + D.out.join('') + '</defs>' + body + '</svg>';
  }

  // ---------- render ----------
  let uidSeq = 0;
  function render(ch, look, opt) {
    opt = opt || {}; if (ch.art) return renderArt(ch, look, opt); const D = new Defs('a' + (++uidSeq) + '_'); const L = {}; LAYERS.forEach((k) => (L[k] = ''));
    const items = G.LS_DATA.itemsById, hair = HAIR[look.hair.style] || HAIR.wavy;
    L.hairBack = hair.back(look.hair.color, D);
    L.body = drawBody(ch, D);
    L.base = drawBase(ch, look, D);
    L.face = drawFace(ch, look, D);
    L.sticker = drawSticker(look.makeup && look.makeup.sticker);
    L.hairFront = hair.front(look.hair.color, D);
    Object.keys(look.slots).forEach((slot) => {
      const it = items[look.slots[slot]]; if (!it) return;
      if (hair.hidesHair && (it.layer === 'hairacc' && !it.overHijab)) return;
      let svg;
      if (it.img) { const b = it.box || [0, 0, VB.w, VB.h]; svg = '<image href="' + it.img + '" x="' + b[0] + '" y="' + b[1] + '" width="' + b[2] + '" height="' + b[3] + '" preserveAspectRatio="xMidYMid meet"/>'; }
      else svg = (DRAW[it.draw] || (() => ''))(it.p || {}, D);
      L[it.layer] = (L[it.layer] || '') + '<g data-item="' + it.id + '">' + svg + '</g>';
      if (it.img && (it.layer === 'dress' || it.layer === 'top')) L.arms = drawForearms(ch, D);
    });
    const vb = opt.viewBox || '0 0 ' + VB.w + ' ' + VB.h;
    const body = LAYERS.map((k) => '<g class="ly ly-' + k + '">' + L[k] + '</g>').join('');
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="' + vb + '" class="' + (opt.cls || 'avatar') + '"><defs>' + D.out.join('') + '</defs><g class="doll">' + body + '</g></svg>';
  }
  // single item preview (for library tiles) — drawn on a mannequin-free canvas region
  function renderItem(it, extra) {
    const D = new Defs('i' + (++uidSeq) + '_');
    if (it.img) return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><image href="' + (it.thumb || it.img) + '" x="2" y="2" width="96" height="96" preserveAspectRatio="xMidYMid meet"/></svg>';
    let svg = (DRAW[it.draw] || (() => ''))(it.p || {}, D);
    const vb = it.vb || { top: '120 310 160 170', bottom: '110 420 180 260', dress: '80 300 240 380', shoes: '140 580 120 130', crown: '120 40 160 120', bag: '250 430 90 120', glasses: '80 180 240 110', earrings: '80 220 240 80', necklace: '150 310 100 70', bracelet: '90 420 220 60' }[it.cat] || '0 0 400 760';
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="' + vb + '"><defs>' + D.out.join('') + '</defs>' + svg + (extra || '') + '</svg>';
  }
  function renderHairThumb(style, color, skin) {
    const D = new Defs('h' + (++uidSeq) + '_'), h = HAIR[style] || HAIR.wavy;
    const body = h.back(color, D) + '<ellipse cx="200" cy="215" rx="101" ry="97" fill="' + (skin || '#f9d2b6') + '"/>' + h.front(color, D);
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="20 30 360 400"><defs>' + D.out.join('') + '</defs>' + body + '</svg>';
  }
  G.LS_AVATAR = { render, renderItem, renderHairThumb, renderArtHairThumb, HAIR, DRAW, LAYERS, VB, util: { light, dark, star, heart, flower, sparkle } };
})(window);
