/* LOLO STYLE — screens, state, saving, sounds and effects. */
(function (G) {
  'use strict';
  const DATA = G.LS_DATA, AV = G.LS_AVATAR, SC = G.LS_SCENES;
  const $ = (s, r) => (r || document).querySelector(s), $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const KEY = 'loloStyle.v2';
  const clone = (o) => JSON.parse(JSON.stringify(o));
  const rnd = (a) => a[Math.floor(Math.random() * a.length)];

  // ---------- icons ----------
  const ICON = {
    sound: '<svg viewBox="0 0 24 24" fill="#fff"><path d="M4 9v6h4l5 4V5L8 9H4z"/><path d="M16 8.5a5 5 0 0 1 0 7M18.5 6a8.5 8.5 0 0 1 0 12" stroke="#fff" stroke-width="2.2" fill="none" stroke-linecap="round"/></svg>',
    mute: '<svg viewBox="0 0 24 24" fill="#fff"><path d="M4 9v6h4l5 4V5L8 9H4z"/><path d="M16 9l6 6M22 9l-6 6" stroke="#fff" stroke-width="2.4" stroke-linecap="round"/></svg>',
    gear: '<svg viewBox="0 0 24 24" fill="#fff"><path d="M19.4 13a7.6 7.6 0 0 0 0-2l2-1.6-2-3.4-2.4 1a7 7 0 0 0-1.7-1L15 3.5h-4l-.4 2.5a7 7 0 0 0-1.7 1l-2.4-1-2 3.4L6.6 11a7.6 7.6 0 0 0 0 2l-2 1.6 2 3.4 2.4-1a7 7 0 0 0 1.7 1l.4 2.5h4l.4-2.5a7 7 0 0 0 1.7-1l2.4 1 2-3.4zM13 15.5a3.5 3.5 0 1 1 0-7 3.5 3.5 0 0 1 0 7z"/></svg>',
    play: '<svg viewBox="0 0 24 24"><path d="M7 4.5v15l12-7.5z" fill="#fff" stroke="#fff" stroke-width="2" stroke-linejoin="round"/></svg>',
    home: '<svg viewBox="0 0 24 24" fill="#fff"><path d="M12 3 2 11.5h3V21h5.5v-6h3v6H19v-9.5h3z"/></svg>',
    undo: '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12a8 8 0 1 0 2.5-5.8"/><path d="M4 4v5h5"/></svg>',
    shuffle: '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h4l10 12h4M3 18h4l3-3.6M14 9.6 17 6h4M18 3l3 3-3 3M18 15l3 3-3 3"/></svg>',
    ok: '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 12.5l5 5L19.5 7"/></svg>',
    camera: '<svg viewBox="0 0 24 24" fill="#fff"><path d="M9 4 7.5 6H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-3.5L15 4z"/><circle cx="12" cy="13" r="4" fill="#9b4fe8"/><circle cx="12" cy="13" r="2.4" fill="#fff"/></svg>',
    gallery: '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.4" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="3"/><path d="M3 16l5-5 4 4 3-3 6 6"/><circle cx="16" cy="9" r="2" fill="#fff"/></svg>',
    reset: '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round"><path d="M5 5l14 14M19 5 5 19"/></svg>',
    left: '<svg viewBox="0 0 40 60"><path d="M30 6 8 30l22 24" fill="#ffd23f" stroke="#fff" stroke-width="6" stroke-linejoin="round"/></svg>',
    right: '<svg viewBox="0 0 40 60"><path d="M10 6l22 24-22 24" fill="#ffd23f" stroke="#fff" stroke-width="6" stroke-linejoin="round"/></svg>',
  };

  // ---------- state & saving ----------
  const ST = load();
  function load() { let s = null; try { s = JSON.parse(localStorage.getItem(KEY)); } catch (e) {} s = s || {}; return { char: s.char || 'c1', looks: s.looks || {}, gallery: s.gallery || [], sound: s.sound !== false, music: s.music !== false, tab: s.tab || 'dress' }; }
  function save() { try { localStorage.setItem(KEY, JSON.stringify({ char: ST.char, looks: ST.looks, gallery: ST.gallery, sound: ST.sound, music: ST.music, tab: ST.tab })); } catch (e) {} }
  const charOf = (id) => DATA.CHARS.find((c) => c.id === id) || DATA.CHARS[0];
  function defaultLook(ch) { return { slots: clone(ch.slots || {}), hair: clone(ch.hair), makeup: {}, bg: 'room' }; }
  function look() { if (!ST.looks[ST.char]) ST.looks[ST.char] = defaultLook(charOf(ST.char)); return ST.looks[ST.char]; }
  let UNDO = [];
  function change(fn) { UNDO.push(clone(look())); if (UNDO.length > 40) UNDO.shift(); fn(look()); save(); }

  // ---------- sound (synthesised, no files) ----------
  let AC = null, musicTimer = null;
  function ac() { if (!AC) { try { AC = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) {} } if (AC && AC.state === 'suspended') AC.resume(); return AC; }
  function tone(f1, f2, dur, type, vol, delay) {
    if (!ST.sound) return; const a = ac(); if (!a) return; const t = a.currentTime + (delay || 0);
    const o = a.createOscillator(), g = a.createGain(); o.type = type || 'sine'; o.frequency.setValueAtTime(f1, t); if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + dur);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol || 0.18, t + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + dur); o.connect(g).connect(a.destination); o.start(t); o.stop(t + dur + 0.05);
  }
  const SFX = {
    click: () => tone(620, 900, 0.09, 'triangle', 0.14),
    pick: () => { tone(520, 1180, 0.12, 'triangle', 0.16); [1568, 2093, 2637].forEach((f, i) => tone(f, 0, 0.18, 'sine', 0.06, 0.06 + i * 0.05)); },
    remove: () => tone(700, 280, 0.16, 'sine', 0.14),
    win: () => [523, 659, 784, 1047, 1319].forEach((f, i) => tone(f, 0, 0.32, 'triangle', 0.14, i * 0.09)),
  };
  function music(on) {
    clearInterval(musicTimer); musicTimer = null; if (!on || !ST.music) return;
    const notes = [659, 784, 880, 784, 659, 587, 523, 587, 659, 784, 1047, 880, 784, 659, 587, 659], bass = [262, 196, 220, 175]; let i = 0;
    musicTimer = setInterval(() => { const a = ac(); if (!a || !ST.music || document.hidden) return; const t = a.currentTime;
      const n = notes[i % notes.length]; const o = a.createOscillator(), g = a.createGain(); o.type = 'sine'; o.frequency.value = n; g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.035, t + 0.03); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.34); o.connect(g).connect(a.destination); o.start(t); o.stop(t + 0.4);
      if (i % 4 === 0) { const b = a.createOscillator(), bg = a.createGain(); b.type = 'triangle'; b.frequency.value = bass[(i / 4) % 4] / 2; bg.gain.setValueAtTime(0.0001, t); bg.gain.exponentialRampToValueAtTime(0.04, t + 0.04); bg.gain.exponentialRampToValueAtTime(0.0001, t + 1.2); b.connect(bg).connect(a.destination); b.start(t); b.stop(t + 1.3); }
      i++; }, 340);
  }
  let started = false; function firstTouch() { if (started) return; started = true; ac(); music(true); }
  document.addEventListener('pointerdown', firstTouch, { capture: true });

  // ---------- effects ----------
  function sparkles(x, y, n) {
    const fx = $('#fx'); for (let i = 0; i < (n || 12); i++) { const s = document.createElement('div'); s.className = 'spark'; s.textContent = rnd(['✨', '⭐', '💖', '🌟', '💫']); s.style.left = x + 'px'; s.style.top = y + 'px'; const a = Math.random() * Math.PI * 2, d = 60 + Math.random() * 120; s.style.setProperty('--dx', Math.cos(a) * d + 'px'); s.style.setProperty('--dy', Math.sin(a) * d + 'px'); fx.appendChild(s); setTimeout(() => s.remove(), 950); }
  }
  function confetti() { const fx = $('#fx'); for (let i = 0; i < 40; i++) { const c = document.createElement('div'); c.className = 'confetti'; c.textContent = rnd(['⭐', '💖', '✨', '🎀', '🌸', '👑']); c.style.left = Math.random() * 100 + 'vw'; c.style.animationDuration = 1.8 + Math.random() * 1.6 + 's'; c.style.animationDelay = Math.random() * 0.5 + 's'; fx.appendChild(c); setTimeout(() => c.remove(), 4200); } }
  const PRAISE = ['رائع! ✨', 'ما أجمل هذا! 💖', 'اختيار موفق! 🌟', 'تبدين كالأميرة! 👑', 'أحسنتِ! 🎀', 'ذوق جميل! 💫', 'إطلالة مدهشة! 🌸'];
  function say(t) { const b = $('.bubble'); if (!b) return; b.textContent = t; b.style.animation = 'none'; void b.offsetWidth; b.style.animation = ''; }

  // fit each drawn thumbnail to its real drawing bounds so every item fills its tile
  function fitTiles(root) {
    $$('.tile svg', root).forEach((sv) => { if (sv.querySelector('image')) return; try { const b = sv.getBBox(); if (!b.width || !b.height) return; const m = Math.max(b.width, b.height) * 0.1, sz = Math.max(b.width, b.height) + m * 2; sv.setAttribute('viewBox', (b.x + b.width / 2 - sz / 2) + ' ' + (b.y + b.height / 2 - sz / 2) + ' ' + sz + ' ' + sz); } catch (e) {} });
  }
  // ---------- modal ----------
  function modal(html, bind) { const m = $('#modal'); m.innerHTML = '<div class="mbox">' + html + '</div>'; m.classList.add('on'); m.onclick = (e) => { if (e.target === m) closeModal(); }; if (bind) bind(m); }
  function closeModal() { const m = $('#modal'); m.classList.remove('on'); m.innerHTML = ''; }
  function settings() {
    SFX.click();
    modal('<h2>⚙️ الإعدادات</h2><div class="mrow">المؤثرات الصوتية <button class="tog ' + (ST.sound ? 'on' : '') + '" data-k="sound"></button></div><div class="mrow">الموسيقى <button class="tog ' + (ST.music ? 'on' : '') + '" data-k="music"></button></div><div class="mrow">مسح كل الإطلالات المحفوظة <button class="gl g-pink mbtn" data-reset>مسح</button></div><button class="gl g-purple mbtn" data-close>تم</button>', (m) => {
      $$('.tog', m).forEach((b) => (b.onclick = () => { ST[b.dataset.k] = !ST[b.dataset.k]; b.classList.toggle('on'); save(); if (b.dataset.k === 'music') music(ST.music); SFX.click(); refreshSoundBtn(); }));
      $('[data-reset]', m).onclick = () => { if (!confirm('هل تريدين مسح كل الإطلالات المحفوظة؟')) return; ST.looks = {}; ST.gallery = []; UNDO = []; save(); closeModal(); go(ROUTE.name); };
      $('[data-close]', m).onclick = closeModal;
    });
  }
  function refreshSoundBtn() { $$('[data-snd]').forEach((b) => (b.innerHTML = ST.sound ? ICON.sound : ICON.mute)); }
  function topRight() { return '<div class="topR"><button class="gl g-purple round" data-set>' + ICON.gear + '</button><button class="gl g-pink round" data-snd>' + (ST.sound ? ICON.sound : ICON.mute) + '</button></div>'; }
  function bindTop(root) { $('[data-set]', root).onclick = settings; $('[data-snd]', root).onclick = () => { ST.sound = !ST.sound; save(); refreshSoundBtn(); SFX.click(); }; }

  // ---------- router (future screens are registered here too) ----------
  let ROUTE = { name: 'home' };
  const SCREENS = {};
  function go(name, arg) { ROUTE = { name, arg }; const app = $('#app'); app.innerHTML = ''; const el = document.createElement('div'); el.className = 'screen ' + name; app.appendChild(el); (SCREENS[name] || SCREENS.home)(el, arg); }

  // HOME
  SCREENS.home = (el) => {
    el.innerHTML = SC.scene('room') + '<img class="hero" src="assets/girl.webp" alt=""><img class="lolo-mascot" src="assets/fish.webp" alt=""><img class="logo" src="assets/logo.webp" alt="لولو ستايل">' + topRight() +
      '<button class="gl g-gold play" data-play aria-label="ابدئي">' + ICON.play + '</button>' +
      '<div class="sections"><button class="gl g-pink sec" data-go="dress"><span>👗</span>تلبيس</button><button class="gl g-purple sec" data-go="acc"><span>👑</span>إكسسوارات</button><button class="gl g-blue sec" data-go="makeup"><span>💄</span>مكياج</button><button class="gl g-orange sec" data-go="hair"><span>💇‍♀️</span>تسريحات</button><button class="gl g-teal sec" data-photo><span>📸</span>استوديو الصور</button></div>' +
      '<button class="games-btn" data-games>🎮 ألعاب لولو</button>';
    bindTop(el);
    $('[data-play]', el).onclick = () => { SFX.pick(); go('select'); };
    $$('[data-go]', el).forEach((b) => (b.onclick = () => { SFX.click(); ST.tab = b.dataset.go; save(); go('studio'); }));
    $('[data-photo]', el).onclick = () => { SFX.click(); go('soon', 'photo'); };
    $('[data-games]', el).onclick = () => { SFX.click(); if (history.length > 1) history.back(); else location.href = '/'; };
  };

  // CHARACTER SELECT
  SCREENS.select = (el) => {
    let sel = ST.char;
    el.innerHTML = SC.scene('room') + '<img class="logo" src="assets/logo.webp" alt=""><div class="gl g-purple title-pill"><span class="crown">👑</span>اختاري شخصيتك</div>' + topRight() +
      '<div class="cards">' + DATA.CHARS.map((c) => '<button class="card" data-c="' + c.id + '"><img src="' + c.img + '" alt="' + c.name + '"><div class="nm">' + c.name + '</div></button>').join('') + '</div>' +
      '<button class="arrow" style="right:3%" data-prev>' + ICON.right + '</button><button class="arrow" style="left:3%" data-next>' + ICON.left + '</button>' +
      '<img class="lolo-mascot" src="assets/fish.webp" alt=""><button class="gl g-gold start" data-start><span class="pb">' + ICON.play.replace('<svg', '<svg width="34" height="34"') + '</span>ابدئي التلبيس 👗</button><button class="gl g-purple round homeBtn" data-home>' + ICON.home + '</button>';
    bindTop(el);
    const paint = () => $$('.card', el).forEach((c) => { const on = c.dataset.c === sel; c.classList.toggle('on', on); const k = $('.check', c); if (on && !k) c.insertAdjacentHTML('beforeend', '<div class="check">✓</div>'); if (!on && k) k.remove(); });
    paint();
    $$('.card', el).forEach((c) => (c.onclick = () => { sel = c.dataset.c; SFX.pick(); paint(); const r = c.getBoundingClientRect(); sparkles(r.left + r.width / 2, r.top + r.height / 2, 8); }));
    const step = (d) => { const i = DATA.CHARS.findIndex((c) => c.id === sel); sel = DATA.CHARS[(i + d + DATA.CHARS.length) % DATA.CHARS.length].id; SFX.click(); paint(); };
    $('[data-prev]', el).onclick = () => step(-1); $('[data-next]', el).onclick = () => step(1);
    $('[data-start]', el).onclick = () => { ST.char = sel; ST.tab = 'dress'; UNDO = []; save(); SFX.win(); go('studio'); };
    $('[data-home]', el).onclick = () => { SFX.click(); go('home'); };
  };

  // STUDIO (dress up · accessories · hair salon · makeup · backgrounds)
  let subTab = {};
  SCREENS.studio = (el) => {
    const ch = charOf(ST.char);
    el.innerHTML = '<div class="side"><img class="logo" src="assets/logo.webp" alt=""><div class="menu">' + DATA.MENU.map((m) => '<button class="mi" data-tab="' + m.id + '"><span>' + m.name + '</span><span class="ic">' + m.icon + '</span></button>').join('') + '</div><button class="gl g-purple round" data-home style="align-self:center">' + ICON.home + '</button></div>' +
      '<div class="stage"><div class="scene-wrap"></div><div class="podium"></div><div class="doll-wrap"></div><img class="lolo-mascot" src="assets/fish.webp" alt=""><div class="bubble">هيا نختار إطلالة جميلة لـ' + ch.name + '! ✨</div>' +
      '<div class="actions"><button class="gl g-purple round" data-undo title="تراجع">' + ICON.undo + '</button><button class="gl g-purple round" data-rand title="عشوائي">' + ICON.shuffle + '</button><button class="gl g-green round ok" data-ok title="تأكيد">' + ICON.ok + '</button><button class="gl g-purple round" data-photo title="صورة">' + ICON.camera + '</button><button class="gl g-purple round" data-gal title="إطلالاتي">' + ICON.gallery + '</button><button class="gl g-pink round" data-reset title="إعادة التعيين">' + ICON.reset + '</button></div></div>' +
      '<div class="panel"><div class="gl g-pink ptitle"></div><div class="pbody" style="display:flex;flex-direction:column;min-height:0;flex:1"></div></div>' + topRight();
    bindTop(el);
    $('.topR', el).style.cssText += ';left:auto;right:calc(min(31vw,9999px) + 20px)';
    if (window.matchMedia('(max-aspect-ratio:1/1)').matches) { const tr = $('.topR', el); tr.style.cssText = 'position:absolute;top:' + ($('.menu', el).getBoundingClientRect().bottom + 10) + 'px;left:10px;right:auto'; const hb = $('[data-home]', el); hb.style.cssText = 'width:50px;height:50px'; tr.appendChild(hb); $$('.round', tr).forEach((b) => (b.style.cssText = 'width:50px;height:50px')); }
    $$('.mi', el).forEach((b) => (b.onclick = () => { ST.tab = b.dataset.tab; save(); SFX.click(); paintPanel(); }));
    $('[data-home]', el).onclick = () => { SFX.click(); go('home'); };
    $('[data-undo]', el).onclick = () => { if (!UNDO.length) { say('لا يوجد شيء للتراجع عنه'); return; } ST.looks[ST.char] = UNDO.pop(); save(); SFX.remove(); paintDoll(); paintPanel(); say('تم التراجع ↩️'); };
    $('[data-rand]', el).onclick = () => { change(randomize); SFX.pick(); paintDoll(true); paintPanel(); say(rnd(PRAISE)); };
    $('[data-reset]', el).onclick = () => { change((l) => Object.assign(l, defaultLook(ch))); SFX.remove(); paintDoll(); paintPanel(); say('عادت الإطلالة كما كانت 🔄'); };
    $('[data-ok]', el).onclick = () => { ST.gallery.unshift({ char: ST.char, look: clone(look()), at: Date.now() }); ST.gallery = ST.gallery.slice(0, 30); save(); SFX.win(); confetti(); say('أحسنتِ! حُفظت إطلالتك في معرض إطلالاتي 💖'); };
    $('[data-photo]', el).onclick = () => { SFX.click(); photo(); };
    $('[data-gal]', el).onclick = () => { SFX.click(); go('gallery'); };
    paintDoll(); paintPanel();

    function paintDoll(hop) {
      const l = look(); $('.scene-wrap', el).innerHTML = SC.scene(l.bg || 'room');
      const w = $('.doll-wrap', el); w.innerHTML = AV.render(ch, l);
      if (hop) { w.classList.remove('hop'); void w.offsetWidth; w.classList.add('hop'); const r = w.getBoundingClientRect(); sparkles(r.left + r.width / 2, r.top + r.height * 0.45, 14); }
    }
    function tileItem(it, slot) { const on = look().slots[slot] === it.id; return '<button class="tile ' + (on ? 'on' : '') + '" data-it="' + it.id + '" title="' + it.name + '">' + AV.renderItem(it) + (it.unlocked ? '' : '<div class="lock">🔒</div>') + '</button>'; }
    function noneTile(slot) { return '<button class="tile none ' + (look().slots[slot] ? '' : 'on') + '" data-none="' + slot + '"><span><b>🚫</b>بدون</span></button>'; }
    function itemsFor(sub) { return DATA.ITEMS.filter((i) => i.sub === sub && (i.compat === 'all' || i.compat.includes(ST.char))); }
    function paintPanel() {
      const tab = ST.tab, m = DATA.MENU.find((x) => x.id === tab) || DATA.MENU[0];
      $$('.mi', el).forEach((b) => b.classList.toggle('on', b.dataset.tab === tab));
      $('.ptitle', el).textContent = m.icon + ' ' + (tab === 'hair' ? 'صالون الشعر' : tab === 'acc' ? 'الإكسسوارات' : tab === 'makeup' ? 'استوديو المكياج' : tab === 'bg' ? 'الخلفيات' : m.name);
      const body = $('.pbody', el); let h = '';
      if (m.tabs) {
        const cur = subTab[tab] || m.tabs[0].sub; subTab[tab] = cur;
        if (m.tabs.length > 1) h += '<div class="subtabs">' + m.tabs.map((t) => '<button class="st ' + (t.sub === cur ? 'on' : '') + '" data-sub="' + t.sub + '"><b>' + t.icon + '</b>' + t.name + '</button>').join('') + '</div>';
        const list = itemsFor(cur), slot = list[0] ? list[0].slot : cur;
        h += '<div class="grid">' + noneTile(slot) + list.map((it) => tileItem(it, it.slot)).join('') + '</div>';
      } else if (tab === 'hair') {
        const l = look(), hijab = l.hair.style === 'hijab';
        const styles = ch.art ? DATA.HAIR_STYLES.filter((x) => ch.art.hair[x.id] !== undefined) : DATA.HAIR_STYLES;
        h += '<div class="grid hgrid" style="flex:1 1 55%">' + styles.map((s) => '<button class="tile ' + (l.hair.style === s.id ? 'on' : '') + '" data-hs="' + s.id + '" title="' + s.name + '">' + (ch.art ? AV.renderArtHairThumb(ch, s.id, l.hair.color) : AV.renderHairThumb(s.id, s.id === 'hijab' ? (hijab ? l.hair.color : '#c9b3ff') : (hijab ? ch.hair.color : l.hair.color), ch.skin)) + '</button>').join('') + '</div>';
        h += '<div class="gl g-purple label-pill">🎨 ' + (hijab ? 'لون الحجاب' : 'لون الشعر') + '</div><div class="sec-box sw-row">' + (hijab ? DATA.HIJAB_COLORS : DATA.HAIR_COLORS).map((c) => '<button class="sw ' + (c === 'rainbow' ? 'rb ' : '') + (l.hair.color === c ? 'on' : '') + '" data-hc="' + c + '" style="' + (c === 'rainbow' ? '' : 'background:radial-gradient(circle at 35% 30%,' + AV.util.light(c, 0.35) + ',' + c + ' 55%,' + AV.util.dark(c, 0.2) + ')') + '"></button>').join('') + '</div>';
        h += '<div class="gl g-purple label-pill">🎀 إكسسوارات الشعر</div><div class="grid" style="flex:0 0 auto;max-height:30%;grid-template-columns:repeat(auto-fill,minmax(70px,1fr))">' + noneTile('hairacc') + itemsFor('hairacc').map((it) => tileItem(it, 'hairacc')).join('') + '</div>';
      } else if (tab === 'makeup') {
        const keys = Object.keys(DATA.MAKEUP).filter((k) => !ch.art || !['eyes', 'lips'].includes(k)); if (!keys.includes(subTab.makeup)) subTab.makeup = keys[0]; const cur = subTab.makeup || keys[0]; subTab.makeup = cur; const mk = look().makeup || {}, M = DATA.MAKEUP[cur];
        h += '<div class="subtabs">' + keys.map((k) => '<button class="st ' + (k === cur ? 'on' : '') + '" data-msub="' + k + '"><b>' + DATA.MAKEUP[k].icon + '</b>' + DATA.MAKEUP[k].name + '</button>').join('') + '</div>';
        if (M.colors) h += '<div class="sec-box sw-row" style="margin-top:10px"><button class="sw none ' + (mk[cur] ? '' : 'on') + '" data-mk="">🚫</button>' + M.colors.map((c) => '<button class="sw ' + (mk[cur] === c ? 'on' : '') + '" data-mk="' + c + '" style="background:radial-gradient(circle at 35% 30%,' + AV.util.light(c, 0.4) + ',' + c + ' 60%,' + AV.util.dark(c, 0.15) + ')"></button>').join('') + '</div>';
        else h += '<div class="grid"><button class="tile none ' + (mk.sticker ? '' : 'on') + '" data-mk=""><span><b>🚫</b>بدون</span></button>' + M.options.map((o) => '<button class="tile ' + (mk.sticker === o ? 'on' : '') + '" data-mk="' + o + '" style="font-size:42px">' + { star: '⭐', heart: '💖', sparkle: '✨', rainbow: '🌈', stars2: '🌟' }[o] + '</button>').join('') + '</div>';
        h += '<div style="flex:1;display:grid;place-items:center;font-size:56px;opacity:.9">💄🖌️💅</div>';
      } else if (tab === 'bg') {
        h += '<div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(140px,1fr))">' + DATA.BACKGROUNDS.map((b) => '<button class="tile bg ' + ((look().bg || 'room') === b.id ? 'on' : '') + '" data-bg="' + b.id + '" title="' + b.name + '">' + SC.scene(b.id, '') + '</button>').join('') + '</div>';
      }
      body.innerHTML = h;
      fitTiles(body);
      $$('[data-sub]', body).forEach((b) => (b.onclick = () => { subTab[tab] = b.dataset.sub; SFX.click(); paintPanel(); }));
      $$('[data-msub]', body).forEach((b) => (b.onclick = () => { subTab.makeup = b.dataset.msub; SFX.click(); paintPanel(); }));
      $$('[data-it]', body).forEach((b) => (b.onclick = () => pick(DATA.itemsById[b.dataset.it])));
      $$('[data-none]', body).forEach((b) => (b.onclick = () => { const s = b.dataset.none; if (!look().slots[s]) return; change((l) => { delete l.slots[s]; }); SFX.remove(); paintDoll(); paintPanel(); }));
      $$('[data-hs]', body).forEach((b) => (b.onclick = () => { const st = b.dataset.hs; change((l) => { const was = l.hair.style; l.hair.style = st; if (st === 'hijab' && was !== 'hijab') l.hair.color = '#f4f1f6'; if (st !== 'hijab' && was === 'hijab') l.hair.color = ch.hair.style === 'hijab' ? '#4a2614' : ch.hair.color; }); SFX.pick(); paintDoll(true); paintPanel(); say(rnd(PRAISE)); }));
      $$('[data-hc]', body).forEach((b) => (b.onclick = () => { change((l) => { l.hair.color = b.dataset.hc; }); SFX.pick(); paintDoll(true); paintPanel(); }));
      $$('[data-mk]', body).forEach((b) => (b.onclick = () => { const k = subTab.makeup, v = b.dataset.mk; change((l) => { l.makeup = l.makeup || {}; if (v) l.makeup[k] = v; else delete l.makeup[k]; }); v ? SFX.pick() : SFX.remove(); paintDoll(!!v); paintPanel(); if (v) say(rnd(PRAISE)); }));
      $$('[data-bg]', body).forEach((b) => (b.onclick = () => { change((l) => { l.bg = b.dataset.bg; }); SFX.pick(); paintDoll(); paintPanel(); }));
    }
    function pick(it) {
      if (!it) return; if (!it.unlocked) { say('هذه القطعة مقفلة 🔒'); return; }
      const cur = look().slots[it.slot] === it.id;
      change((l) => {
        if (cur) { delete l.slots[it.slot]; return; }
        l.slots[it.slot] = it.id;
        if (it.slot === 'dress') { delete l.slots.top; delete l.slots.bottom; }
        if (it.slot === 'top' || it.slot === 'bottom') delete l.slots.dress;
      });
      if (cur) { SFX.remove(); paintDoll(); } else { SFX.pick(); paintDoll(true); say(rnd(PRAISE)); }
      paintPanel();
    }
    function randomize(l) {
      const by = (sub) => itemsFor(sub);
      l.slots = {};
      if (Math.random() < 0.6) l.slots.dress = rnd(by('dress')).id; else { l.slots.top = rnd(by('top')).id; l.slots.bottom = rnd(by(Math.random() < 0.5 ? 'skirt' : 'pants')).id; }
      l.slots.shoes = rnd(by('shoes')).id;
      if (ch.art) l.hair = { style: rnd(Object.keys(ch.art.hair)), color: Math.random() < 0.6 ? ch.hair.color : rnd(DATA.HAIR_COLORS) };
      else if (ch.hair.style !== 'hijab') { l.hair = { style: rnd(DATA.HAIR_STYLES.filter((s) => s.id !== 'hijab')).id, color: Math.random() < 0.7 ? rnd(DATA.HAIR_COLORS.slice(0, 5)) : rnd(DATA.HAIR_COLORS) }; }
      else l.hair = { style: 'hijab', color: rnd(DATA.HIJAB_COLORS) };
      ['headwear', 'hairacc', 'glasses', 'earrings', 'necklace', 'bracelet', 'bag'].forEach((sub) => { if (Math.random() < 0.4) l.slots[sub] = rnd(by(sub)).id; });
      if (l.slots.headwear && l.slots.hairacc && Math.random() < 0.6) delete l.slots.hairacc;
      l.makeup = {}; if (Math.random() < 0.5) l.makeup.shadow = rnd(DATA.MAKEUP.shadow.colors); if (Math.random() < 0.5) l.makeup.lips = rnd(DATA.MAKEUP.lips.colors); if (Math.random() < 0.3) l.makeup.sticker = rnd(DATA.MAKEUP.sticker.options);
      l.bg = rnd(DATA.BACKGROUNDS).id;
    }
  };

  // PHOTO (saves an image of the current look with its background)
  function photo() {
    const ch = charOf(ST.char), l = look();
    const doll = AV.render(ch, l).replace('<svg ', '<svg x="560" y="60" width="480" height="830" ');
    const svg = '<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="900" viewBox="0 0 1600 900">' + SC.raw(l.bg || 'room') + '<ellipse cx="800" cy="860" rx="220" ry="40" fill="#f3c6f5"/>' + doll + '</svg>';
    const img = new Image(), url = URL.createObjectURL(new Blob([svg], { type: 'image/svg+xml' }));
    img.onload = () => {
      const c = document.createElement('canvas'); c.width = 1600; c.height = 900; const x = c.getContext('2d'); x.drawImage(img, 0, 0); URL.revokeObjectURL(url);
      const logo = new Image(); logo.onload = () => { x.drawImage(logo, 24, 18, 300, 300 * logo.height / logo.width); done(); }; logo.onerror = done; logo.src = 'assets/logo.webp';
      function done() { let data; try { data = c.toDataURL('image/png'); } catch (e) { data = null; } modal('<h2>📸 صورتك جاهزة!</h2>' + (data ? '<img class="photo" src="' + data + '" alt=""><div><a class="gl g-green mbtn" style="display:inline-block;text-decoration:none" download="lolo-style.png" href="' + data + '">⬇️ حفظ الصورة</a></div><p style="font-weight:700;color:#8a2fd0">على الموبايل: اضغطي مطولًا على الصورة لحفظها</p>' : '<p>تعذّر إنشاء الصورة</p>') + '<button class="gl g-purple mbtn" data-close>إغلاق</button>', (m) => { $('[data-close]', m).onclick = closeModal; }); }
    };
    img.src = url;
  }

  // SAVED LOOKS GALLERY
  SCREENS.gallery = (el) => {
    el.innerHTML = SC.scene('room') + '<div class="gl g-purple title-pill"><span class="crown">🖼️</span>إطلالاتي</div>' + topRight() + (ST.gallery.length ? '<div class="gal">' + ST.gallery.map((g, i) => '<div class="gcard"><div class="av">' + AV.render(charOf(g.char), g.look, { cls: 'mini' }) + '</div><div>' + charOf(g.char).name + '</div><div class="row"><button class="gl g-green" data-wear="' + i + '">ارتدي 👗</button><button class="gl g-pink" data-del="' + i + '">حذف</button></div></div>').join('') + '</div>' : '<div class="empty">لا توجد إطلالات محفوظة بعد 💖<br>اضغطي ✓ في استوديو التلبيس لحفظ إطلالتك</div>') + '<button class="gl g-purple round homeBtn" data-back>' + ICON.home + '</button>';
    bindTop(el);
    $('[data-back]', el).onclick = () => { SFX.click(); go('studio'); };
    $$('[data-wear]', el).forEach((b) => (b.onclick = () => { const g = ST.gallery[+b.dataset.wear]; ST.char = g.char; ST.looks[g.char] = clone(g.look); UNDO = []; save(); SFX.pick(); go('studio'); }));
    $$('[data-del]', el).forEach((b) => (b.onclick = () => { ST.gallery.splice(+b.dataset.del, 1); save(); SFX.remove(); go('gallery'); }));
  };

  // FUTURE SCREENS (routes ready; content comes in the next phases)
  const SOON = { photo: { t: 'استوديو الصور', i: '📸' }, runway: { t: 'منصة عرض الأزياء', i: '💃' }, preview: { t: 'عرض الإطلالة النهائية', i: '✨' }, rewards: { t: 'النجوم والجوائز', i: '⭐' } };
  SCREENS.soon = (el, k) => {
    const s = SOON[k] || SOON.photo;
    el.innerHTML = SC.scene(k === 'runway' ? 'stage' : 'room') + topRight() + '<div class="soon"><img src="assets/fish.webp" style="width:160px" class="lolo-mascot" alt=""><div class="card2"><h1>' + s.i + ' ' + s.t + '</h1><p>قريبًا جدًّا في لولو ستايل!</p><p style="font-size:18px;color:#8a2fd0">حتى ذلك الحين يمكنك حفظ صورة إطلالتك من زر 📸 في استوديو التلبيس</p></div><button class="gl g-gold start" style="position:static;transform:none" data-studio>👗 إلى استوديو التلبيس</button></div><button class="gl g-purple round homeBtn" data-home>' + ICON.home + '</button>';
    $('.soon .lolo-mascot', el).style.position = 'static';
    bindTop(el);
    $('[data-studio]', el).onclick = () => { SFX.click(); go('studio'); };
    $('[data-home]', el).onclick = () => { SFX.click(); go('home'); };
  };

  G.LOLO_STYLE = { go, state: ST, data: DATA, SOON };
  go('home');
})(window);
