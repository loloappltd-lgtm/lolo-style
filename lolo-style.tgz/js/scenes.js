/* LOLO STYLE — background scenes (vector, 1600×900). New scenes: add a function here + an entry in data.js BACKGROUNDS. */
(function (G) {
  'use strict';
  const U = () => G.LS_AVATAR.util;
  function sparkles(n, seed, color) {
    let o = '', s = seed || 7; const r = () => ((s = (s * 9301 + 49297) % 233280) / 233280);
    for (let i = 0; i < n; i++) o += U().sparkle(Math.round(r() * 1600), Math.round(r() * 600), Math.round(6 + r() * 12), color || '#ffffff');
    return '<g opacity=".85">' + o + '</g>';
  }
  function castle(x, y, s, c) {
    const d = G.LS_AVATAR.util.dark(c, 0.15);
    let o = '<g transform="translate(' + x + ',' + y + ') scale(' + s + ')">';
    [[-120, 60, 50, 160], [70, 60, 50, 160], [-60, 0, 120, 220], [-20, -60, 40, 120]].forEach(([a, b, w, h]) => { o += '<rect x="' + a + '" y="' + b + '" width="' + w + '" height="' + h + '" fill="' + c + '"/><path d="M' + (a - 8) + ',' + b + ' L' + (a + w / 2) + ',' + (b - w * 1.1) + ' L' + (a + w + 8) + ',' + b + 'Z" fill="' + d + '"/>'; });
    return o + '<path d="M-20,220 v-50 a20,20 0 0 1 40,0 v50Z" fill="' + d + '"/></g>';
  }
  const S = {
    room: () => '<defs><linearGradient id="rw" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e9c8ff"/><stop offset="1" stop-color="#f6d8f3"/></linearGradient><linearGradient id="rf" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f7cdea"/><stop offset="1" stop-color="#eaa8d8"/></linearGradient><linearGradient id="sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#9fd8ff"/><stop offset="1" stop-color="#e6f6ff"/></linearGradient></defs>' +
      '<rect width="1600" height="900" fill="url(#rw)"/><path d="M620,620 V220 a180,180 0 0 1 360,0 V620Z" fill="url(#sky)" stroke="#fff" stroke-width="18"/>' + castle(800, 430, 0.9, '#ffc4e6') + '<path d="M800,240 V620 M620,420 H980" stroke="#fff" stroke-width="10"/>' +
      '<path d="M0,0 H330 Q300,300 360,640 H0Z" fill="#d48cf0" opacity=".9"/><path d="M1600,0 H1270 Q1300,300 1240,640 H1600Z" fill="#d48cf0" opacity=".9"/><path d="M40,0 Q120,300 80,640 M180,0 Q240,320 220,640 M1560,0 Q1480,300 1520,640 M1420,0 Q1360,320 1380,640" stroke="#c070e0" stroke-width="8" fill="none" opacity=".6"/>' +
      '<rect y="620" width="1600" height="280" fill="url(#rf)"/><path d="M0,700 H1600 M0,790 H1600 M200,620 L80,900 M600,620 L560,900 M1000,620 L1040,900 M1400,620 L1520,900" stroke="#fff" stroke-width="3" opacity=".35"/>' +
      '<ellipse cx="800" cy="790" rx="420" ry="70" fill="#f3b6e2"/><ellipse cx="800" cy="790" rx="380" ry="58" fill="#f9cdee"/>' +
      '<g transform="translate(260,250)"><ellipse rx="110" ry="160" fill="#ffd36b"/><ellipse rx="92" ry="142" fill="#cfe9ff"/>' + Array.from({ length: 12 }, (_, i) => { const a = i / 12 * Math.PI * 2; return '<circle cx="' + (118 * Math.cos(a)).toFixed(0) + '" cy="' + (168 * Math.sin(a)).toFixed(0) + '" r="14" fill="#fff8d6"/>'; }).join('') + '</g>' +
      '<g transform="translate(1340,330)"><rect x="-120" y="-160" width="240" height="320" rx="20" fill="#fbe1f4" stroke="#e7a8d6" stroke-width="6"/><path d="M-100,-120 H100" stroke="#e0a000" stroke-width="8"/>' + ['#ff8fc8', '#b48cff', '#7fc8ff', '#ffd23f'].map((c, i) => '<path d="M' + (-80 + i * 50) + ',-118 l-22,90 h44z" fill="' + c + '"/>').join('') + '</g>' + sparkles(26, 3),
    castle: () => '<defs><linearGradient id="cs" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8fd3ff"/><stop offset="1" stop-color="#ffe3f4"/></linearGradient></defs><rect width="1600" height="900" fill="url(#cs)"/>' +
      [[250, 150], [1250, 120], [800, 90]].map(([x, y]) => '<g fill="#fff" opacity=".9"><circle cx="' + x + '" cy="' + y + '" r="46"/><circle cx="' + (x + 50) + '" cy="' + (y + 10) + '" r="36"/><circle cx="' + (x - 50) + '" cy="' + (y + 12) + '" r="32"/></g>').join('') + castle(800, 360, 1.5, '#ffc4e6') +
      '<path d="M0,600 Q400,520 800,590 T1600,570 V900 H0Z" fill="#8fe08a"/><path d="M0,690 Q500,620 1000,690 T1600,680 V900 H0Z" fill="#6fcf6a"/>' + Array.from({ length: 30 }, (_, i) => U().flower(((i * 137) % 1600), 700 + ((i * 53) % 180), 12, ['#ff8fc8', '#fff', '#ffd23f', '#b48cff'][i % 4], '#ffd93d')).join('') + sparkles(14, 9),
    stage: () => '<rect width="1600" height="900" fill="#3a1a6e"/>' + [[300, '#ff8fc8'], [800, '#ffd23f'], [1300, '#8fd3ff']].map(([x, c]) => '<path d="M' + x + ',0 L' + (x - 260) + ',760 L' + (x + 260) + ',760Z" fill="' + c + '" opacity=".16"/>').join('') +
      '<path d="M0,0 H260 Q220,400 300,760 H0Z M1600,0 H1340 Q1380,400 1300,760 H1600Z" fill="#e0408f"/><path d="M0,0 H1600 V90 Q800,150 0,90Z" fill="#c42f7a"/>' + Array.from({ length: 20 }, (_, i) => '<circle cx="' + (40 + i * 80) + '" cy="96" r="9" fill="#ffe27a"/>').join('') +
      '<path d="M380,680 H1220 L1400,900 H200Z" fill="#7b4bc4"/><path d="M380,680 H1220" stroke="#ffe27a" stroke-width="8"/>' + Array.from({ length: 10 }, (_, i) => '<circle cx="' + (420 + i * 85) + '" cy="690" r="6" fill="#fff"/>').join('') + sparkles(40, 5, '#ffe9ff'),
    beach: () => '<defs><linearGradient id="bs" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7fd1ff"/><stop offset="1" stop-color="#d9f4ff"/></linearGradient></defs><rect width="1600" height="900" fill="url(#bs)"/><circle cx="1300" cy="170" r="90" fill="#ffd93d"/><circle cx="1300" cy="170" r="120" fill="#ffd93d" opacity=".25"/>' +
      '<rect y="470" width="1600" height="200" fill="#3fb8ec"/><path d="M0,520 Q100,505 200,520 T400,520 T600,520 T800,520 T1000,520 T1200,520 T1400,520 T1600,520" stroke="#fff" stroke-width="6" fill="none" opacity=".6"/><path d="M0,640 Q400,600 800,640 T1600,630 V900 H0Z" fill="#ffe2a8"/>' +
      '<g transform="translate(220,640)"><path d="M0,0 Q20,-160 -10,-300" stroke="#a0662f" stroke-width="26" fill="none"/>' + [-60, -20, 30, 70].map((a) => '<path d="M-10,-300 q' + a * 2 + ',-30 ' + a * 3 + ',40" stroke="#3fae4f" stroke-width="22" fill="none" stroke-linecap="round"/>').join('') + '</g>' + U().star(1200, 780, 24, '#ff9f80') + '<ellipse cx="1000" cy="800" rx="40" ry="14" fill="#fff" opacity=".6"/>',
    night: () => '<defs><linearGradient id="ns" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1d1450"/><stop offset="1" stop-color="#6a3fb8"/></linearGradient></defs><rect width="1600" height="900" fill="url(#ns)"/><circle cx="1260" cy="180" r="80" fill="#fff6c8"/><circle cx="1295" cy="160" r="72" fill="#2a1b62"/>' +
      Array.from({ length: 60 }, (_, i) => '<circle cx="' + ((i * 263) % 1600) + '" cy="' + ((i * 97) % 560) + '" r="' + (1 + (i % 3)) + '" fill="#fff"/>').join('') + sparkles(16, 11, '#ffe9a8') + '<path d="M0,640 Q400,560 800,630 T1600,610 V900 H0Z" fill="#3b2a7a"/><path d="M0,720 Q500,660 1000,720 T1600,710 V900 H0Z" fill="#2b1f5e"/>' + castle(1100, 470, 0.7, '#5a3fa8'),
    candy: () => '<defs><linearGradient id="cd" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffc6e8"/><stop offset="1" stop-color="#fff0d8"/></linearGradient></defs><rect width="1600" height="900" fill="url(#cd)"/>' +
      [[220, '#ff6fae'], [1380, '#8fd3ff'], [1100, '#ffd23f'], [420, '#b48cff']].map(([x, c], i) => '<path d="M' + x + ',' + (700 - i * 20) + ' V' + (380 + i * 30) + '" stroke="#fff" stroke-width="16"/><circle cx="' + x + '" cy="' + (330 + i * 30) + '" r="' + (80 - i * 8) + '" fill="' + c + '"/><path d="M' + (x - 60 + i * 8) + ',' + (330 + i * 30) + ' a' + (60 - i * 8) + ',' + (60 - i * 8) + ' 0 0 1 ' + (120 - i * 16) + ',0" stroke="#fff" stroke-width="12" fill="none"/>').join('') +
      '<path d="M0,650 Q300,560 600,640 T1200,630 T1600,600 V900 H0Z" fill="#ff9fcf"/><path d="M0,740 Q400,680 800,740 T1600,720 V900 H0Z" fill="#ffd1ea"/>' + Array.from({ length: 14 }, (_, i) => '<circle cx="' + (60 + i * 115) + '" cy="' + (760 + (i % 3) * 30) + '" r="12" fill="' + ['#ff5fae', '#ffd23f', '#58b4ff', '#7fe0b0'][i % 4] + '"/>').join('') + sparkles(20, 13),
  };
  function scene(id, cls) { return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1600 900" preserveAspectRatio="xMidYMid slice" class="' + (cls || 'scene') + '">' + (S[id] || S.room)() + '</svg>'; }
  G.LS_SCENES = { scene, raw: (id) => (S[id] || S.room)() };
})(window);
