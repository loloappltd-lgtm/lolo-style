/* LOLO STYLE — game data. Dresses use the approved art (assets/dresses/*.webp). Adding a new dress / bag / hairstyle = add one entry here (and, when final art is ready,
   point it to an image with `img` + `box` instead of `draw`). No engine code changes are needed.
   Item fields: id, name, cat, sub, slot, layer, draw|img, p (drawing params), box (x,y,w,h on the 400×760 doll),
                compat ('all' or [character ids]), unlocked, isDefault */
(function (G) {
  'use strict';
  const SLOT_LAYER = { dress: 'dress', top: 'top', bottom: 'bottom', shoes: 'shoes', headwear: 'headwear', hairacc: 'hairacc', glasses: 'glasses', earrings: 'earrings', necklace: 'necklace', bracelet: 'bracelet', bag: 'bag' };
  const ITEMS = [];
  function add(cat, sub, slot, list) { list.forEach((x) => ITEMS.push(Object.assign({ cat, sub, slot, layer: SLOT_LAYER[slot], compat: 'all', unlocked: true, isDefault: false }, x))); }

  // ---- dresses ----
  add('dress', 'dress', 'dress', [
    { id: 'd_pink', name: 'فستان الأميرة الوردي', img: 'assets/dresses/d01.webp', box: [83, 296, 234, 225], sf: 0.631 },
    { id: 'd_snow', name: 'فستان الثلج الأزرق', img: 'assets/dresses/d02.webp', box: [83, 296, 234, 243], sf: 0.656 },
    { id: 'd_purple', name: 'فستان بنفسجي لامع', img: 'assets/dresses/d03.webp', box: [83, 296, 234, 236], sf: 0.578 },
    { id: 'd_yellow', name: 'فستان الشمس الذهبي', img: 'assets/dresses/d04.webp', box: [83, 296, 234, 238], sf: 0.636 },
    { id: 'd_mermaid', name: 'فستان حورية البحر', img: 'assets/dresses/d05.webp', box: [83, 296, 234, 262], sf: 0.552 },
    { id: 'd_hearts', name: 'فستان القلوب الأحمر', img: 'assets/dresses/d06.webp', box: [83, 296, 234, 239], sf: 0.651 },
    { id: 'd_lilac', name: 'فستان زهرة الليلك', img: 'assets/dresses/d07.webp', box: [83, 296, 234, 204], sf: 0.579 },
    { id: 'd_star_gown', name: 'فستان ليلة النجوم', img: 'assets/dresses/d08.webp', box: [83, 296, 234, 219], sf: 0.586 },
    { id: 'd_rainbow', name: 'فستان قوس قزح', img: 'assets/dresses/d09.webp', box: [83, 296, 234, 208], sf: 0.598 },
    { id: 'd_green', name: 'فستان زهور الربيع', img: 'assets/dresses/d10.webp', box: [83, 296, 234, 209], sf: 0.574 },
    { id: 'd_pinkheart', name: 'فستان القلب الوردي', img: 'assets/dresses/d11.webp', box: [83, 296, 234, 207], sf: 0.583 },
    { id: 'd_ice', name: 'فستان الأميرة الجليدية', img: 'assets/dresses/d12.webp', box: [83, 296, 234, 214], sf: 0.627 },
    { id: 'd_sunny', name: 'فستان عبّاد الشمس', img: 'assets/dresses/d13.webp', box: [83, 296, 234, 197], sf: 0.555 },
    { id: 'd_roses', name: 'فستان الورود الوردي', img: 'assets/dresses/d14.webp', box: [83, 296, 234, 221], sf: 0.648 },
    { id: 'd_embroid', name: 'فستان الملكة الأبيض', img: 'assets/dresses/d15.webp', box: [83, 296, 234, 214], sf: 0.596 },
    { id: 'd_red', name: 'فستان الوردة الحمراء', img: 'assets/dresses/d16.webp', box: [83, 296, 234, 208], sf: 0.624 },
    { id: 'd_blue', name: 'فستان السماء', img: 'assets/dresses/d17.webp', box: [83, 296, 234, 213], sf: 0.598 },
    { id: 'd_butterfly', name: 'فستان الفراشة', img: 'assets/dresses/d18.webp', box: [83, 296, 234, 211], sf: 0.639 },
    { id: 'd_sailor', name: 'فستان البحّارة', img: 'assets/dresses/d19.webp', box: [83, 296, 234, 218], sf: 0.704 },
    { id: 'd_hoodie', name: 'فستان الهودي الوردي', img: 'assets/dresses/d20.webp', box: [83, 296, 234, 251], sf: 0.811 },
    { id: 'd_pinafore', name: 'فستان جينز بحمالات', img: 'assets/dresses/d21.webp', box: [83, 296, 234, 240], sf: 0.866 },
    { id: 'd_purplehoodie', name: 'فستان هودي بنفسجي', img: 'assets/dresses/d22.webp', box: [83, 296, 234, 246], sf: 0.885 },
    { id: 'd_rainbow2', name: 'فستان قوس قزح بالقلب', img: 'assets/dresses/d23.webp', box: [83, 296, 234, 224], sf: 0.681 },
    { id: 'd_cowgirl', name: 'فستان رعاة البقر', img: 'assets/dresses/d24.webp', box: [83, 296, 234, 231], sf: 0.714 },
  ]);
  // ---- tops ----
  add('top', 'top', 'top', [
    { id: 't_heart_art', name: 'بلوزة القلب الوردية', img: 'assets/c1/top_heart.webp', art: true, compat: ['c1'] },
    { id: 't_star', name: 'تيشيرت النجمة', draw: 'top', p: { color: '#ffffff', badge: 'star', collar: '#ff5fae' } },
    { id: 't_heart', name: 'تيشيرت القلب', draw: 'top', p: { color: '#ff8fc8', badge: 'heart' } },
    { id: 't_hoodie', name: 'هودي بنفسجي', draw: 'top', p: { color: '#8a5cf0', sleeves: 'long', sleeveColor: '#ffd23f', cuff: '#ffd23f', hood: true, pocket: true, badge: 'star' } },
    { id: 't_ruffle', name: 'بلوزة الكشكشة', draw: 'top', p: { color: '#ffd23f', ruffle: true } },
    { id: 't_sweater', name: 'سويتر أزرق', draw: 'top', p: { color: '#58b4ff', sleeves: 'long', pattern: 'snow', patternColor: '#ffffff' } },
    { id: 't_longwhite', name: 'بلوزة بيضاء بأكمام', draw: 'top', p: { color: '#fbf7ff', sleeves: 'long', collar: '#ff8fc8', buttons: '#ff8fc8', len: 470 } },
    { id: 't_stripes', name: 'تيشيرت مخطط', draw: 'top', p: { color: '#ffffff', pattern: 'stripes', patternColor: '#9fd8ff' } },
    { id: 't_cardigan', name: 'جاكيت وردي', draw: 'top', p: { color: '#ffb3d9', sleeves: 'long', buttons: '#ffffff', pattern: 'dots', patternColor: '#ffffff' } },
  ]);
  // ---- skirts ----
  add('bottom', 'skirt', 'bottom', [
    { id: 's_pleat', name: 'تنورة بليسيه', draw: 'skirt', p: { color: '#9b5cf0', pleats: true } },
    { id: 's_tutu', name: 'تنورة توتو', draw: 'skirt', p: { color: '#ff8fc8', tutu: true } },
    { id: 's_denim', name: 'تنورة جينز', draw: 'skirt', p: { color: '#4f86d9', flare: 18, len: 520, bow: '#ff8fc8' } },
    { id: 's_long', name: 'تنورة طويلة', draw: 'skirt', p: { color: '#ff7fbf', flare: 34, len: 660, pattern: 'dots', patternColor: '#ffffff' } },
    { id: 's_flower', name: 'تنورة الزهور', draw: 'skirt', p: { color: '#ffd23f', pattern: 'flowers', patternColor: '#ffffff' } },
    { id: 's_sparkle', name: 'تنورة لامعة', draw: 'skirt', p: { color: '#c79bff', pattern: 'sparkle', bow: '#ffffff' } },
  ]);
  // ---- pants ----
  add('bottom', 'pants', 'bottom', [
    { id: 'p_shorts', name: 'شورت وردي', draw: 'shorts', p: { color: '#ff6fb5', cuffs: true } },
    { id: 'p_jeans', name: 'بنطلون جينز', draw: 'pants', p: { color: '#4f86d9', seams: true, heart: true } },
    { id: 'p_overalls', name: 'سالوبيت بنفسجي', draw: 'overalls', p: { color: '#9b6bf0', badge: 'star' } },
    { id: 'p_overshort', name: 'سالوبيت قصير', draw: 'overalls', p: { color: '#5aa6ff', short: true, badge: 'star' } },
    { id: 'p_denimshorts', name: 'شورت جينز بقلب', draw: 'shorts', p: { color: '#5b8fe0', heart: true } },
    { id: 'p_leggings', name: 'بنطلون الليلك', draw: 'pants', p: { color: '#c9a3ff', pattern: 'stars', patternColor: '#ffffff' } },
  ]);
  // ---- shoes ----
  add('shoes', 'shoes', 'shoes', [
    { id: 'sh_mary', name: 'حذاء وردي بفيونكة', draw: 'shoes', p: { color: '#ff5fae', style: 'maryjane', bow: '#ffb3e0', socks: 'low' } },
    { id: 'sh_sneak', name: 'كوتشي وردي', draw: 'shoes', p: { color: '#ff7fbf', style: 'sneakers' } },
    { id: 'sh_boots_p', name: 'بوت بنفسجي', draw: 'shoes', p: { color: '#9b5cf0', style: 'boots', star: true } },
    { id: 'sh_boots_y', name: 'بوت أصفر', draw: 'shoes', p: { color: '#ffc93c', style: 'boots' } },
    { id: 'sh_ballet', name: 'باليرينا بنفسجي', draw: 'shoes', p: { color: '#b07bff', style: 'maryjane', star: true } },
    { id: 'sh_sandal', name: 'صندل الزهور', draw: 'shoes', p: { color: '#5ccfd4', style: 'sandals' } },
    { id: 'sh_blue', name: 'حذاء أزرق', draw: 'shoes', p: { color: '#58b4ff', style: 'maryjane', bow: '#ffffff', socks: 'low' } },
    { id: 'sh_white', name: 'كوتشي أبيض', draw: 'shoes', p: { color: '#ffffff', style: 'sneakers', sole: '#ff8fc8', socks: 'low', sockColor: '#ffe0ef' } },
  ]);
  // ---- accessories ----
  add('crown', 'headwear', 'headwear', [
    { id: 'h_gold', name: 'تاج ذهبي', draw: 'crown', p: { color: '#ffc93c', heart: true } },
    { id: 'h_silver', name: 'تاج فضي', draw: 'tiara', p: { color: '#dfe6f5', gem: '#4fb3ff' } },
    { id: 'h_pink', name: 'تاج وردي', draw: 'crown', p: { color: '#ff8fc8', gem: '#ff3d8e', gem2: '#ffffff', heart: true } },
    { id: 'h_tiara_gold', name: 'تاج الأميرة', draw: 'tiara', p: { color: '#ffc93c', gem: '#4fb3ff' } },
    { id: 'h_flowers', name: 'إكليل زهور', draw: 'flowercrown', p: { color: '#ffffff', color2: '#ffd1e8' } },
    { id: 'h_roses', name: 'إكليل ورود', draw: 'flowercrown', p: { color: '#ff4f7a', color2: '#ff8fb1', rose: true } },
    { id: 'h_straw', name: 'قبعة القش', draw: 'strawhat', p: { ribbon: '#ff5fae' } },
    { id: 'h_cap', name: 'كاب بنفسجي', draw: 'cap', p: { color: '#8a5cf0' } },
  ]);
  add('crown', 'hairacc', 'hairacc', [
    { id: 'b_pink', name: 'فيونكة وردية بنجمة', draw: 'bow', p: { color: '#ff4fa0', star: true } },
    { id: 'b_purple', name: 'فيونكة بنفسجية', draw: 'bow', p: { color: '#9b5cf0', star: true, s: 0.7 } },
    { id: 'b_green', name: 'فيونكة خضراء', draw: 'bow', p: { color: '#4cc24c', s: 0.7, x: 150, y: 116 } },
    { id: 'b_twin', name: 'فيونكتان صغيرتان', draw: 'twinbows', p: { color: '#a46bff' } },
    { id: 'b_cat', name: 'طوق القطة', draw: 'catears', p: { color: '#ff7fbf' } },
    { id: 'b_band', name: 'طوق وردي', draw: 'headband', p: { color: '#ff5fae', dots: true } },
    { id: 'b_flower', name: 'وردة حمراء', draw: 'flowerclip', p: { color: '#ff3b3b' } },
    { id: 'b_pins', name: 'دبابيس الشعر', draw: 'hairpins', p: {} },
    { id: 'b_wrap', name: 'لفة شعر ملونة', draw: 'headwrap', p: { color: '#ff7a3d' } },
  ]);
  add('glasses', 'glasses', 'glasses', [
    { id: 'g_heart', name: 'نظارة القلوب', draw: 'glasses', p: { color: '#ff3d8e', shape: 'heart' } },
    { id: 'g_star', name: 'نظارة النجوم', draw: 'glasses', p: { color: '#ffc93c', shape: 'star', lens: 'rgba(90,40,160,.6)' } },
    { id: 'g_round', name: 'نظارة دائرية', draw: 'glasses', p: { color: '#ff5fae', shape: 'round', lens: 'rgba(80,20,60,.5)' } },
    { id: 'g_flower', name: 'نظارة الزهور', draw: 'glasses', p: { color: '#ff8fc8', shape: 'round', flowers: true, lens: 'rgba(60,30,90,.55)' } },
  ]);
  add('bag', 'bag', 'bag', [
    { id: 'bg_pink', name: 'حقيبة وردية', draw: 'bag', p: { color: '#ff5fae', quilt: true, charm: 'heart' } },
    { id: 'bg_purple', name: 'حقيبة بفيونكة', draw: 'bag', p: { color: '#9b5cf0', quilt: true, charm: 'bow' } },
    { id: 'bg_blue', name: 'حقيبة النجمة', draw: 'bag', p: { color: '#4fb3ff', charm: 'star' } },
    { id: 'bg_rainbow', name: 'حقيبة قوس قزح', draw: 'bag', p: { color: '#ffffff', shape: 'rainbow' } },
    { id: 'bg_heart', name: 'حقيبة القلب', draw: 'bag', p: { color: '#ff4f7a', shape: 'heart', charm: 'star' } },
  ]);
  add('necklace', 'necklace', 'necklace', [
    { id: 'n_pearls', name: 'عقد اللؤلؤ', draw: 'necklace', p: { beads: '#fff6e6', chain: '#ffe9a8' } },
    { id: 'n_heart', name: 'قلادة القلب', draw: 'necklace', p: { pendant: 'heart' } },
    { id: 'n_rainbow', name: 'عقد قوس قزح', draw: 'necklace', p: { beads: 'rainbow' } },
    { id: 'n_star', name: 'قلادة النجمة', draw: 'necklace', p: { pendant: 'star', beads: '#ffd93d' } },
  ]);
  add('earrings', 'earrings', 'earrings', [
    { id: 'e_star', name: 'أقراط النجوم', draw: 'earrings', p: { shape: 'star', color: '#ff7fbf' } },
    { id: 'e_heart', name: 'أقراط القلوب', draw: 'earrings', p: { shape: 'heart', color: '#ff3d8e' } },
    { id: 'e_pearl', name: 'أقراط اللؤلؤ', draw: 'earrings', p: { shape: 'pearl' } },
    { id: 'e_hoop', name: 'أقراط ذهبية', draw: 'earrings', p: { shape: 'hoop' } },
  ]);
  add('bracelet', 'bracelet', 'bracelet', [
    { id: 'r_yellow', name: 'سوار اللؤلؤ الأصفر', draw: 'bracelet', p: { color: '#ffd93d' } },
    { id: 'r_pink', name: 'سوار وردي', draw: 'bracelet', p: { color: '#ff7fbf' } },
    { id: 'r_multi', name: 'سوار ملون', draw: 'bracelet', p: { multi: true } },
  ]);

  const HAIR_STYLES = [
    { id: 'wavy', name: 'طويل مموج' }, { id: 'straight', name: 'طويل ناعم' }, { id: 'curly', name: 'مجعد' }, { id: 'bob', name: 'قصير' },
    { id: 'pigtails', name: 'ذيلان' }, { id: 'ponytail', name: 'ذيل حصان' }, { id: 'braids', name: 'ضفيرتان' }, { id: 'bun', name: 'كعكة' },
    { id: 'spacebuns', name: 'كعكتان' }, { id: 'afro', name: 'شعر منفوش' }, { id: 'hijab', name: 'حجاب' },
  ];
  const HAIR_COLORS = ['#6b3a1f', '#4a2614', '#1f1716', '#e3b04b', '#b8541f', '#c0262d', '#ff6fae', '#8a4fd8', '#4f8fe8', '#d9d9e6', 'rainbow'];
  const HIJAB_COLORS = ['#f4f1f6', '#ffd1e6', '#c9b3ff', '#9fd8ff', '#ffe08a', '#bdf0c0', '#ff8fb1', '#7a5cff'];
  const MAKEUP = {
    shadow: { name: 'ظلال العيون', icon: '👁️', colors: ['#ff8fd0', '#b48cff', '#7fc8ff', '#ffd27a', '#7fe0b0', '#ff9f80', '#f0c0ff'] },
    lips: { name: 'ألوان الشفاه', icon: '💋', colors: ['#ff4f7a', '#ff7fbf', '#e53950', '#c2185b', '#ff9f80', '#b48cff', '#d9455f'] },
    blush: { name: 'أحمر الخدود', icon: '🌸', colors: ['#ff8fb1', '#ff6f91', '#ffb3a0', '#f7a8d8', '#ff9f80'] },
    eyes: { name: 'ألوان العيون', icon: '✨', colors: ['#6b3a1a', '#3a7bd5', '#2fa84f', '#8a4fd8', '#d9762a', '#1e9fb8', '#4a2a1a'] },
    sticker: { name: 'ملصقات', icon: '⭐', options: ['star', 'heart', 'sparkle', 'rainbow', 'stars2'] },
  };
  const BACKGROUNDS = [
    { id: 'room', name: 'غرفة الملابس' }, { id: 'castle', name: 'حديقة القصر' }, { id: 'stage', name: 'منصة العرض' },
    { id: 'beach', name: 'الشاطئ' }, { id: 'night', name: 'ليلة النجوم' }, { id: 'candy', name: 'أرض الحلوى' },
  ];
  // ---- characters (portrait art comes from the approved character-select design) ----
  const CHARS = [
    { id: 'c1', name: 'ليلى', img: 'assets/chars/c1.webp', art: { base: 'assets/c1/base.webp', arms: 'assets/c1/arms.webp', hair: { wavy: 'assets/c1/hair_wavy.webp', bun: '' }, bunHair: 'assets/c1/hair_bun.webp' }, skin: '#fbd6bd', eyes: '#6b3a1a', hair: { style: 'wavy', color: '#6b3a1f' }, slots: { dress: 'd_pink', shoes: 'sh_mary', hairacc: 'b_pink', earrings: 'e_star', necklace: 'n_pearls', bracelet: 'r_yellow' } },
    { id: 'c2', name: 'سارة', img: 'assets/chars/c2.webp', skin: '#fcdcc6', eyes: '#3a7bd5', hair: { style: 'straight', color: '#e3b04b' }, slots: { dress: 'd_snow', shoes: 'sh_blue', headwear: 'h_tiara_gold', earrings: 'e_pearl' } },
    { id: 'c3', name: 'نور', img: 'assets/chars/c3.webp', skin: '#f6cfb3', eyes: '#6b3a1a', hair: { style: 'straight', color: '#3a2216' }, slots: { top: 't_hoodie', bottom: 'p_jeans', shoes: 'sh_sneak', headwear: 'h_cap', earrings: 'e_star' } },
    { id: 'c4', name: 'مريم', img: 'assets/chars/c4.webp', skin: '#fbd6bd', eyes: '#6b3a1a', hair: { style: 'hijab', color: '#f4f1f6' }, slots: { top: 't_longwhite', bottom: 's_long', shoes: 'sh_mary', glasses: 'g_heart' } },
    { id: 'c5', name: 'جنى', img: 'assets/chars/c5.webp', skin: '#f8cfae', eyes: '#6b3a1a', hair: { style: 'spacebuns', color: '#5a3218' }, slots: { top: 't_star', bottom: 'p_overalls', shoes: 'sh_white', hairacc: 'b_twin' } },
    { id: 'c6', name: 'ياسمين', img: 'assets/chars/c6.webp', skin: '#f3c9aa', eyes: '#4a2a1a', hair: { style: 'wavy', color: '#1f1716' }, slots: { dress: 'd_embroid', shoes: 'sh_sandal', hairacc: 'b_flower', earrings: 'e_pearl' } },
    { id: 'c7', name: 'فرح', img: 'assets/chars/c7.webp', skin: '#fbd6bd', eyes: '#6b3a1a', hair: { style: 'braids', color: '#6b3a1f' }, slots: { dress: 'd_sunny', shoes: 'sh_boots_y', headwear: 'h_straw' } },
    { id: 'c8', name: 'رُبى', img: 'assets/chars/c8.webp', skin: '#fcdcc6', eyes: '#2fa84f', freckles: true, hair: { style: 'curly', color: '#b8541f' }, slots: { dress: 'd_pinafore', shoes: 'sh_sneak', hairacc: 'b_green' } },
    { id: 'c9', name: 'ميا', img: 'assets/chars/c9.webp', skin: '#fbdcc8', eyes: '#4a2a1a', hair: { style: 'bun', color: '#151213' }, slots: { dress: 'd_butterfly', shoes: 'sh_ballet', hairacc: 'b_pins' } },
    { id: 'c10', name: 'أمل', img: 'assets/chars/c10.webp', skin: '#9a6545', eyes: '#4a2a1a', hair: { style: 'afro', color: '#2b1a12' }, slots: { dress: 'd_rainbow2', shoes: 'sh_sandal', hairacc: 'b_wrap', earrings: 'e_hoop', bracelet: 'r_multi' } },
  ];
  CHARS.forEach((c) => c.slots && Object.values(c.slots).forEach((id) => { const it = ITEMS.find((i) => i.id === id); if (it) it.isDefault = true; }));
  // ---- studio menu ----
  const MENU = [
    { id: 'dress', name: 'فساتين', icon: '👗', tabs: [{ sub: 'dress', name: 'فساتين' }] },
    { id: 'top', name: 'ملابس', icon: '👚', tabs: [{ sub: 'top', name: 'بلوزات' }] },
    { id: 'skirt', name: 'تنانير', icon: '🩰', tabs: [{ sub: 'skirt', name: 'تنانير' }] },
    { id: 'pants', name: 'بناطيل', icon: '👖', tabs: [{ sub: 'pants', name: 'بناطيل' }] },
    { id: 'shoes', name: 'أحذية', icon: '👟', tabs: [{ sub: 'shoes', name: 'أحذية' }] },
    { id: 'acc', name: 'إكسسوارات', icon: '👑', tabs: [{ sub: 'headwear', name: 'تيجان', icon: '👑' }, { sub: 'hairacc', name: 'فيونكات', icon: '🎀' }, { sub: 'glasses', name: 'نظارات', icon: '🕶️' }, { sub: 'bag', name: 'حقائب', icon: '👜' }, { sub: 'necklace', name: 'قلادات', icon: '📿' }, { sub: 'earrings', name: 'أقراط', icon: '💎' }, { sub: 'bracelet', name: 'أساور', icon: '💫' }] },
    { id: 'hair', name: 'تسريحات', icon: '💇‍♀️' },
    { id: 'makeup', name: 'مكياج', icon: '💄' },
    { id: 'bg', name: 'خلفيات', icon: '🏰' },
  ];
  const byId = {}; ITEMS.forEach((i) => (byId[i.id] = i));
  G.LS_DATA = { ITEMS, itemsById: byId, HAIR_STYLES, HAIR_COLORS, HIJAB_COLORS, MAKEUP, BACKGROUNDS, CHARS, MENU,
    register(item) { item = Object.assign({ compat: 'all', unlocked: true, isDefault: false, layer: SLOT_LAYER[item.slot] }, item); ITEMS.push(item); byId[item.id] = item; return item; } };
})(window);
