# Adds (or updates) one level: copies the two pictures, finds where they differ and writes the level's data.
# usage: python3 tools/add_level.py <number> <first.png> <second.png> [easy|medium|hard] [hints] [min_area]
# writes: levels/<NNN>/a.webp, levels/<NNN>/b.webp, levels/<NNN>/level.json and adds the level to levels/index.json
import sys, json, os, cv2, numpy as np
n = int(sys.argv[1]); pa, pb = sys.argv[2], sys.argv[3]
diff = sys.argv[4] if len(sys.argv) > 4 else 'easy'; hints = int(sys.argv[5]) if len(sys.argv) > 5 else 3; MIN = int(sys.argv[6]) if len(sys.argv) > 6 else 300
lid = '%03d' % n; D = os.path.join('levels', lid); os.makedirs(D, exist_ok=True)
a, b = cv2.imread(pa), cv2.imread(pb)
if a.shape != b.shape: b = cv2.resize(b, (a.shape[1], a.shape[0]), interpolation=cv2.INTER_AREA)
H, W = a.shape[:2]; s = 900 / max(H, W)
a2, b2 = cv2.resize(a, None, fx=s, fy=s), cv2.resize(b, None, fx=s, fy=s)
d = cv2.absdiff(cv2.GaussianBlur(a2, (5, 5), 0), cv2.GaussianBlur(b2, (5, 5), 0)).max(axis=2)
m = cv2.morphologyEx(((d > 38) * 255).astype(np.uint8), cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
m = cv2.dilate(m, np.ones((15, 15), np.uint8))
k, lab, st, cen = cv2.connectedComponentsWithStats(m)
spots = []
for i in range(1, k):
    x, y, w, h, area = st[i]
    if area < MIN: continue
    spots.append({'x': round((x + w / 2) / a2.shape[1], 4), 'y': round((y + h / 2) / a2.shape[0], 4), 'r': round(max(w, h) / 2 / a2.shape[1] + 0.02, 4)})
spots.sort(key=lambda o: (o['x'], o['y']))
t = min(1, 1200 / max(H, W))
for src, nm in ((a, 'a'), (b, 'b')): cv2.imwrite(os.path.join(D, nm + '.webp'), cv2.resize(src, None, fx=t, fy=t, interpolation=cv2.INTER_AREA), [cv2.IMWRITE_WEBP_QUALITY, 88])
J = os.path.join(D, 'level.json'); old = json.load(open(J)) if os.path.exists(J) else {}
names = old.get('names', {})
L = {'id': n, 'difficulty': diff, 'images': {'a': 'a.webp', 'b': 'b.webp'}, 'ratio': round(W / H, 4), 'count': len(spots),
     'differences': [dict(sp, name=names.get(str(i), '')) for i, sp in enumerate(spots)],
     'hints': hints, 'points': {'perDifference': 100, 'fastBonus': 150, 'fastSeconds': 30 + 10 * len(spots), 'noHintBonus': 100, 'coins': 10}}
if old.get('scene'): L['scene'] = old['scene']
json.dump(L, open(J, 'w'), ensure_ascii=False, indent=1)
I = 'levels/index.json'; idx = json.load(open(I)) if os.path.exists(I) else {'total': 100, 'levels': []}
if lid not in idx['levels']: idx['levels'].append(lid); idx['levels'].sort()
json.dump(idx, open(I, 'w'), ensure_ascii=False, indent=1)
pv = b2.copy()
for o in spots: cv2.circle(pv, (int(o['x'] * a2.shape[1]), int(o['y'] * a2.shape[0])), int(o['r'] * a2.shape[1]), (200, 120, 141), 3)
cv2.imwrite('/tmp/check_%s.png' % lid, np.hstack([a2, pv]))
print('level', lid, '->', len(spots), 'differences', json.dumps(spots))
