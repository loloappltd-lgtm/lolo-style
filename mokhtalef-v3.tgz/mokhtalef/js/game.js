/* مختلف — gameplay. Every level lives in its own folder: levels/NNN/level.json + a.webp + b.webp,
   listed in levels/index.json. Adding a level = add its folder and its number (tools/add_level.py does both). */
'use strict';
var TOTAL = 100, IDX = [], CACHE = {};
var RANGES = [
  { key: 'easy', name: 'سهل', from: 1, to: 34, img: 'd_easy', diffs: '3–4 اختلافات', cls: 'mint' },
  { key: 'medium', name: 'متوسط', from: 35, to: 67, img: 'd_mid', diffs: '5–7 اختلافات', cls: 'sky' },
  { key: 'hard', name: 'صعب', from: 68, to: 100, img: 'd_hard', diffs: '8–10 اختلافات', cls: 'pink' }
];
function rangeOf(n) { for (var i = 0; i < RANGES.length; i++) if (n >= RANGES[i].from && n <= RANGES[i].to) return i; return 0; }
function getJSON(u) { return fetch(u + (u.indexOf('?') < 0 ? '?' : '&') + 't=' + Date.now(), { cache: 'no-store' }).then(function (r) { var dh = r.headers.get('Date'); if (dh) { var t = Date.parse(dh); if (!isNaN(t)) SRV_OFF = t - Date.now(); } if (!r.ok) throw new Error(r.status); return r.json(); }); }
function lid(n) { return ('00' + n).slice(-3); }
function hasLevel(n) { return IDX.indexOf(lid(n)) >= 0; }
function loadLevel(n) {
  var id = lid(n); if (CACHE[id]) return Promise.resolve(CACHE[id]);
  return getJSON('levels/' + id + '/level.json').then(function (L) { L.dir = 'levels/' + id + '/'; CACHE[id] = L; return L; });
}
function preload(L) { [L.images.a, L.images.b].forEach(function (f) { var i = new Image(); i.src = L.dir + f; }); }
function nextIn(r) { for (var n = r.from; n <= r.to; n++) { if (!hasLevel(n)) return { soon: n }; if (!starsOf(n)) return unlocked(n) ? { n: n } : { locked: n }; } return { all: true }; }
function continueLevel() { for (var n = 1; n <= TOTAL; n++) { if (!hasLevel(n)) return { soon: n }; if (!starsOf(n)) return { n: n }; } return { all: true }; }

var G = null, clock = 0;
/* every level start passes the parent's play-time rules first (checked on the server, see js/parent.js) */
function startLevel(n) { if (window.playGuard) playGuard(function () { startLevel0(n); }); else startLevel0(n); }
function startLevel0(n) {
  loadLevel(n).then(function (L) {
    G = { n: n, L: L, got: [], miss: 0, t: 0, hints: L.hints, used: 0, over: false, paused: false, hintOn: false };
    S.last = n; save();
    var w = Math.floor((n - 1) / 10), dk = { easy: 0, medium: 1, hard: 2 }[L.difficulty] || 0;
    $('gLv').textContent = (n - 1) % 10 + 1; $('gTot').textContent = $('gTot2').textContent = L.differences.length;
    $('gWorld').textContent = WORLDS[w]; $('gWImg').src = 'assets/worlds/w' + ('0' + (w + 1)).slice(-2) + '.webp';
    $('gDiff').textContent = RANGES[dk].name; $$('#gBars i').forEach(function (e, i) { e.classList.toggle('on', i <= dk); });
    $('gTime').textContent = '00:00';
    ['svA', 'svB'].forEach(function (s) { $(s).innerHTML = ''; $(s).setAttribute('viewBox', '0 0 1000 ' + Math.round(1000 / L.ratio)); });
    var ready = 0, go = function () {
      if (++ready < 2) return;
      show('game'); updHUD(); layout();
      clearInterval(clock); clock = setInterval(function () { if (G && !G.over && !G.paused && !document.hidden) { G.t++; $('gTime').textContent = mmss(G.t); } }, 1000);
    };
    $('imA').onload = go; $('imB').onload = go;
    $('imA').onerror = $('imB').onerror = function () { toast('الصور مش راضية تحمل — جرّب تاني', 'retry'); };
    $('imA').src = L.dir + L.images.a; $('imB').src = L.dir + L.images.b;
    if (hasLevel(n + 1)) loadLevel(n + 1).then(preload, function () {});
  }, function () { toast('المرحلة دي مش موجودة لسه', 'lock'); });
}
/* the two pictures always take the biggest space the screen allows; side by side, or stacked on a tall screen */
function layout() {
  if (!G || CUR !== 'game') return;
  var bd = $('board'), W = bd.clientWidth, H = bd.clientHeight, gap = 14, ar = G.L.ratio, B = 12;
  var wRow = Math.min((W - gap) / 2 - B, (H - B) * ar), wCol = Math.min(W - B, ((H - gap) / 2 - B) * ar);
  var col = wCol > wRow * 1.08; bd.classList.toggle('col', col);
  var w = col ? wCol : wRow, h = w / ar;
  ['picA', 'picB'].forEach(function (p) { $(p).style.width = w + B + 'px'; $(p).style.height = h + B + 'px'; });
}
window.addEventListener('resize', function () { setTimeout(layout, 60); });
function mmss(t) { return ('0' + Math.floor(t / 60)).slice(-2) + ':' + ('0' + t % 60).slice(-2); }
function liveStars() { var s = 3; if (G.used >= 1) s--; if (G.used >= 2 || G.miss >= 6) s--; if (G.miss >= 12) s = Math.min(s, 1); return Math.max(1, s); }
function updHUD() {
  var c = G.L.differences.length, f = G.got.length;
  $('gCnt').textContent = f;
  var dh = ''; for (var k = 0; k < c; k++) dh += '<i class="' + (G.got.indexOf(k) >= 0 ? 'on' : '') + '"></i>'; $('gDots').innerHTML = dh;
  $('progB').style.width = (f / c * 100) + '%'; $('progT').textContent = f + ' / ' + c;
  var left = G.hints + S.extraHints; $('hintN').textContent = left; $('hintB').classList.toggle('dis', left <= 0);
  var s = liveStars(); $$('#gStars .st').forEach(function (e, i) { e.classList.toggle('on', i < s); });
}
function vbH() { return 1000 / G.L.ratio; }
function circ(cls, d) { var r = Math.max(46, (d.r + 0.012) * 1000); return '<circle class="' + cls + '" cx="' + (d.x * 1000).toFixed(1) + '" cy="' + (d.y * vbH()).toFixed(1) + '" r="' + r.toFixed(1) + '"/>'; }
function point(pic, e) { var r = pic.getBoundingClientRect(), b = 6; return { x: (e.clientX - r.left - b) / (r.width - 2 * b), y: (e.clientY - r.top - b) / (r.height - 2 * b) }; }
function hitTest(p) {
  var best = -1, bd = 1e9;
  G.L.differences.forEach(function (d, k) {
    var dx = p.x - d.x, dy = (p.y - d.y) / G.L.ratio, dist = Math.sqrt(dx * dx + dy * dy), tol = Math.max(d.r, 0.055) + (d.r < 0.1 ? 0.045 : 0.02); // forgiving for small fingers, without swallowing nearby objects
    if (dist <= tol && dist < bd) { bd = dist; best = k; }
  });
  return best;
}
function onTap(e) {
  if (!G || G.over || G.paused) return;
  e.preventDefault();
  var pic = e.currentTarget, p = point(pic, e), k = hitTest(p);
  if (k >= 0 && G.got.indexOf(k) < 0) return found(k);
  var sv = pic.querySelector('svg');
  sv.insertAdjacentHTML('beforeend', '<circle class="ripple" cx="' + p.x * 1000 + '" cy="' + p.y * vbH() + '" r="34"/>');
  var rp = sv.lastChild; setTimeout(function () { rp.remove(); }, 650);
  if (k < 0) { G.miss++; sfx.soft(); buzz(25); pic.classList.remove('shake'); void pic.offsetWidth; pic.classList.add('shake'); updHUD(); }
}
function found(k) {
  G.got.push(k); var d = G.L.differences[k];
  sfx.ok(); buzz(35); S.found++; onFound(); save();
  ['svA', 'svB'].forEach(function (s) {
    var sv = $(s); $$('.hintC', sv).forEach(function (h) { h.remove(); });
    sv.insertAdjacentHTML('beforeend', '<g class="grow">' + circ('found', d) + circ('found2', d) + '</g>');
    var y = d.y * vbH() - Math.max(46, d.r * 1000) - 10;
    sv.insertAdjacentHTML('beforeend', '<use href="#i-star" class="flyStar" x="' + (d.x * 1000 - 34) + '" y="' + (y - 34) + '" width="68" height="68"/>');
    var st = sv.lastChild; setTimeout(function () { st.remove(); }, 1050);
  });
  G.hintOn = false; updHUD();
  if (G.got.length === G.L.differences.length) win();
}
$('picA').addEventListener('pointerdown', onTap); $('picB').addEventListener('pointerdown', onTap);
$('hintB').onclick = function () {
  if (!G || G.over || G.paused || G.hintOn) return;
  var left = G.L.differences.map(function (d, k) { return k; }).filter(function (k) { return G.got.indexOf(k) < 0; });
  if (!left.length) return;
  if (G.hints + S.extraHints <= 0) {
    if (S.coins >= CONFIG.hintPrice) return approvePurchase('تلميح زيادة', 'تاخد تلميح بـ ' + CONFIG.hintPrice + ' عملة؟', function () {   // a clear yes (or the parent's PIN) before any purchase
      if (S.coins < CONFIG.hintPrice) return; S.coins -= CONFIG.hintPrice; S.extraHints++; addLog('bulb', 'اشتريت تلميح', 0, '-' + CONFIG.hintPrice + ' عملة'); save(); sfx.coin(); updHUD(); updPills(); $('hintB').click(); });
    sfx.soft(); return toast('خلصت التلميحات — جرّب تدوّر بنفسك', 'search');
  }
  if (G.hints > 0) G.hints--; else { S.extraHints--; save(); }
  G.used++; G.hintOn = true; sfx.hint(); onHintUsed();
  var d = G.L.differences[left[0]];
  ['svA', 'svB'].forEach(function (s) { $(s).insertAdjacentHTML('beforeend', circ('hintC', d)); var c = $(s).lastChild; setTimeout(function () { c.remove(); if (G) G.hintOn = false; }, 3400); });
  updHUD();
};
/* win: rewards come from how the child played, and are added exactly once per finished round */
function win() {
  if (G.won) return; G.won = true; G.over = true; clearInterval(clock);
  var P = G.L.points || {}, c = G.L.differences.length, s = liveStars();
  var base = (P.perDifference || 100) * c, fast = G.t <= (P.fastSeconds || 60) ? (P.fastBonus || 150) : 0, noh = G.used === 0 ? (P.noHintBonus || 100) : 0, total = base + fast + noh;
  var prev = S.lv[G.n] || {}, first = !prev.s, newStars = Math.max(0, s - (prev.s || 0));
  var why = [], coins;
  if (first) {
    var C = CONFIG.level; coins = (P.coins || C.firstCoins); why.push('إكمال المرحلة +' + coins);
    if (s > 1) { coins += (s - 1) * C.perExtraStar; why.push(s + ' نجوم +' + (s - 1) * C.perExtraStar); }
    if (fast) { coins += C.fast; why.push('سرعة +' + C.fast); }
    if (noh) { coins += C.noHint; why.push('من غير تلميح +' + C.noHint); }
  } else {
    coins = CONFIG.level.replayCoins + newStars * CONFIG.level.replayNewStar; why.push('لعبتها تاني +' + CONFIG.level.replayCoins); if (newStars) why.push('نجوم جديدة +' + newStars * CONFIG.level.replayNewStar);
  }
  S.lv[G.n] = { s: Math.max(prev.s || 0, s), score: Math.max(prev.score || 0, total), t: Math.min(prev.t || 1e9, G.t) };
  S.wins++; if (s === 3) S.perfect++; if (fast) S.fast++; if (noh) S.nohint++;
  if (window.sendResult) sendResult(G.n, s, G.t, G.used);   // the server checks it and counts only new stars
  giveCoins(coins, 'flag', 'المرحلة ' + G.n, newStars ? '+' + newStars + ' نجوم' : '');
  onWin({ noHint: !!noh, newStars: newStars });
  var w = Math.floor((G.n - 1) / 10), worldNow = checkWorldDone(G.n);
  // ---- fill the window ----
  var h = ''; for (var i = 0; i < 3; i++) h += '<svg class="st' + (i < s ? ' on' : '') + (i === 1 ? ' mid' : '') + '" style="animation-delay:' + (0.15 + i * 0.2) + 's"><use href="#i-star"/></svg>';
  $('wStars').innerHTML = h;
  $('wLv').textContent = (G.n - 1) % 10 + 1; $('wTime').textContent = mmss(G.t);
  $('wStarsN').textContent = '+' + newStars; $('wCoinsN').textContent = '+' + coins;
  $('wWhy').textContent = why.join(' · ') + ' · ' + fmtNum(total) + ' نقطة';
  var dc = wDoneCount(w);
  $('wWName').textContent = WORLDS[w]; $('wWImg').src = 'assets/worlds/w' + ('0' + (w + 1)).slice(-2) + '.webp';
  $('wWBar').style.width = (dc * 10) + '%'; $('wWT').textContent = dc + ' / 10';
  var done = wDone(w);
  $('wChest').classList.toggle('open', done); $('wChest').classList.toggle('anim', !!S.fx);
  $('wDone').innerHTML = worldNow ? ic('trophy') + 'خلّصت ' + WORLDS[w] + '! خدت ' + rewardText(CONFIG.world) : done ? ic('check') + 'العالم ده خلصان' : 'خلّص الـ10 مراحل وافتح صندوق ' + WORLDS[w];
  $('wDone').classList.toggle('big', !!worldNow);
  // next button: next level in this world, or the next world when this one is finished
  var nx = G.n + 1, nb = $('wNext'), lastOfWorld = G.n % 10 === 0;
  nb.dataset.mode = '';
  if (lastOfWorld && done && w < 9) { $('wNextT').textContent = 'افتح ' + WORLDS[w + 1]; nb.dataset.mode = 'world'; nb.classList.remove('dis'); }
  else if (lastOfWorld) { $('wNextT').textContent = 'المرحلة التالية'; nb.dataset.mode = w < 9 ? 'lockedWorld' : 'end'; nb.classList.add('dis'); }
  else { $('wNextT').textContent = 'المرحلة التالية'; nb.dataset.mode = hasLevel(nx) ? 'level' : 'soon'; nb.classList.toggle('dis', !hasLevel(nx)); }
  updPills();
  setTimeout(function () { sfx.win(); if (S.fx) confetti(); openOv('ovWin'); }, 650);
  if (window.afterWin) afterWin();
}
$('wNext').onclick = function () {
  sfx.tap(); var m = this.dataset.mode, w = Math.floor((G.n - 1) / 10);
  if (m === 'soon') return toast('المرحلة ' + ((G.n) % 10 + 1) + ' جاية قريب', 'star');
  if (m === 'lockedWorld') return toast('خلّص كل مراحل ' + WORLDS[w] + ' الأول', 'lock');
  if (m === 'end') return toast('خلّصت كل العوالم! برافو', 'trophy');
  closeOv('ovWin');
  if (m === 'world') { LV_W = w + 1; LV_SEL = 0; return show('levels'); }
  startLevel(G.n + 1);
};
$('wRe').onclick = function () { sfx.tap(); closeOv('ovWin'); startLevel(G.n); };
$('wLvls').onclick = function () { sfx.tap(); closeOv('ovWin'); show('worlds'); };
$('wClose').onclick = function () { sfx.tap(); closeOv('ovWin'); exitToMap(); };
function pauseGame() { if (!G || G.over) return; G.paused = true; $('pLv').textContent = (G.n - 1) % 10 + 1; $('pTime').textContent = mmss(G.t); $('pSnd').classList.toggle('on', !!S.snd); openOv('ovPause'); }
function resumeGame() { if (G && !G.over) G.paused = false; }
$('gPause').onclick = function () { sfx.tap(); pauseGame(); };
$('pGo').onclick = function () { sfx.tap(); closeOv('ovPause'); resumeGame(); };
$('pRe').onclick = function () { sfx.tap(); closeOv('ovPause'); G.over = true; startLevel(G.n); };
function exitToMap() { if (G) { G.over = true; LV_W = Math.floor((G.n - 1) / 10); LV_SEL = G.n; } clearInterval(clock); show('levels'); }
$('pLvls').onclick = function () { sfx.tap(); closeOv('ovPause'); exitToMap(); };
$('gBack').onclick = function () { sfx.tap(); exitToMap(); };
/* retry: this level starts again from zero; other levels' progress stays */
$('gRetry').onclick = function () { if (!G || G.over) return; sfx.tap(); G.over = true; clearInterval(clock); startLevel(G.n); };
$('pHome').onclick = function () { sfx.tap(); closeOv('ovPause'); G.over = true; clearInterval(clock); show('start'); };
$('pSnd').onclick = function () { S.snd = S.snd ? 0 : 1; save(); this.classList.toggle('on', !!S.snd); musicSync(); sfx.tap(); };
document.addEventListener('visibilitychange', function () { if (document.hidden && G && !G.over && !G.paused && CUR === 'game') pauseGame(); });
SCREENS.game = function () { setTimeout(layout, 30); };
