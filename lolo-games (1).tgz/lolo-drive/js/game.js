// LOLO DRIVE — 3D city driving + races (Three.js, no external assets)
import * as THREE from 'three';

const $ = (s) => document.querySelector(s), $$ = (s) => [...document.querySelectorAll(s)];
const rnd = (a, b) => a + Math.random() * (b - a), clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
const MOBILE = matchMedia('(pointer:coarse)').matches || /Android|iPhone|iPad/i.test(navigator.userAgent);

// ---------------- save ----------------
const KEY = 'loloDrive.v1';
const S = Object.assign({ stars: 0, owned: ['sedan'], car: 'sedan', color: 0, best: {}, sound: true }, (() => { try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch (e) { return {}; } })());
const save = () => { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} };
const setStars = () => { $('#starsN').textContent = S.stars; };
setStars();

// ---------------- renderer / scene ----------------
const canvas = $('#c');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: !MOBILE, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(devicePixelRatio || 1, MOBILE ? 1.25 : 1.75));
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.05;
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
const scene = new THREE.Scene();
const SKY = new THREE.Color('#9cc9ef');
scene.background = SKY; scene.fog = new THREE.Fog(SKY, 120, 420);
const camera = new THREE.PerspectiveCamera(62, 1, 0.3, 900);
scene.add(new THREE.HemisphereLight('#cfe6ff', '#5b5246', 0.85));
const sun = new THREE.DirectionalLight('#fff3dc', 2.1);
sun.castShadow = true; sun.shadow.mapSize.set(MOBILE ? 1024 : 2048, MOBILE ? 1024 : 2048);
const sc = sun.shadow.camera; sc.left = -70; sc.right = 70; sc.top = 70; sc.bottom = -70; sc.near = 1; sc.far = 300; sun.shadow.bias = -0.0006;
scene.add(sun, sun.target);
function resize() { const w = innerWidth, h = innerHeight; renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix(); $('#rot').classList.toggle('need', MOBILE); }
addEventListener('resize', resize); resize();

// ---------------- textures ----------------
function canvasTex(w, h, draw, rep) { const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; if (rep) { t.wrapS = t.wrapT = THREE.RepeatWrapping; } return t; }
function facadeTex(base, glass, frame) {
  return canvasTex(128, 128, (g, w, h) => {
    g.fillStyle = base; g.fillRect(0, 0, w, h);
    for (let i = 0; i < 2400; i++) { g.fillStyle = `rgba(0,0,0,${Math.random() * 0.05})`; g.fillRect(Math.random() * w, Math.random() * h, 2, 2); }
    for (let y = 0; y < 4; y++) for (let x = 0; x < 4; x++) {
      const X = x * 32 + 6, Y = y * 32 + 7; g.fillStyle = frame; g.fillRect(X - 2, Y - 2, 24, 22);
      const gr = g.createLinearGradient(X, Y, X + 20, Y + 18); gr.addColorStop(0, glass); gr.addColorStop(1, '#0d1b2a'); g.fillStyle = gr; g.fillRect(X, Y, 20, 18);
      if (Math.random() < 0.25) { g.fillStyle = 'rgba(255,230,170,.35)'; g.fillRect(X, Y, 20, 18); }
      g.fillStyle = 'rgba(255,255,255,.18)'; g.fillRect(X, Y, 20, 4);
    }
  }, true);
}
const asphalt = canvasTex(256, 256, (g, w, h) => { g.fillStyle = '#3b3f45'; g.fillRect(0, 0, w, h); for (let i = 0; i < 9000; i++) { const v = 40 + Math.random() * 40 | 0; g.fillStyle = `rgba(${v},${v},${v + 4},.5)`; g.fillRect(Math.random() * w, Math.random() * h, 1.5, 1.5); } }, true);
asphalt.repeat.set(60, 60);
const walkTex = canvasTex(128, 128, (g, w, h) => { g.fillStyle = '#b9b4aa'; g.fillRect(0, 0, w, h); g.strokeStyle = 'rgba(80,75,70,.35)'; g.lineWidth = 2; for (let i = 0; i <= 4; i++) { g.beginPath(); g.moveTo(i * 32, 0); g.lineTo(i * 32, h); g.stroke(); g.beginPath(); g.moveTo(0, i * 32); g.lineTo(w, i * 32); g.stroke(); } }, true);
const grassTex = canvasTex(128, 128, (g, w, h) => { g.fillStyle = '#4f8a3a'; g.fillRect(0, 0, w, h); for (let i = 0; i < 3000; i++) { g.fillStyle = Math.random() < 0.5 ? '#5d9a44' : '#43782f'; g.fillRect(Math.random() * w, Math.random() * h, 2, 3); } }, true);

// ---------------- city layout ----------------
const N = 8, BS = 56, R = 16, P = BS + R, HALF = (N * P) / 2;
const road = (k) => k * P - HALF;            // road centre line k = 0..N
const blockMin = (i) => road(i) + R / 2, blockMax = (i) => road(i + 1) - R / 2;
const solids = [];                            // AABBs the car can't enter
const world = new THREE.Group(); scene.add(world);
const ground = new THREE.Mesh(new THREE.PlaneGeometry(N * P + 400, N * P + 400), new THREE.MeshStandardMaterial({ map: asphalt, roughness: 0.95 }));
ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; world.add(ground);
// outer grass ring beyond the city edge
const edge = new THREE.Mesh(new THREE.RingGeometry(HALF + R, HALF + 600, 4, 1), new THREE.MeshStandardMaterial({ map: grassTex, roughness: 1 }));
edge.rotation.x = -Math.PI / 2; edge.rotation.z = Math.PI / 4; edge.position.y = 0.02; world.add(edge);
const outer = HALF + R / 2; solids.push({ x0: -1e4, x1: 1e4, z0: outer, z1: 1e4 }, { x0: -1e4, x1: 1e4, z0: -1e4, z1: -outer }, { x0: outer, x1: 1e4, z0: -1e4, z1: 1e4 }, { x0: -1e4, x1: -outer, z0: -1e4, z1: 1e4 });

const PALETTE = [['#d9cbb3', '#6d8fb3', '#8c7f6b'], ['#b8bcc2', '#5b7896', '#6f747a'], ['#c79a7b', '#7896b0', '#7a5a46'], ['#e8e2d6', '#4d6f94', '#9a958b'], ['#8e9aa6', '#3f6488', '#59636e']];
const FLOORS = [3, 5, 8, 12, 18];
const facadeMats = PALETTE.map(([b, gl, f]) => new THREE.MeshStandardMaterial({ map: facadeTex(b, gl, f), roughness: 0.7, metalness: 0.05 }));
const roofMat = new THREE.MeshStandardMaterial({ color: '#6b6b6b', roughness: 0.9 });
const walkMat = new THREE.MeshStandardMaterial({ map: walkTex, roughness: 0.9 });
const grassMat = new THREE.MeshStandardMaterial({ map: grassTex, roughness: 1 });
const parks = new Set(['2,5', '5,2', '6,6']);
const buildingsByClass = {};
const tmpM = new THREE.Matrix4(), tmpQ = new THREE.Quaternion(), tmpS = new THREE.Vector3(), tmpP = new THREE.Vector3();
const treesAt = [], lampsAt = [];
for (let i = 0; i < N; i++) for (let j = 0; j < N; j++) {
  const x0 = blockMin(i), x1 = blockMax(i), z0 = blockMin(j), z1 = blockMax(j), cx = (x0 + x1) / 2, cz = (z0 + z1) / 2, w = x1 - x0, d = z1 - z0;
  const curb = new THREE.Mesh(new THREE.BoxGeometry(w, 0.3, d), walkMat); curb.position.set(cx, 0.15, cz); curb.receiveShadow = true; world.add(curb);
  walkTex.repeat.set(1, 1);
  solids.push({ x0, x1, z0, z1 });
  for (const [lx, lz] of [[x0 + 1.2, z0 + 1.2], [x1 - 1.2, z0 + 1.2], [x0 + 1.2, z1 - 1.2], [x1 - 1.2, z1 - 1.2]]) lampsAt.push([lx, lz]);
  if (parks.has(i + ',' + j)) {
    const gr = new THREE.Mesh(new THREE.BoxGeometry(w - 5, 0.1, d - 5), grassMat); gr.position.set(cx, 0.33, cz); gr.receiveShadow = true; world.add(gr);
    for (let t = 0; t < 22; t++) treesAt.push([rnd(x0 + 5, x1 - 5), rnd(z0 + 5, z1 - 5), rnd(0.8, 1.4)]);
    continue;
  }
  for (let t = 0; t < 6; t++) treesAt.push([t < 3 ? x0 + 2.2 : x1 - 2.2, lerp(z0 + 6, z1 - 6, (t % 3) / 2), rnd(0.7, 1)]);
  // 2x2 lots per block with a little variation
  const lots = Math.random() < 0.25 ? [[cx, cz, w - 6, d - 6]] : [[x0 + 3 + (w - 6) / 4, z0 + 3 + (d - 6) / 4], [x1 - 3 - (w - 6) / 4, z0 + 3 + (d - 6) / 4], [x0 + 3 + (w - 6) / 4, z1 - 3 - (d - 6) / 4], [x1 - 3 - (w - 6) / 4, z1 - 3 - (d - 6) / 4]].map(([a, b]) => [a, b, (w - 6) / 2 - 2, (d - 6) / 2 - 2]);
  const centre = Math.hypot(cx, cz) < HALF * 0.45;
  for (const [bx, bz, bw, bd] of lots) {
    const fl = FLOORS[Math.min(FLOORS.length - 1, Math.floor(Math.random() * (centre ? 5 : 3.2)))], pal = Math.floor(Math.random() * PALETTE.length), key = fl + '_' + pal;
    (buildingsByClass[key] = buildingsByClass[key] || []).push([bx, bz, bw * rnd(0.82, 1), bd * rnd(0.82, 1), fl]);
  }
}
for (const [key, list] of Object.entries(buildingsByClass)) {
  const [fl, pal] = key.split('_').map(Number), H = fl * 3.2;
  const g = new THREE.BoxGeometry(1, 1, 1); const uv = g.attributes.uv;
  for (let k = 0; k < uv.count; k++) uv.setXY(k, uv.getX(k) * 4, uv.getY(k) * fl / 4); // windows: 4 per texture
  const im = new THREE.InstancedMesh(g, [facadeMats[pal], facadeMats[pal], roofMat, roofMat, facadeMats[pal], facadeMats[pal]], list.length);
  list.forEach(([x, z, w, d], n) => { tmpM.compose(tmpP.set(x, 0.3 + H / 2, z), tmpQ.identity(), tmpS.set(w, H, d)); im.setMatrixAt(n, tmpM); });
  im.castShadow = true; im.receiveShadow = true; world.add(im);
}
// trees
{ const trunk = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.18, 0.25, 2.4, 6), new THREE.MeshStandardMaterial({ color: '#6b4a2b', roughness: 1 }), treesAt.length);
  const leaf = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(1.6, 1), new THREE.MeshStandardMaterial({ color: '#3f7a35', roughness: 0.9, flatShading: true }), treesAt.length);
  treesAt.forEach(([x, z, s], n) => { tmpM.compose(tmpP.set(x, 1.5 * s, z), tmpQ.identity(), tmpS.set(s, s, s)); trunk.setMatrixAt(n, tmpM); tmpM.compose(tmpP.set(x, 3.4 * s, z), tmpQ.setFromEuler(new THREE.Euler(0, Math.random() * 3, 0)), tmpS.set(s * rnd(0.9, 1.2), s * rnd(1, 1.3), s * rnd(0.9, 1.2))); leaf.setMatrixAt(n, tmpM); });
  trunk.castShadow = leaf.castShadow = true; world.add(trunk, leaf); }
// street lamps
{ const pole = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.08, 0.12, 6, 6), new THREE.MeshStandardMaterial({ color: '#30343a', metalness: 0.6, roughness: 0.4 }), lampsAt.length);
  const head = new THREE.InstancedMesh(new THREE.BoxGeometry(0.5, 0.18, 0.9), new THREE.MeshStandardMaterial({ color: '#30343a', emissive: '#ffe7b0', emissiveIntensity: 0.15 }), lampsAt.length);
  lampsAt.forEach(([x, z], n) => { tmpM.compose(tmpP.set(x, 3.3, z), tmpQ.identity(), tmpS.set(1, 1, 1)); pole.setMatrixAt(n, tmpM); tmpM.compose(tmpP.set(x, 6.25, z), tmpQ.identity(), tmpS.set(1, 1, 1)); head.setMatrixAt(n, tmpM); });
  world.add(pole, head); }
// lane markings + crosswalks
{ const dashes = [], zebra = [];
  for (let k = 0; k <= N; k++) for (let i = 0; i < N; i++) {
    const a = blockMin(i) + 4, b = blockMax(i) - 4;
    for (let t = a; t < b; t += 6) { dashes.push([t + 1.5, road(k), 0]); dashes.push([road(k), t + 1.5, Math.PI / 2]); }
    for (let s = -R / 2 + 1.5; s < R / 2 - 1; s += 1.6) { zebra.push([blockMin(i) + 1.2, road(k) + s, 0]); zebra.push([blockMax(i) - 1.2, road(k) + s, 0]); zebra.push([road(k) + s, blockMin(i) + 1.2, Math.PI / 2]); zebra.push([road(k) + s, blockMax(i) - 1.2, Math.PI / 2]); }
  }
  const mk = (list, w, d, color) => { const m = new THREE.InstancedMesh(new THREE.PlaneGeometry(w, d), new THREE.MeshStandardMaterial({ color, roughness: 0.8 }), list.length); list.forEach(([x, z, r], n) => { tmpM.compose(tmpP.set(x, 0.03, z), tmpQ.setFromEuler(new THREE.Euler(-Math.PI / 2, 0, r)), tmpS.set(1, 1, 1)); m.setMatrixAt(n, tmpM); }); m.receiveShadow = true; world.add(m); };
  mk(dashes, 3, 0.25, '#e8e4d8'); mk(zebra, 2.4, 0.7, '#e8e4d8'); }

// ---------------- car models ----------------
const CARS = [
  { id: 'sedan', name: 'سيدان', cost: 0, top: 36, acc: 15, grip: 7.5, dim: [1.9, 4.4], prof: [[-2.2, .45], [-2.25, .95], [-1.3, 1.05], [-.75, 1.55], [.75, 1.58], [1.45, 1.1], [2.2, 1.0], [2.25, .45]] },
  { id: 'sport', name: 'رياضية', cost: 12, top: 46, acc: 21, grip: 9, dim: [1.95, 4.5], prof: [[-2.25, .4], [-2.3, .8], [-1.2, .95], [-.4, 1.32], [.6, 1.34], [1.3, .95], [2.25, .78], [2.3, .4]] },
  { id: 'suv', name: 'جيب', cost: 25, top: 40, acc: 17, grip: 8, dim: [2.05, 4.6], prof: [[-2.3, .55], [-2.32, 1.25], [-1.6, 1.35], [-1.25, 2.0], [1.1, 2.02], [1.45, 1.4], [2.3, 1.3], [2.32, .55]] },
];
const COLORS = ['#d62828', '#f4f4f4', '#1d3557', '#ffb703', '#2a9d8f', '#111418', '#8338ec', '#ff6fae'];
const tireMat = new THREE.MeshStandardMaterial({ color: '#141414', roughness: 0.85 });
const rimMat = new THREE.MeshStandardMaterial({ color: '#c9ccd1', metalness: 0.9, roughness: 0.25 });
const glassMat = new THREE.MeshStandardMaterial({ color: '#13202e', metalness: 0.6, roughness: 0.1 });
function buildCar(def, color) {
  const g = new THREE.Group(), [W, L] = def.dim;
  const shape = new THREE.Shape(); def.prof.forEach(([x, y], n) => (n ? shape.lineTo(x, y) : shape.moveTo(x, y))); shape.closePath();
  const body = new THREE.Mesh(new THREE.ExtrudeGeometry(shape, { depth: W - 0.2, bevelEnabled: true, bevelSize: 0.1, bevelThickness: 0.1, bevelSegments: 2 }), new THREE.MeshPhysicalMaterial({ color, metalness: 0.55, roughness: 0.28, clearcoat: 1, clearcoatRoughness: 0.08 }));
  body.position.z = -(W - 0.2) / 2; body.castShadow = true; g.add(body);
  // windows: a dark inset band on the cabin
  const p = def.prof, wy0 = Math.min(p[2][1], p[5][1]) + 0.05; const ws = new THREE.Shape();
  ws.moveTo(p[2][0] + 0.15, wy0); ws.lineTo(p[3][0] + 0.08, p[3][1] - 0.08); ws.lineTo(p[4][0] - 0.08, p[4][1] - 0.08); ws.lineTo(p[5][0] - 0.15, wy0); ws.closePath();
  const win = new THREE.Mesh(new THREE.ExtrudeGeometry(ws, { depth: W + 0.02, bevelEnabled: false }), glassMat); win.position.z = -(W + 0.02) / 2; g.add(win);
  const wheelG = new THREE.CylinderGeometry(0.42, 0.42, 0.32, 18); wheelG.rotateX(Math.PI / 2);
  const rimG = new THREE.CylinderGeometry(0.26, 0.26, 0.34, 10); rimG.rotateX(Math.PI / 2);
  g.wheels = [];
  for (const [x, z] of [[-L * 0.32, W / 2], [-L * 0.32, -W / 2], [L * 0.32, W / 2], [L * 0.32, -W / 2]]) {
    const w = new THREE.Group(); w.add(new THREE.Mesh(wheelG, tireMat), new THREE.Mesh(rimG, rimMat)); w.position.set(x, 0.42, z); w.children[0].castShadow = true; g.add(w); g.wheels.push(w);
  }
  const lamp = (x, y, z, c, e) => { const m = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.16, 0.42), new THREE.MeshStandardMaterial({ color: c, emissive: c, emissiveIntensity: e })); m.position.set(x, y, z); g.add(m); };
  const fy = p[p.length - 2][1] - 0.25, ry = p[1][1] - 0.2;
  lamp(p[p.length - 1][0] + 0.06, fy, W / 2 - 0.45, '#fff8e0', 0.8); lamp(p[p.length - 1][0] + 0.06, fy, -W / 2 + 0.45, '#fff8e0', 0.8);
  lamp(p[0][0] - 0.1, ry, W / 2 - 0.4, '#ff2a2a', 0.6); lamp(p[0][0] - 0.1, ry, -W / 2 + 0.4, '#ff2a2a', 0.6);
  const sh = new THREE.Mesh(new THREE.PlaneGeometry(L + 0.6, W + 0.5), new THREE.MeshBasicMaterial({ color: '#000', transparent: true, opacity: 0.28, depthWrite: false }));
  sh.rotation.x = -Math.PI / 2; sh.position.y = 0.04; g.add(sh);
  // model faces +x; the game uses +z as forward, so rotate it inside a wrapper
  const wrap = new THREE.Group(); g.rotation.y = -Math.PI / 2; wrap.add(g); wrap.inner = g; wrap.wheels = g.wheels; return wrap;
}

// ---------------- vehicles ----------------
function Vehicle(def, color) { this.def = def; this.mesh = buildCar(def, color); scene.add(this.mesh); this.x = 0; this.z = 0; this.yaw = 0; this.v = 0; this.lat = 0; this.steer = 0; this.r = 2.1; }
Vehicle.prototype.place = function (x, z, yaw) { this.x = x; this.z = z; this.yaw = yaw; this.v = 0; this.lat = 0; this.sync(0); };
Vehicle.prototype.sync = function (dt) {
  this.mesh.position.set(this.x, 0, this.z); this.mesh.rotation.y = this.yaw;
  const spin = (this.v * dt) / 0.42; this.mesh.wheels.forEach((w, n) => { w.children.forEach((c) => (c.rotation.z -= spin)); if (n >= 2) w.rotation.y = this.steer * 0.45; });
  this.mesh.inner.rotation.z = clamp(-this.lat * 0.012, -0.05, 0.05);
};
function collideWorld(o) {
  let hit = false;
  for (const b of solids) {
    if (o.x + o.r < b.x0 || o.x - o.r > b.x1 || o.z + o.r < b.z0 || o.z - o.r > b.z1) continue;
    const pl = o.x + o.r - b.x0, pr = b.x1 - (o.x - o.r), pu = o.z + o.r - b.z0, pd = b.z1 - (o.z - o.r), m = Math.min(pl, pr, pu, pd);
    if (m === pl) o.x -= pl; else if (m === pr) o.x += pr; else if (m === pu) o.z -= pu; else o.z += pd;
    hit = true;
  }
  return hit;
}

// player
let player = null;
function makePlayer() {
  const def = CARS.find((c) => c.id === S.car) || CARS[0];
  const old = player; player = new Vehicle(def, COLORS[S.color] || COLORS[0]);
  if (old) { player.place(old.x, old.z, old.yaw); scene.remove(old.mesh); } else player.place(road(4) + 3.5, road(4) - 30, 0);
}
makePlayer();

// traffic (stays on lanes, turns at intersections; just slows the player on contact)
const traffic = [];
function laneFor(dir) { return dir === 0 ? 3.5 : dir === 2 ? -3.5 : dir === 1 ? -3.5 : 3.5; } // 0:+z 1:+x 2:-z 3:-x (right-hand traffic)
const DIRV = [[0, 1], [1, 0], [0, -1], [-1, 0]];
function spawnTraffic(n) {
  for (let t = 0; t < n; t++) {
    const def = CARS[t % 3], v = new Vehicle(def, COLORS[(t * 3 + 1) % COLORS.length]);
    const along = Math.random() < 0.5, k = 1 + Math.floor(Math.random() * (N - 1)), dir = along ? (Math.random() < 0.5 ? 0 : 2) : (Math.random() < 0.5 ? 1 : 3);
    const s = rnd(-HALF + 20, HALF - 20);
    if (dir === 0 || dir === 2) v.place(road(k) + laneFor(dir), s, dir === 0 ? 0 : Math.PI); else v.place(s, road(k) + laneFor(dir), dir === 1 ? Math.PI / 2 : -Math.PI / 2);
    v.dir = dir; v.k = k; v.cruise = rnd(9, 14); v.v = v.cruise; v.lastNode = null; traffic.push(v);
  }
}
spawnTraffic(MOBILE ? 18 : 28);
function updateTraffic(dt) {
  for (const v of traffic) {
    const [dx, dz] = DIRV[v.dir];
    // slow down behind the player
    const px = player.x - v.x, pz = player.z - v.z, ahead = px * dx + pz * dz, side = Math.abs(px * dz - pz * dx);
    const target = ahead > 0 && ahead < 14 && side < 3 ? 0 : v.cruise;
    v.v = lerp(v.v, target, dt * 2.5);
    v.x += dx * v.v * dt; v.z += dz * v.v * dt;
    // at an intersection centre, maybe turn
    const ix = Math.round((v.x + HALF) / P), iz = Math.round((v.z + HALF) / P), cx = road(ix), cz = road(iz), node = ix + ',' + iz;
    const lx = cx + laneFor(v.dir) * (dz ? 1 : 0), lz = cz + laneFor(v.dir) * (dx ? 1 : 0);
    if (node !== v.lastNode && Math.abs(v.x - (dz ? lx : cx)) < 0.8 && Math.abs(v.z - (dx ? lz : cz)) < 0.8 || node !== v.lastNode && Math.hypot(v.x - cx, v.z - cz) < 4.2) {
      v.lastNode = node;
      const opts = [v.dir, (v.dir + 1) % 4, (v.dir + 3) % 4].filter((d) => { const nx = ix + DIRV[d][0], nz = iz + DIRV[d][1]; return nx >= 0 && nx <= N && nz >= 0 && nz <= N; });
      const nd = Math.random() < 0.6 && opts.includes(v.dir) ? v.dir : opts[Math.floor(Math.random() * opts.length)];
      if (nd !== v.dir) { v.dir = nd; const [ndx, ndz] = DIRV[nd]; v.x = ndz ? cx + laneFor(nd) : cx; v.z = ndx ? cz + laneFor(nd) : cz; v.yaw = Math.atan2(ndx, ndz); }
    }
    if (Math.abs(v.x) > HALF + 2 || Math.abs(v.z) > HALF + 2) { v.dir = (v.dir + 2) % 4; v.yaw += Math.PI; v.x = clamp(v.x, -HALF, HALF); v.z = clamp(v.z, -HALF, HALF); const [a, b] = DIRV[v.dir]; if (b) v.x = road(Math.round((v.x + HALF) / P)) + laneFor(v.dir); else v.z = road(Math.round((v.z + HALF) / P)) + laneFor(v.dir); }
    v.steer = 0; v.sync(dt);
  }
}

// ---------------- input ----------------
const IN = { gas: 0, brake: 0, left: 0, right: 0 };
const keys = {};
addEventListener('keydown', (e) => { keys[e.code] = 1; if (e.code === 'KeyH') horn(); if (e.code === 'KeyC') cycleCam(); if (e.code === 'Escape' && mode !== 'menu') pauseGame(); });
addEventListener('keyup', (e) => { keys[e.code] = 0; });
function bindHold(id, prop) {
  const el = $(id); let ids = new Set();
  const on = (e) => { e.preventDefault(); ids.add(e.pointerId); IN[prop] = 1; el.classList.add('dn'); audioStart(); try { el.setPointerCapture(e.pointerId); } catch (x) {} };
  const off = (e) => { ids.delete(e.pointerId); if (!ids.size) { IN[prop] = 0; el.classList.remove('dn'); } };
  el.addEventListener('pointerdown', on); el.addEventListener('pointerup', off); el.addEventListener('pointercancel', off); el.addEventListener('lostpointercapture', off);
}
bindHold('#bG', 'gas'); bindHold('#bB', 'brake'); bindHold('#bL', 'left'); bindHold('#bR', 'right');

// ---------------- audio ----------------
let AC = null, eng = null;
function audioStart() {
  if (!S.sound) return; if (!AC) { try { AC = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { return; } }
  if (AC.state === 'suspended') AC.resume();
  if (!eng) { const o = AC.createOscillator(), o2 = AC.createOscillator(), f = AC.createBiquadFilter(), g = AC.createGain(); o.type = 'sawtooth'; o2.type = 'square'; f.type = 'lowpass'; f.frequency.value = 600; g.gain.value = 0; o.connect(f); o2.connect(f); f.connect(g).connect(AC.destination); o.start(); o2.start(); eng = { o, o2, g, f }; }
}
function beep(f, d, type, vol, delay) { if (!AC || !S.sound) return; const t = AC.currentTime + (delay || 0), o = AC.createOscillator(), g = AC.createGain(); o.type = type || 'sine'; o.frequency.value = f; g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol || 0.2, t + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + d); o.connect(g).connect(AC.destination); o.start(t); o.stop(t + d + 0.05); }
function horn() { audioStart(); beep(392, 0.35, 'square', 0.12); beep(330, 0.35, 'square', 0.1); }
const ding = () => { beep(880, 0.15, 'triangle', 0.2); beep(1320, 0.2, 'triangle', 0.15, 0.08); };
const bump = () => beep(90, 0.18, 'sawtooth', 0.18);
const win = () => [523, 659, 784, 1047].forEach((f, i) => beep(f, 0.3, 'triangle', 0.18, i * 0.12));
document.addEventListener('pointerdown', audioStart, { capture: true });

// ---------------- camera ----------------
let camMode = 0; const camPos = new THREE.Vector3(0, 8, -12);
function cycleCam() { camMode = (camMode + 1) % 3; }
function updateCam(dt, snap) {
  const back = [9.5, 15, 0.2][camMode], up = [3.6, 6.5, 1.35][camMode], look = [2.2, 3, 0.9][camMode];
  const fx = Math.sin(player.yaw), fz = Math.cos(player.yaw);
  const want = new THREE.Vector3(player.x - fx * back, up, player.z - fz * back);
  if (camMode === 2) want.set(player.x + fx * 0.3, up, player.z + fz * 0.3);
  camPos.lerp(want, snap ? 1 : 1 - Math.exp(-dt * (camMode === 2 ? 30 : 6)));
  camera.position.copy(camPos);
  camera.lookAt(player.x + fx * (camMode === 2 ? 20 : 6), look, player.z + fz * (camMode === 2 ? 20 : 6));
  camera.fov = lerp(camera.fov, 60 + Math.abs(player.v) * 0.35, dt * 2); camera.updateProjectionMatrix();
  sun.position.set(player.x + 60, 110, player.z + 35); sun.target.position.set(player.x, 0, player.z);
}

// ---------------- player physics ----------------
function updatePlayer(dt) {
  const d = player.def;
  const gas = IN.gas || keys.ArrowUp || keys.KeyW ? 1 : 0, brk = IN.brake || keys.ArrowDown || keys.KeyS ? 1 : 0;
  const st = (IN.left || keys.ArrowLeft || keys.KeyA ? 1 : 0) - (IN.right || keys.ArrowRight || keys.KeyD ? 1 : 0);
  if (mode === 'count' || mode === 'done') { player.v = lerp(player.v, 0, dt * 3); }
  else {
    if (gas) player.v += d.acc * (1 - Math.max(0, player.v) / d.top) * dt;
    if (brk) player.v -= (player.v > 0.5 ? 30 : 9) * dt;
    if (!gas && !brk) player.v -= Math.sign(player.v) * Math.min(Math.abs(player.v), 4 * dt);
    player.v = clamp(player.v, -10, d.top);
  }
  player.steer = lerp(player.steer, st, dt * 8);
  const sp = Math.abs(player.v), steerAmt = player.steer * (1.9 / (1 + sp * 0.045)) * clamp(sp / 4, 0, 1) * Math.sign(player.v || 1);
  player.yaw += steerAmt * dt;
  player.lat = lerp(player.lat, steerAmt * sp * 0.6, dt * (10 - d.grip * 0.6));
  const fx = Math.sin(player.yaw), fz = Math.cos(player.yaw);
  player.x += (fx * player.v + fz * player.lat * 0.05) * dt; player.z += (fz * player.v - fx * player.lat * 0.05) * dt;
  const before = player.v;
  if (collideWorld(player)) { player.v *= 0.55; if (Math.abs(before) > 8) { bump(); shake = 0.4; } }
  for (const o of traffic.concat(racers)) {
    const dx = player.x - o.x, dz = player.z - o.z, dd = Math.hypot(dx, dz), m = player.r + o.r - 0.3;
    if (dd < m && dd > 0.01) { const push = (m - dd); player.x += (dx / dd) * push * 0.7; player.z += (dz / dd) * push * 0.7; o.x -= (dx / dd) * push * 0.3; o.z -= (dz / dd) * push * 0.3; if (Math.abs(player.v) > 6) { bump(); shake = 0.35; } player.v *= 0.6; }
  }
  player.sync(dt);
  if (eng) { const t = AC.currentTime, rpm = 40 + (sp % 14) * 6 + sp * 2.2; eng.o.frequency.setTargetAtTime(rpm, t, 0.05); eng.o2.frequency.setTargetAtTime(rpm * 0.5, t, 0.05); eng.g.gain.setTargetAtTime(S.sound && mode !== 'menu' ? 0.035 + (gas ? 0.03 : 0) : 0, t, 0.1); }
}
let shake = 0;

// ---------------- markers, checkpoints, stars ----------------
const ringMat = new THREE.MeshBasicMaterial({ color: '#ffc93c', transparent: true, opacity: 0.75, side: THREE.DoubleSide });
const ringGeo = new THREE.TorusGeometry(6.2, 0.35, 8, 40);
const beamGeo = new THREE.CylinderGeometry(3, 3, 40, 24, 1, true);
const node = (k, l) => ({ x: road(k), z: road(l) });
function beam(x, z, color) { const m = new THREE.Mesh(beamGeo, new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.28, depthWrite: false, side: THREE.DoubleSide })); m.position.set(x, 20, z); scene.add(m); return m; }
const starGeo = (() => { const s = new THREE.Shape(); for (let i = 0; i < 10; i++) { const a = (i / 10) * Math.PI * 2 - Math.PI / 2, r = i % 2 ? 0.45 : 1.1; i ? s.lineTo(Math.cos(a) * r, Math.sin(a) * r) : s.moveTo(Math.cos(a) * r, Math.sin(a) * r); } return new THREE.ExtrudeGeometry(s, { depth: 0.3, bevelEnabled: false }); })();
const starMat = new THREE.MeshStandardMaterial({ color: '#ffd23f', emissive: '#ffb000', emissiveIntensity: 0.6, metalness: 0.3, roughness: 0.3 });

// ---------------- races & missions ----------------
const ROUTES = {
  r1: [[4, 4], [4, 6], [6, 6], [6, 3], [3, 3], [3, 1], [1, 1], [1, 4], [4, 4]],
  r2: [[2, 2], [6, 2], [6, 5], [7, 5], [7, 7], [3, 7], [3, 5], [1, 5], [1, 2], [2, 2]],
  r3: [[0, 0], [8, 0], [8, 4], [5, 4], [5, 8], [0, 8], [0, 3], [2, 3], [2, 0], [0, 0]],
};
const EVENTS = [
  { id: 'r1', kind: 'race', name: 'سباق وسط البلد', desc: 'سباق قصير بين العمارات العالية', laps: 1, ai: [0.78, 0.83, 0.88], at: [4, 4] },
  { id: 'r2', kind: 'race', name: 'سباق الحدايق', desc: 'شوارع طويلة وملفات كتير', laps: 1, ai: [0.84, 0.89, 0.93], at: [2, 2] },
  { id: 'r3', kind: 'race', name: 'سباق الطريق الدائري', desc: 'أطول سباق حوالين المدينة كلها', laps: 1, ai: [0.88, 0.92, 0.97], at: [0, 0] },
  { id: 'stars', kind: 'stars', name: 'لم النجوم', desc: 'لِم 15 نجمة في الشوارع قبل ما الوقت يخلص', time: 120, at: [5, 5] },
  { id: 'deliver', kind: 'deliver', name: 'توصيل الطلبات', desc: 'وصّل 4 طلبات لأماكنها بسرعة', time: 150, at: [3, 6] },
];
let mode = 'menu', ev = null, cps = [], cpMesh = null, cpBeam = null, cpIdx = 0, t0 = 0, timeLeft = 0, racers = [], starsObjs = [], got = 0, drops = [], dropIdx = 0;
const markers = EVENTS.map((e) => { const p = node(...e.at); const b = beam(p.x, p.z, e.kind === 'race' ? '#ffc93c' : e.kind === 'stars' ? '#ffe066' : '#5cc3ff'); return { e, b, x: p.x, z: p.z }; });
function clearEvent() {
  if (cpMesh) scene.remove(cpMesh); if (cpBeam) scene.remove(cpBeam); cpMesh = cpBeam = null;
  racers.forEach((r) => scene.remove(r.mesh)); racers = []; starsObjs.forEach((s) => scene.remove(s)); starsObjs = []; drops = [];
  markers.forEach((m) => (m.b.visible = true)); ev = null; $('#mis').classList.remove('on');
}
function showCp() {
  if (cpMesh) scene.remove(cpMesh); if (cpBeam) scene.remove(cpBeam);
  const c = cps[cpIdx]; if (!c) return;
  cpMesh = new THREE.Mesh(ringGeo, ringMat); cpMesh.position.set(c.x, 6.4, c.z);
  const nx = cps[cpIdx + 1] || c, pv = cps[cpIdx - 1] || c; cpMesh.rotation.y = Math.atan2(nx.x - pv.x, nx.z - pv.z);
  scene.add(cpMesh); cpBeam = beam(c.x, c.z, '#ffc93c');
}
function startEvent(e) {
  clearEvent(); ev = e; markers.forEach((m) => (m.b.visible = false)); hideOv(); $('#hud').classList.add('on'); $('#ctl').classList.add('on');
  if (e.kind === 'race') {
    const route = ROUTES[e.id]; cps = [];
    for (let l = 0; l < e.laps; l++) route.slice(1).forEach((p) => cps.push(node(...p)));
    const s = node(...route[0]), n1 = node(...route[1]), yaw = Math.atan2(n1.x - s.x, n1.z - s.z), fx = Math.sin(yaw), fz = Math.cos(yaw), rx = fz, rz = -fx;
    const grid = [[-3.2, 0], [3.2, 0], [-3.2, -8], [3.2, -8]];
    player.place(s.x + rx * grid[3][0] + fx * (grid[3][1] + 4), s.z + rz * grid[3][0] + fz * (grid[3][1] + 4), yaw);
    e.ai.forEach((skill, n) => { const v = new Vehicle(CARS[n % 3], COLORS[(n + 2) % COLORS.length]); v.place(s.x + rx * grid[n][0] + fx * (grid[n][1] + 4), s.z + rz * grid[n][0] + fz * (grid[n][1] + 4), yaw); v.skill = skill; v.cp = 0; v.done = 0; racers.push(v); });
    cpIdx = 0; showCp(); countdown();
  } else if (e.kind === 'stars') {
    got = 0; const p = node(...e.at); player.place(p.x + 3.5, p.z, 0);
    const used = new Set();
    while (starsObjs.length < 15) {
      const k = Math.floor(Math.random() * (N + 1)), i = Math.floor(Math.random() * N), along = Math.random() < 0.5, t = rnd(blockMin(i) + 6, blockMax(i) - 6), key = k + ',' + i + along;
      if (used.has(key)) continue; used.add(key);
      const m = new THREE.Mesh(starGeo, starMat); m.scale.setScalar(1.3); along ? m.position.set(road(k) + rnd(-3, 3), 1.6, t) : m.position.set(t, 1.6, road(k) + rnd(-3, 3)); scene.add(m); starsObjs.push(m);
    }
    timeLeft = e.time; mode = 'play'; t0 = performance.now(); toast('⭐ لِم كل النجوم!');
  } else if (e.kind === 'deliver') {
    const p = node(...e.at); player.place(p.x + 3.5, p.z, 0); drops = [];
    while (drops.length < 4) { const k = Math.floor(Math.random() * (N + 1)), l = Math.floor(Math.random() * (N + 1)), q = node(k, l); if (Math.hypot(q.x - (drops.length ? drops[drops.length - 1].x : p.x), q.z - (drops.length ? drops[drops.length - 1].z : p.z)) > 150) drops.push(q); }
    dropIdx = 0; cps = drops; cpIdx = 0; showCp(); timeLeft = e.time; mode = 'play'; t0 = performance.now(); toast('📦 وصّل الطلب للمكان المنوّر');
  }
  updateCam(0, true);
}
function countdown() {
  mode = 'count'; let n = 3; const big = $('#big');
  const step = () => { if (mode !== 'count') return; big.textContent = n > 0 ? n : 'انطلق!'; big.classList.add('on'); beep(n > 0 ? 440 : 880, 0.25, 'triangle', 0.25);
    if (n === 0) { mode = 'play'; t0 = performance.now(); setTimeout(() => big.classList.remove('on'), 700); return; } n--; setTimeout(step, 900); };
  step();
}
function racerProgress(v) { const c = cps[v.cp] || cps[cps.length - 1], p = cps[v.cp - 1] || c; return v.cp * 1000 - Math.hypot(v.x - c.x, v.z - c.z) + (v.done ? 1e6 - v.done : 0); }
function updateRacers(dt) {
  for (const v of racers) {
    if (v.done || mode === 'count') { v.v = lerp(v.v, 0, dt * 2); v.sync(dt); continue; }
    const c = cps[v.cp]; if (!c) continue;
    const dx = c.x - v.x, dz = c.z - v.z, dist = Math.hypot(dx, dz);
    const want = Math.atan2(dx, dz); let da = want - v.yaw; while (da > Math.PI) da -= Math.PI * 2; while (da < -Math.PI) da += Math.PI * 2;
    const nx = cps[v.cp + 1]; let turn = 0; if (nx) { const a1 = Math.atan2(nx.x - c.x, nx.z - c.z); turn = Math.abs(Math.atan2(Math.sin(a1 - want), Math.cos(a1 - want))); }
    const top = 40 * v.skill, slow = turn > 0.6 && dist < 34 ? lerp(13, top, clamp((dist - 10) / 24, 0, 1)) : top;
    v.v = lerp(v.v, Math.abs(da) > 0.5 ? Math.min(slow, 12) : slow, dt * 1.6);
    v.steer = clamp(da * 2, -1, 1); v.yaw += clamp(da, -1, 1) * dt * 2.6;
    v.x += Math.sin(v.yaw) * v.v * dt; v.z += Math.cos(v.yaw) * v.v * dt;
    collideWorld(v);
    if (dist < 7) { v.cp++; if (v.cp >= cps.length) v.done = performance.now(); }
    v.sync(dt);
  }
}
const fmt = (s) => { s = Math.max(0, s); const m = Math.floor(s / 60), r = s - m * 60; return m + ':' + (r < 10 ? '0' : '') + r.toFixed(1); };
function updateEvent(dt) {
  const mis = $('#mis');
  if (!ev) {
    // free roam: offer the nearest event marker
    let near = null; for (const m of markers) if (Math.hypot(player.x - m.x, player.z - m.z) < 9) near = m;
    const nb = $('#near'); if (near) { nb.textContent = '▶ ابدأ: ' + near.e.name; nb.classList.add('on'); nb.onclick = () => startEvent(near.e); } else nb.classList.remove('on');
    return;
  }
  $('#near').classList.remove('on');
  const el = (performance.now() - t0) / 1000;
  if (ev.kind === 'race') {
    if (mode === 'play') {
      const c = cps[cpIdx]; if (c && Math.hypot(player.x - c.x, player.z - c.z) < 7.5) { cpIdx++; ding(); if (cpIdx >= cps.length) return finishRace(el); showCp(); }
      const me = cpIdx * 1000 - (cps[cpIdx] ? Math.hypot(player.x - cps[cpIdx].x, player.z - cps[cpIdx].z) : 0);
      const pos = 1 + racers.filter((r) => racerProgress(r) > me).length;
      mis.innerHTML = `المركز ${pos} من ${racers.length + 1} · ${cpIdx}/${cps.length}<small>⏱️ ${fmt(el)}</small>`; mis.classList.add('on');
      if (racers.every((r) => r.done) && el > 5) { /* keep racing; player can still finish */ }
    }
  } else {
    timeLeft = ev.time - el;
    if (ev.kind === 'stars') {
      for (let n = starsObjs.length - 1; n >= 0; n--) { const s = starsObjs[n]; s.rotation.y += dt * 2.5; if (Math.hypot(player.x - s.position.x, player.z - s.position.z) < 3.4) { scene.remove(s); starsObjs.splice(n, 1); got++; ding(); } }
      mis.innerHTML = `⭐ ${got}/15<small>⏱️ ${fmt(timeLeft)}</small>`; mis.classList.add('on');
      if (got >= 15) return finishMission(true, el); if (timeLeft <= 0) return finishMission(false, el);
    } else {
      const c = cps[cpIdx]; if (c && Math.hypot(player.x - c.x, player.z - c.z) < 7.5) { cpIdx++; ding(); toast(cpIdx < cps.length ? '✅ اتوصّل! الطلب اللي بعده' : '✅ كل الطلبات اتوصلت'); if (cpIdx >= cps.length) return finishMission(true, el); showCp(); }
      mis.innerHTML = `📦 ${cpIdx}/${cps.length}<small>⏱️ ${fmt(timeLeft)}</small>`; mis.classList.add('on');
      if (timeLeft <= 0) return finishMission(false, el);
    }
  }
  if (cpMesh) cpMesh.rotation.z += dt;
}
function reward(n) { S.stars += n; save(); setStars(); }
function finishRace(el) {
  mode = 'done'; const me = 1e6, pos = 1 + racers.filter((r) => r.done && r.done < performance.now()).length;
  const prize = [5, 3, 2, 1][pos - 1] || 1; reward(prize); win();
  const best = S.best[ev.id]; if (!best || el < best) { S.best[ev.id] = +el.toFixed(1); save(); }
  result(pos === 1 ? '🏆 كسبت السباق!' : '🏁 خلّصت السباق', `المركز <b>${pos}</b> من ${racers.length + 1}<br>الوقت ${fmt(el)}${best ? ' · أحسن وقت ' + fmt(Math.min(best, el)) : ''}<br>كسبت ⭐ ${prize}`);
}
function finishMission(ok, el) {
  mode = 'done'; const prize = ok ? 4 : 1; reward(prize); ok ? win() : bump();
  result(ok ? '🎉 برافو! المهمة خلصت' : '⏱️ الوقت خلص', (ev.kind === 'stars' ? `لمّيت ⭐ ${got} من 15` : `وصّلت ${cpIdx} من ${cps.length} طلبات`) + `<br>كسبت ⭐ ${prize}`);
}
function result(t, b) { $('#resT').textContent = t; $('#resB').innerHTML = b; setTimeout(() => showOv('#result'), 900); }

// ---------------- minimap ----------------
const mapC = $('#map'), mg = mapC.getContext('2d');
function drawMap() {
  const W = mapC.width, s = W / (N * P + R), o = (v) => (v + HALF + R / 2) * s;
  mg.clearRect(0, 0, W, W); mg.save(); mg.translate(W / 2, W / 2); mg.rotate(player.yaw + Math.PI); mg.translate(-o(player.x) * 1, -o(player.z) * 1);
  mg.fillStyle = 'rgba(255,255,255,.08)'; for (let i = 0; i < N; i++) for (let j = 0; j < N; j++) mg.fillRect(o(blockMin(i)), o(blockMin(j)), BS * s, BS * s);
  mg.fillStyle = '#5b6370'; for (let k = 0; k <= N; k++) { mg.fillRect(o(road(k) - R / 2), o(-HALF - R / 2), R * s, (N * P + R) * s); mg.fillRect(o(-HALF - R / 2), o(road(k) - R / 2), (N * P + R) * s, R * s); }
  if (!ev) markers.forEach((m) => { mg.fillStyle = m.e.kind === 'race' ? '#ffc93c' : '#5cc3ff'; mg.beginPath(); mg.arc(o(m.x), o(m.z), 5, 0, 7); mg.fill(); });
  if (cps[cpIdx] && ev && ev.kind !== 'stars') { mg.fillStyle = '#ffd23f'; mg.beginPath(); mg.arc(o(cps[cpIdx].x), o(cps[cpIdx].z), 6, 0, 7); mg.fill(); }
  starsObjs.forEach((st) => { mg.fillStyle = '#ffe066'; mg.fillRect(o(st.position.x) - 2.5, o(st.position.z) - 2.5, 5, 5); });
  racers.forEach((r) => { mg.fillStyle = '#ff5a5a'; mg.beginPath(); mg.arc(o(r.x), o(r.z), 3.5, 0, 7); mg.fill(); });
  mg.restore();
  mg.fillStyle = '#4fe37a'; mg.beginPath(); mg.moveTo(W / 2, W / 2 - 8); mg.lineTo(W / 2 + 6, W / 2 + 6); mg.lineTo(W / 2 - 6, W / 2 + 6); mg.fill();
}

// ---------------- UI ----------------
const toastEl = $('#toast'); let toastT = 0;
function toast(t) { toastEl.textContent = t; toastEl.classList.add('on'); clearTimeout(toastT); toastT = setTimeout(() => toastEl.classList.remove('on'), 2200); }
function hideOv() { $$('.ov').forEach((o) => { if (o.id !== 'hud' && o.id !== 'ctl') o.classList.remove('on'); }); }
function showOv(id) { hideOv(); $(id).classList.add('on'); }
function toMenu() { clearEvent(); paused = false; mode = "menu"; $('#hud').classList.remove('on'); $('#ctl').classList.remove('on'); showOv('#home'); }
function freeRoam() { clearEvent(); hideOv(); mode = 'play'; $('#hud').classList.add('on'); $('#ctl').classList.add('on'); toast('🚗 دوّر على الأعمدة المنوّرة علشان تبدأ سباق أو مهمة'); }
let paused = false;
function pauseGame() { if (mode === 'menu') return; paused = true; showOv('#pause'); $('#restartBtn').style.display = ev ? '' : 'none'; }
function renderRaces() {
  $('#raceList').innerHTML = EVENTS.map((e) => `<div class="card"><div class="t">${e.kind === 'race' ? '🏁' : e.kind === 'stars' ? '⭐' : '📦'} ${e.name}</div><div class="d">${e.desc}</div><div class="r"><span>${S.best[e.id] ? '⏱️ أحسن وقت ' + fmt(S.best[e.id]) : ''}</span><span>${e.kind === 'race' ? 'الجايزة حتى ⭐5' : 'الجايزة ⭐4'}</span></div><button class="go" data-ev="${e.id}">ابدأ</button></div>`).join('');
  $$('[data-ev]').forEach((b) => (b.onclick = () => startEvent(EVENTS.find((e) => e.id === b.dataset.ev))));
}
function renderGarage() {
  $('#carList').innerHTML = CARS.map((c) => { const own = S.owned.includes(c.id); return `<div class="card ${S.car === c.id ? 'sel' : ''}"><div class="t">🚗 ${c.name}</div><div class="d">السرعة ${Math.round(c.top * 3.6)} كم/س · التسارع ${'★'.repeat(Math.round(c.acc / 7))}</div><button class="go" data-car="${c.id}">${S.car === c.id ? '✓ مختارة' : own ? 'اختار' : '🔒 افتح بـ ⭐' + c.cost}</button></div>`; }).join('');
  $('#colors').innerHTML = COLORS.map((c, n) => `<button style="background:${c}" class="${S.color === n ? 'on' : ''}" data-col="${n}"></button>`).join('');
  $$('[data-car]').forEach((b) => (b.onclick = () => { const c = CARS.find((x) => x.id === b.dataset.car); if (!S.owned.includes(c.id)) { if (S.stars < c.cost) { toast('محتاج ⭐ ' + c.cost + ' — العب سباقات ومهام'); return; } S.stars -= c.cost; S.owned.push(c.id); setStars(); ding(); } S.car = c.id; save(); makePlayer(); renderGarage(); }));
  $$('[data-col]').forEach((b) => (b.onclick = () => { S.color = +b.dataset.col; save(); makePlayer(); renderGarage(); }));
}
document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-a]'); if (!b) return; const a = b.dataset.a; audioStart(); beep(660, 0.06, 'triangle', 0.1);
  if (a === 'free') freeRoam(); else if (a === 'races') { renderRaces(); showOv('#races'); } else if (a === 'garage') { renderGarage(); showOv('#garage'); } else if (a === 'home' || a === 'quit') toMenu();
  else if (a === 'sound') { S.sound = !S.sound; save(); $('#sndBtn').textContent = S.sound ? '🔊 الصوت' : '🔇 الصوت'; if (eng) eng.g.gain.value = 0; }
  else if (a === 'games') { history.length > 1 ? history.back() : (location.href = '/'); }
  else if (a === 'pause') pauseGame(); else if (a === 'resume') { paused = false; hideOv(); } else if (a === 'restart' || a === 'again') { const e2 = ev || lastEv; paused = false; if (e2) startEvent(e2); else freeRoam(); }
  else if (a === 'cam') cycleCam(); else if (a === 'horn') horn();
});
$('#sndBtn').textContent = S.sound ? '🔊 الصوت' : '🔇 الصوت';
let lastEv = null;
const _start = startEvent; // remember the last event for "play again"

// ---------------- loop ----------------
let last = performance.now(), mapT = 0;
function frame(now) {
  requestAnimationFrame(frame);
  let dt = Math.min(0.05, (now - last) / 1000); last = now;
  if (ev) lastEv = ev;
  if (mode === 'menu') { // slow cinematic orbit behind the menu
    const t = now / 9000; camera.position.set(Math.sin(t) * 90, 45, Math.cos(t) * 90); camera.lookAt(0, 8, 0);
    sun.position.set(60, 110, 35); sun.target.position.set(0, 0, 0); updateTraffic(dt); renderer.render(scene, camera); return;
  }
  if (!paused) {
    updatePlayer(dt); updateTraffic(dt); updateRacers(dt); if (mode !== 'done') updateEvent(dt);
    markers.forEach((m) => (m.b.material.opacity = 0.2 + Math.sin(now / 300) * 0.08));
  }
  updateCam(dt);
  if (shake > 0) { camera.position.x += rnd(-shake, shake); camera.position.y += rnd(-shake, shake) * 0.5; shake = Math.max(0, shake - dt * 1.5); }
  $('#spd').textContent = Math.round(Math.abs(player.v) * 3.6);
  if ((mapT += dt) > 0.1) { mapT = 0; drawMap(); }
  renderer.render(scene, camera);
}
requestAnimationFrame(frame);
window.LOLO_DRIVE = { S, startEvent, EVENTS, freeRoam, toMenu, get player() { return player; } };
